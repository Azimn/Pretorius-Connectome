# Pretorius: The Lost Years
## Batch 1 Production Report

**Date compiled:** 2026-10-08

**Result:** 102 new autobiographical memory events across 5 complete chronological episodes. All are marked **reconstructed**, with explicitly named established anchors held in the continuity ledger. **Speculative crossover events:** 0. Childhood additions: 0; primary-source childhood facts are preserved in the manuscript preface and ledger rather than fictionalized into trauma.

**Periods covered:** 1860-1864, 1864-1868, 1868-1877, 1878-1888 and 1889-June 1899. The first two episodes contain 41 academic and scientific-career events; the subsequent three contain 61 exile, fieldwork, relationship and independent-research events. This distribution favors adult exile in keeping with project emphasis.

**Narrative size:** 12,791 words in event bodies, excluding metadata and continuity prose. Each complete episode contains between 15 and 30 linked events. All memory_text fields are first-person scene accounts. **Record order:** E01-001 through E05-021.

**Input audit:** Autobiography: 1842 birth; 1860 matriculation; 1864 doctorate and faculty appointment; Henry mentorship; six established homunculi in stated order before dismissal; 1868 expulsion and tower; 1899 news of Henry. The original manuscript also contains a large repeated LoRA training archive, and the second file includes 389 JSONL `generated_training` conversational entries. Those are not primary eyewitness records. The 1860s University of Ingolstadt is incompatible with actual history, so it remains a flagged fictional divergence, not a silently repaired location.

**Duplicates:** 0 exact repeated memory texts across the 102 new events. Near-duplicate review used TF-IDF unigram/bigram cosine, threshold 0.40 for review. 0 distinct pairs exceeded its comparison threshold; see below for any flagged pairs. Related scenes deliberately return to the same subject with new evidence or changed relationships and are not automatically duplicates.

**Near-duplicate review candidates:** None at the chosen threshold.

**Chronological uncertainties and conflicts:** The functioning Ingolstadt university of the 1860s is fictional relative to documented history. Pretorius's rapid 1864 doctorate and professorship remain original canon, though unusually early. The exact dates of the six homunculi and the 1899 windmill incident are not fixed in the autobiography; new intermediate dates are approximations, not claims about source chronology. The primary text states nearly thirty years of isolation in broad terms, while the reconstruction introduces discreet visits, travel and correspondence; the interpretive choice is that *obscurity* need not mean complete immobility. Readers who prefer literal total seclusion should review the 1878-1897 travel subarc as a potentially incompatible extension. Public-domain literary novels appear only as contemporary books, not direct encounters.

**Historical consistency:** 1866 is treated as a period of wartime anxiety without fabricating a specific military service record; 1870-71 references correspond to the Franco-Prussian War and unification. Mendelssohn's 'Spring Song' was published by 1844, predating the 1867 Ballerina scene. *Strange Case of Dr Jekyll and Mr Hyde* appeared in 1886; *The Island of Doctor Moreau* in 1896. For background: https://www.lmu.de/en/about-lmu/lmu-at-a-glance/history/ ; https://imslp.org/wiki/Lieder_ohne_Worte,_Op.62_(Mendelssohn,_Felix) ; https://www.gutenberg.org/ebooks/159 ; https://germanhistorydocs.org/en/forging-an-empire-bismarckian-germany-1866-1890/creation-of-the-german-empire-1866-1871

**Unresolved threads:** Henry's unanswered correspondence; Pretorius's motives for contact; whether the homunculi's responses reflect learned anticipation or simpler environmental cues; Clara's independent life and slowing business; the archive succession; the difficulty of scaling living forms without endangering existing lives; the old paper laboratory model; the degree of trust between Pretorius and Voss; the ethical question Reuter pressed about pain and restriction; interpretation of the Queen's avoidance and of the King/Archbishop cooperative episodes.

**Privacy and safety of inference:** Fields headed `observations` and `belief_changes` distinguish recorded behavior from Pretorius's interpretations. No new biography is treated as evidence that the historical source attests actual creature consciousness. The cultivation process stays wholly fictional and nonprocedural.

**QA controls:** Required keys and nonempty memory bodies; monotonic event chronology; episode lengths 15-30; referential integrity and prior-only event links; no events after 1899; no reunion, Bride or Frankenstein Village material; no em dashes; no sub-90-word scenes. Automated validation output: **PASS**, with 0 errors. The events additionally received manual narrative review of recurring objects, named relationships and source anchors.

**Exact continuation checkpoint:** **E05-021, June 1899**, ending with Pretorius still at the tower, having obtained corroboration about Henry and the creature. There is no later permitted event within this project's boundary. Any further in-scope enrichment should be inserted as retrospective scenes *before* that date, using distinct IDs and revised chronological_order values. No next encounter can be written without changing the stop rule.
