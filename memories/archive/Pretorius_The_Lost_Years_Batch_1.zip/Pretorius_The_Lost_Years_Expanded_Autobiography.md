# Pretorius: The Lost Years

*An autobiographical reconstruction in five linked episodes, 1860 to June 1899.*

**Provenance:** Every numbered scene is a reconstructed fictional memory, not a quotation from the source autobiography. The institutional history and pivotal canonical acts are anchored to the source; events, dialogue, supporting characters, dates of intermediate incidents, and remembered particulars are inventions. The first-person narrator is intentionally imperfect, and some of his explanations are visibly contradicted by his behavior.

**Boundary:** This manuscript ends before Pretorius reunites with Henry Frankenstein. No scene from their reunion, the Bride, later events or Frankenstein Village appears here.

**Earlier life:** Born in 1842 in Ingolstadt, Pretorius was raised by a provincial magistrate who hoped he would study law. Those details are established in the source. This reconstruction begins with adult education, keeping childhood out of the newly invented memory corpus.


## Episode 01: The Borrowed Rooms (1860 to 1864)

### E01-001 | The Empty Specimen Drawer | 1860-10

On my third day at the university, I was given a drawer that smelled of camphor and contained nothing except a dead beetle pinned through its thorax. Herr Kappel, keeper of the cabinet, called it an accommodation. I called it a warning about academic generosity. He had lost the key to the better drawer, or claimed to have lost it, and made me sign twice for a cracked magnifying lens. I spent the afternoon arranging the beetle's wings under the glass, discovering that I could change the appearance of movement merely by altering the angle of the light. When Kappel returned, the drawer was cleaner than he had ever kept it. The following morning a second key appeared beside my ink bottle. He never admitted leaving it. I never thanked him in public.

### E01-002 | The Candle at the Stair | 1860-12

Professor Heller's final lecture ended in darkness because the caretaker had economized on candles. The students stamped about and made a nuisance of themselves, while I remained to question a diagram in which the nervous system had been represented as a line of telegraph wire. Heller relit one candle and invited me to prove the analogy wrong. I could not. What I could prove was that his diagram omitted interruption, delay and recovery. He listened until the wax had almost reached his fingers, then informed me that objections become useful only when their author can name a measurement. I went home irritated enough to fill six pages. Years later I could still recall the smell of his singed cuff. I have never forgiven him for giving me good advice in such a disagreeable manner.

### E01-003 | The Glassblower's Apprentice | 1861-02

Jakob Lenz was eighteen and had already burned two shirts practicing joints that would not leak. He regarded my sketch of a divided vessel, scratched on the back of an examination notice, as an insult to glass. The neck, he said, would break when warm. I told him that I had calculated the pressure. He heated a waste tube and it broke in precisely the place he had marked. I purchased the ruined piece and kept it on my desk, partly as a reminder and partly because he expected me to hide it. We spent the next month learning to disagree over a workbench without raising our voices. He called me Doctor long before I had the right to the title. I suspect he enjoyed my corrections.

### E01-004 | A Disputed Frog | 1861-04

Emil Reuter said a twitch proved an animal had obeyed the experimenter. Heller had asked us to distinguish response from recovery; Emil preferred a demonstration that drew applause. I had watched the frog's leg move even when the stimulus was applied by a boy whose hands were shaking. The animal, I remarked, was not consulting anyone's intentions. Emil laughed, and I laughed too, though at rather different things. Afterward I found him behind the lecture hall replacing the soiled bandage on his thumb. He had been burned preparing the apparatus and had concealed it to avoid losing his place. I helped tie the clean cloth. The next week he lent me his German translation of a French physiology paper, still stained at the corner with iodine.

### E01-005 | The Woman at the Dispensary | 1861-06

Clara Weiss could identify a spoiled botanical tincture by sight and refused to call the ability intuition. She showed me a yellow sediment at the bottom of a jar and asked what I thought it meant. I delivered an answer concerning light and degradation. She removed the cork and demonstrated that the odor contradicted my diagnosis. Her late husband had kept formula books; she had learned which of his confident entries were mistakes by cleaning up after them. I returned three days later with a proper note of the failure, expecting mockery. She gave me a small packet of clean filter paper and said the next specimen would cost me more. I paid. Thus began a correspondence founded less on affection than on our mutual preference for results that survived a second inspection.

### E01-006 | The Locked Shelf of Errors | 1861-09

Kappel showed me a neglected shelf of theses that had been withdrawn or rejected. They were tied with green tape and had the dusty dignity of small coffins. I asked why he had preserved them when the faculty had ordered their titles removed from the catalogue. He replied that a catalogue and a collection served different masters. One manuscript described a failed attempt to preserve a salamander's tissues during winter; its author had mistaken cold for death. I spent a week checking its observations instead of mocking them. Kappel produced more green tape when I returned the pages in order. I understood his bargain: he would trust me with condemned ideas provided I treated their authors as people who might have noticed something.

### E01-007 | The Cold Lecture Bench | 1861-11

We were obliged to count reactions in an unheated room with our pens stiffening between fingers. Emil complained of the cold and misread two intervals; I complained of Emil and misread a third. We warmed our hands around a kettle meant for the caretaker and repeated the observations. The figures agreed less closely with our preferred theory than the first set had done. I proposed omitting the earlier series. Emil looked at me for a long moment and said that if he had suggested such a thing I should have enjoyed humiliating him. He was correct, which made his tone intolerable. I entered both series, labelling the conditions with unusual diligence. We drank the caretaker's tea and replaced it the following morning.

### E01-008 | The First Blue Ledger | 1862-01

I purchased a blue ledger of the kind merchants used for debts and resolved to enter every experiment with the expenditure in the left column and an account of its failure in the right. Kappel objected that I had omitted a column for success. He was not joking. On the first page I recorded the cracked glass neck from Lenz's workshop and the price of the replacement. Against it I wrote that the failure had saved me a worse error. This arrangement pleased me until the seventh page, where a specimen had behaved exactly as expected and I found no useful place to put it. I drew a third column in red ink. An honest method, I discovered, is not one that never changes. It is one that announces the change.

### E01-009 | The Orchard After Frost | 1862-03

Clara persuaded me to walk into an orchard because she wanted branches collected before pruning. Every tree looked dead. She cut a narrow strip of bark and showed me the pale green tissue beneath. I observed that outward appearance was a notoriously poor guide to life, a conclusion she had plainly intended me to reach without fanfare. We brought the branches back wrapped in damp cloth. Two weeks later one produced a bud, while its neighbor, treated identically, remained inert. I wanted to sacrifice both for examination. Clara insisted that a living comparison required leaving one alive. We argued over lunch and I left the bud untouched. It proved nothing grand, but I still remember the small embarrassment of having to learn patience from a branch.

### E01-010 | The Essay No One Read | 1862-05

I submitted thirty-seven pages arguing that an organism ought to be defined by its capacity to sustain a coordinated process, not by resemblance to an approved anatomical form. Heller returned them with two lines underlined and a note asking whether a clock would qualify. I had not thought of clocks because the paper was about living things, an answer that would have amused him. He required me to defend the boundary rather than assume it. I spent a fortnight at the clockmaker's shop watching a spring lose its tension, then rewrote the argument around self-maintenance and repair. Heller read the second version without praise. He wrote only, 'Closer.' It was the first approval from him that I did not mistake for affection.

### E01-011 | A Dinner Without a Demonstration | 1862-07

Lenz brought a pie to Clara's Sunday table in a box intended for optical parts. I brought a drawing. She removed the drawing from beside the gravy and told us we were welcome to dinner only if we refrained from turning the potatoes into scientific examples. We managed eleven minutes. Lenz spoke about his sister's apprenticeship as a seamstress; Clara complained of customers who expected medicine to compensate for dirty water. I discovered that I did not know whether Lenz had brothers, although I had trusted him for a year with my most fragile vessels. On the walk back he asked if my mind ever stopped working. I said it stopped whenever someone served overcooked cabbage. He laughed, and thereafter never forgot to ask whether I had eaten.

### E01-012 | The Written Refusal | 1862-10

My father offered to place me in a clerkship where accurate figures and a respectable coat would, he said, carry me farther than disputing the nature of life. He had already written the recommendation. It stood on the mantel, folded in three, while he asked me to be practical. I thanked him for the care with which he had prepared it and returned it unread. This was not an act of courage. I was certain I could find my way without his help and rather liked proving it. In December I discovered that the examination fee exceeded my savings and sold two books I had intended to keep. My father never mentioned the letter again. Neither did I. The empty spaces on my shelf spoke with greater economy.

### E01-013 | An Interval Miscounted | 1863-01

Lenz delivered a metronome whose wooden case had split along the back. Emil suggested it could stand in for the expensive timing apparatus we were forbidden to borrow. We measured repeated recoveries from a mild stimulus in preserved preparation and obtained intervals so tidy that I suspected fraud. Emil demonstrated the deception without intending to: the pendulum slowed by a fraction when the table shook. The table shook whenever the furnace below was fed. We moved the apparatus to the window and repeated the work. The new results were untidy, which is to say they were useful. I bought the damaged metronome rather than return it; the crack made the instrument unfit for vanity and excellent for memory.

### E01-014 | A Funeral Register | 1863-03

A register clerk refused to let me copy the interval between a man's last observed breath and the formal declaration of death. He said I had no kinship claim. Kappel accompanied me on the second visit, brought a proper letter and quietly reminded me that the bereaved were not specimens. We were admitted to the record room and found that the interval varied with the weather, the availability of witnesses and the clerk's handwriting. The figures could not tell me exactly when a life had ceased. Kappel watched me close the book. I had expected an answer from official evidence and obtained instead a record of decisions made by tired men. I made a note of the distinction, though I did not particularly enjoy making it.

### E01-015 | Clara's Broken Jar | 1863-06

A shelf bracket failed at Clara's shop and six vessels fell before anyone could catch them. She was angrier about the labels than the loss of her stock, because she could replace medicine but not tell which formula belonged to the surviving sediment. Lenz spent an afternoon rebuilding the shelf. I copied the intact labels into my ledger and designed a numbering system she could manage even when tired. At first she rejected it as the officious invention of a man who did not sell medicine to coughing children. We simplified it to a pair of marks on each bottle and one page beside the till. Months later she showed me that the marks had rescued a batch from confusion. I felt a modest satisfaction that did not require an audience.

### E01-016 | A Visitor at the Back Door | 1863-09

My father came without his carriage and stood at the back door while I heated broth over a spirit lamp. He had heard I was selling books. I said the rumor was exaggerated, which it was only in the plural. He asked whether I wished to eat with the family that Sunday. I replied that I had been invited elsewhere, and saw at once that I had made another household sound like a challenge. Before leaving he examined the cracked metronome on my desk and asked if it still kept time. 'Only when properly placed,' I answered. He put down a parcel of good paper and said that was true of men as well. I used the paper for my thesis. I never told him.

### E01-017 | The Thesis in the Snow | 1863-12

I carried my thesis across the courtyard under my coat during the first wet snow of December. Reuter had checked the tables; Heller had removed three flattering adjectives with his own pencil. At the office I discovered that one page of diagrams was missing. It had remained on my bed, beside an untouched supper. Emil ran back for it while I waited on a corridor bench beneath a badly painted saint. When he returned he was breathless and furious that I had entrusted so much to a loose sheet. I submitted the packet a few minutes before the clerk locked his drawer. I remember chiefly that my feet were cold and that Emil, having rescued the work, refused to accompany me to the tavern.

### E01-018 | The Defense of a Boundary | 1864-03

One examiner asked where I would place a seed that had not yet germinated. Another asked whether a sleeping man was less alive than an active one. I answered the second tolerably and the first too quickly. Heller intervened only to ask what observation would change my mind. I described a dormant sample failing to resume coordinated activity under conditions where its living companion recovered. He called that a beginning rather than a conclusion. When the examination was finished, Reuter shook my hand with an expression I mistook for envy until he told me his mother had been admitted to hospital. We walked there together, still carrying the thesis. I received the doctorate soon afterward, but the walk is better preserved in my memory than the declaration.

### E01-019 | The Professorial Coat | 1864-05

I was appointed to the faculty with improbable speed, which has encouraged some biographers to accuse me of inventing the date. Heller examined the cuffs of my old coat and suggested that a professor ought to look as if he could afford to be contradicted. Kappel secured me a room whose door swelled in rain and whose window overlooked a wall. I bought a second-hand black coat and moved my blue ledger into the top desk drawer. On the first morning nobody attended office hours. I remained at my desk until dusk, preparing objections to students who did not exist. I was pleased with my appointment, disappointed in its immediate audience and ashamed of finding both feelings equally powerful.

### E01-020 | The Last Free Afternoon | 1864-08

Lenz announced that he would be married in autumn and might no longer be available for repairs at a moment's notice. I congratulated him by asking whether his intended bride understood the demands of sealed glass joints. Clara said that if I wished to preserve the friendship I should say something less absurd. We walked beside the river, ate black bread and watched two children set paper boats on the current. Lenz described a little workshop he hoped to rent. For the first time I understood that he intended a life not built around my apparatus. I offered him payment in advance for the next year's work, an offer he declined because he did not wish to owe me a year he had not yet lived. I admired the refusal and disliked it.


## Episode 02: The Professor and the Seed (1864 to 1868)

### E02-001 | An Earnest Student | 1864-10

Henry Frankenstein remained after my lecture while the others went to find their coats. He had an awkward habit of placing a question in front of him as though it were a fragile article and asking permission to touch it. His concern was not whether life could be measured, but whether the measurement would alter the thing measured. I gave him a badly copied diagram and told him to return it with three objections. The following week he brought seven, four good and three merely ambitious. He had marked the margins with a neatness that annoyed me until I discovered he had corrected one of my units. I began leaving the door unlatched on Thursdays. Henry interpreted this as encouragement; for once his interpretation was correct.

### E02-002 | The Anatomist's Conditions | 1864-12

Henry wished to work after hours in the anatomy hall. He believed I could simply grant permission. I explained that a professor of philosophy does not possess the keys to every corpse in Bavaria. Heller, who did possess influence, demanded a written purpose and a named supervisor. Henry prepared a letter so earnest that it sounded like a confession. I struck out the word 'conquest' and replaced it with 'observation.' Heller approved a restricted afternoon. Henry resented the limit; I resented asking for it. We used the afternoon to examine the conditions under which tissue ceased responding to stimulation. The most useful result was that neither of us could honestly say where cessation became final.

### E02-003 | A Question Under the Lamp | 1865-02

Henry arrived with the skull of a bird, wrapped in a handkerchief, and asked whether a living creature could be constructed from correct parts alone. I told him that a clock assembled from perfect wheels does nothing without their proper relations, and he objected that the metaphor proved too much. Our argument continued until the lamp smoked. Henry sketched a scheme for joining separate tissues; I drew instead a process by which organization might arise within a small volume. We did not resolve the distinction. The following morning my notes contained the phrase 'formation rather than assembly,' but I could not tell whether it had been mine or his. I left the authorship blank. It would not remain a harmless uncertainty.

### E02-004 | An Unpaid Lecture | 1865-04

Clara asked me to speak to apprentices about the difference between a medicine's label and its effects. Henry accompanied me, expecting an intellectual debate. What he received was a queue of tired women and young men with ink on their cuffs, none of whom wished to hear about Prometheus. I explained the error in a dosage ledger, using Clara's paired bottle marks, and the room paid attention. Afterward Henry said he had learned more from their questions than from my philosophy seminar. I told him he had an unfortunate enthusiasm for praising the obvious. Clara paid us in supper. Henry stayed to wash the cups, a courtesy I regarded as excessive until I noticed how tired she was.

### E02-005 | The Correspondence Packet | 1865-06

Reuter had obtained a place in a provincial hospital and sent me observations on patients who sometimes rallied after appearing beyond help. His packet smelled of damp paper and contained a thread tied around each group of cases. Henry urged me to treat the recoveries as evidence for his method of reanimation. I pointed out that none of the patients had been dead by an unambiguous standard. We wrote Reuter separate replies and discovered we had asked nearly identical questions in different language. I allowed Henry to put his reply beside mine in the outgoing envelope. Reuter answered only Henry's letter, apparently because the student had troubled to ask after his mother's health.

### E02-006 | The Key Returned | 1865-09

Kappel asked for the second cabinet key back. Some instruments had gone missing, and his superiors had started to count those whose names appeared in the borrowing register. I assumed he suspected me and replied rather cruelly. He produced the register: it was his own signature that had covered my access for years. The investigation would fall on him first. I returned the key and copied the names of the objects I was permitted to use. He said nothing until I reached the door, when he asked whether I had completed the study of delayed recovery. I said not yet. His expression made it plain that he knew how much that cost me. Trust, I learned, may survive the surrender of a privilege.

### E02-007 | The Small Green Vessel | 1865-11

Lenz made a greenish glass vessel from cullet he had intended to discard. Its base was imperfect and caught the lamplight in a narrow sickle. I asked whether the tint might harm the specimens. He asked whether I intended to study the specimen or the tint. Clara had brought dormant fragments of plant tissue for observation. Some revived; some did not. I began to suspect that organization might be induced by surroundings that did more than preserve it. I record this only as the origin of a line of thought, not as the origin of a recipe. When Lenz asked what I meant to grow, I said, 'Something that knows it has grown.' He called that an unnecessarily difficult commission.

### E02-008 | The Demonstration Declined | 1866-01

Heller offered me a public lecture slot on the condition that I demonstrate a result rather than a chain of possibilities. I had none that I trusted. Henry urged me to display the unusually responsive samples from Lenz's vessel, and I told him that an audience changes the temptation to interpret one's own eyes. We submitted a lecture on the history of vitalism instead. It drew twenty-six persons, eleven of whom left before the end. Henry found the evening humiliating. I found it instructive and perhaps a little humiliating as well. Heller stopped afterward to say he preferred an unexciting truth to a splendid failure dressed as discovery. I answered that the best discoveries rarely arrive dressed for dinner.

### E02-009 | The Nation on the Noticeboard | 1866-03

The notices about war were posted beside announcements of examinations and room changes, as though armies marched according to the academic calendar. Lenz worried about cousins who might be called up. Henry spoke of patriotic duty with the conviction of a man whose own hands were occupied by safer questions. I told him that nations were exceptionally large organisms and that governments shared with surgeons an alarming faith in amputation. He took offense. Later I bought extra coal because I feared transport would become erratic. Whatever opinions I possessed about states, they did not keep a laboratory warm. Lenz remembered my practical calculation long after Henry forgot my remark.

### E02-010 | Henry's Unsigned Page | 1866-06

Henry left a set of drawings beneath my door showing connections between separate organs. The pages contained no signature, though his precise numbering made authorship unmistakable. I corrected a faulty relation and returned them without comment. He confronted me three days later, convinced that silence meant contempt. I told him I had judged the drawing, not its author. He replied that authorship was precisely what frightened him: he feared producing something that would live and therefore belong to neither of us. I laughed at the word 'belong.' He did not. It was one of the first times I saw him hear a moral claim in a problem I considered mechanical. I kept a copy of the diagram and did not tell him so.

### E02-011 | The Empty Dish | 1866-09

For six weeks I inspected a sealed dish that appeared to contain nothing of interest. Clara advised me to discard it, then changed her mind because I was so eager to agree. Under an oblique light we saw minute structures along one edge, too disordered to call organs and too persistent to call sediment. I fetched Lenz, who pointed out that the dish had been tilted since the previous month. We levelled a second specimen and continued observing both. Neither produced the miracle I anticipated. The first did, however, make its growth follow a path different from that of the second. My ledger acquired an untidy sketch of two branching lines. Later I remembered the sketch more accurately than the specimen.

### E02-012 | The Winter Inventory | 1866-12

We closed the year by counting what had survived. My figures showed more failures than successes; Lenz's showed that the expenditure had exceeded the agreed sum; Clara's showed which samples could no longer be identified with certainty. I was displeased by all three accounts. We divided the laboratory into labelled shelves and made a rule that a vessel without a date would not be treated as evidence. The following morning I found a small parcel outside the door: bread, cheese and a note from Lenz's new wife, whom I had met only twice. It said, 'Eat while the lamps are still on.' I did so, at the worktable, while checking the labels again. I have kept none of that bread but remember it better than most of the year's arguments.

### E02-013 | The First Coherent Response | 1867-02

I shall not describe the preparation of the seed. The formula is not relevant to the recollection and I have no intention of donating it to posterity. What matters is that one minute developing form turned toward an intermittent shadow and continued to orient itself after the shadow was removed. Lenz suggested a mechanical response to heat. Clara changed the light and asked us to try again. We did. The little form did not behave like the first series of samples. I remained at the bench until my knees trembled, then went out to buy more candles. The grocer asked whether I had been drinking. I had not, which made the question particularly irritating. I wrote 'possible organized response' in the blue ledger and underlined 'possible.'

### E02-014 | Her Majesty's Refusal | 1867-04

The first successful homunculus was the Queen. I call her that now, although the title came several days after she had begun to live. She preferred a particular ledge in the glass, and when I changed its position she returned to it with an obstinacy I took for evidence of intention. Clara said that I might also be seeing a response to light. I marked the ledge and rotated the vessel twice. The Queen resumed her place. Then, after a pause in which she studied my immense face, she moved elsewhere. I was absurdly wounded. Lenz found me staring at the vessel and asked whether the sovereign had dismissed her court. I replied that I should have to learn the constitution. That night I slept in a chair beside her.

### E02-015 | A King with an Inconvenient Heart | 1867-06

The second homunculus developed the broad, self-important face of a Tudor monarch, an unfortunate resemblance I could not prevent myself from enjoying. The King noticed the Queen almost immediately. When their vessels stood side by side he abandoned food and attended to her movements until Clara ordered me to separate them for an hour. He returned to eating only when the Queen came back into view. I announced a study of attachment; Clara announced a study of whether my arrangements were distressing two small people. Both descriptions may have been true. The King knocked repeatedly against the glass when I moved the Queen's jar. I stopped moving it as often. This was the first important alteration to my laboratory made at the insistence of a creature I had manufactured.

### E02-016 | The Archbishop's Objection | 1867-08

A third little figure developed in an attitude of disapproval so sustained that we named him Archbishop before his clothing had properly formed. He interrupted the King's displays by striking a tiny staff against the base of his vessel. Lenz, who found this uproariously funny, positioned the jars so that the King could see both the Queen and the Archbishop. The result was a three-sided quarrel conducted with gestures too small to hear. I intended to study hierarchy and instead spent the morning shifting glass to prevent injury. Clara pointed out that the Archbishop did not object to the Queen at all, only to the King approaching her. I had assigned a theological motive to an observation that did not require one. The distinction displeased me because it was interesting.

### E02-017 | The Man in the Black Cape | 1867-10

I had not intended to cultivate anything resembling myself. Nonetheless the fourth figure emerged lean, dark and rather theatrical, with a black cape whose folds appeared before the rest of his costume had assumed proper definition. Lenz called him the Devil. Henry, shown the figure during one carefully supervised visit, regarded him with more unease than he had shown at the Queen. The Devil bowed toward his reflection in the glass and then turned his back upon us. I was delighted. Henry asked whether the miniature had learned vanity from its maker. I told him that resemblance proved kinship no more reliably than a portrait proved paternity. Yet I moved the little mirror out of the laboratory afterward. Certain jokes are more uncomfortable when they resemble observations.

### E02-018 | Music Before Supper | 1867-12

The Ballerina responded to Mendelssohn's 'Spring Song' and to very little else we tried. Clara first played the phrase on an ill-tuned piano in the room below, and the tiny dancer rose from her resting place. When the tune stopped, so did she. I assumed any melody in the same tempo would serve; she refused three substitutions, one played so badly that I sympathized with her judgment. A week later Clara was delayed, and I found myself humming at the jar while stirring soup. The Ballerina did not move. I ate the soup cold and waited for Clara's return. This dependence on a particular piece of music made the laboratory less controllable, and, to my surprise, considerably more pleasant.

### E02-019 | Salt in the Water | 1868-02

The Mermaid was born of an experiment involving seaweed brought inland in a parcel that leaked brine through its paper. I will say nothing useful about the cultivation, only that the resulting little being required a watery world which defeated my usual methods of examination. At first I thought her inactivity a sign of failure. Clara noticed her movements when the room was empty of visitors. We observed from behind a screen; the Mermaid rose toward the light and then vanished into the weed. I wrote that she was timid, then crossed the word out. Perhaps she merely preferred not to have giants breathing upon her water. I retained both formulations in the margin. The crossed-out one has proved the more revealing account of its author.

### E02-020 | The Visit from the Committee | 1868-04

A committee required an account of private investigations carried out during my appointment. Their complaint included conduct unbecoming a professor and experiments said to threaten the moral fabric of the institution. I placed several observation sheets before them but declined to surrender the complete method of cultivation. Heller examined the pages for longer than the others. He did not endorse me; nor did he call the figures false. A junior member asked whether the creatures were capable of suffering. I answered with a lecture on the definition of suffering and recognized only afterward that he had asked a simpler question. Henry waited outside, pale with loyalty and fear. I told him that my work had been misunderstood. He said, quietly, that my answer had not helped.

### E02-021 | The Dismissal and the Box | 1868-07

The dismissal arrived in an envelope thick enough to suggest a substantial argument, though its substance was brief. I had been removed from my professorship. The administration considered my conduct and experiments incompatible with my office. Heller did not attend the final meeting. Kappel brought a packing crate to my room without being asked; he had lined it with old examination papers so that the bottles would not strike each other. Henry had written a note offering to speak for me, then apparently decided against sending it. I saw the torn draft only because a clerk mistook it for waste. I cannot say whether the note would have saved me. I carried the blue ledger myself. Clara insisted the living jars should travel upright. By evening my title remained mine to use, but no door in the university required me to enter.


## Episode 03: The Tower Keeps Its Accounts (1868 to 1877)

### E03-001 | The Tower with Three Dry Rooms | 1868-09

The tower was cheaper than any respectable laboratory and possessed three rooms that remained dry in rain, a virtue sufficient to outweigh its missing stair rail. Lenz tested the upper floor with his boot and refused to carry a jar across it until the beams had been supported. I called his caution provincial. He asked whether I preferred the Queen to arrive on the ground floor by gravity. Clara brought straw, blankets and two pails whose contents were not to be confused. We moved the creatures before the books, the books before my clothes. At dusk the Queen was settled in the least draughty corner, and I discovered that my own bed was damp. I slept beside the heating stove and congratulated myself on having chosen independence.

### E03-002 | The Price of Coal | 1868-11

At the university, coal had appeared in the cellar by an arrangement so invisible that I had never asked who made it. At the tower it arrived by cart, late, wet and at an insulting price. I used the funds saved from an academic dinner jacket and kept the lower room barely warm. The King's appetite diminished when the glass cooled, and the Queen grew less inclined to move. Clara refused to permit further economies on their heat while I possessed money for tobacco. I surrendered a box of cigars with the air of a martyr relinquishing an empire. That evening the King ate again. I recorded the temperature and the change, then made a separate entry for the cigars. Some experiments require a sacrifice of vanity more exacting than any martyrdom.

### E03-003 | The Door That Would Not Lock | 1869-02

Someone tried the tower door during a night of sleet. I heard the latch rise twice, then a boot on the step. By the time I reached the entrance no one was there. Lenz examined the lock the following morning and found it damaged by rust rather than an intruder. I disliked this explanation, for it denied me a suitably sinister enemy. He fitted a new bolt and asked why I kept a lamp burning against the window. I told him it allowed me to observe the tower's surroundings. He said it also advertised that someone was awake inside. We moved the light and installed a small shaded lantern. I did not abandon my suspicion, but for the next week I listened more carefully before naming every sound a persecutor.

### E03-004 | A Letter from Henry | 1869-05

Henry wrote from somewhere beyond my immediate reach. His letter asked after the smaller creatures and whether I had found a way to maintain viable tissue at greater scale. It contained no offer to visit. I began a reply of forty pages and reduced it to four. I sent him observations on the limits of growth but refused the procedure he sought, although I could scarcely have given him one. At the end I added a line asking whether he had recovered from the quarrels of our final university months. I struck it out and wrote instead that the Queen continued to exhibit surprising preferences. He did not answer for several years. I kept his letter under the blue ledger where it left a pale rectangular mark.

### E03-005 | The King Takes a Fall | 1869-08

The King fell from a platform in his vessel after an extravagant display directed toward the Queen. His movements afterward were slow and uneven. I announced that a fall of that scale could not possibly injure him under the circumstances. Clara asked whether he had heard the announcement. We lowered the furniture and spent the next days watching him recover. The Queen kept to the side of her jar facing him; I cannot prove she understood, though the change endured until his gait returned. I installed a narrow partition to prevent future leaps. The King treated the partition as a personal insult and attempted to climb it on the third day. I nearly laughed before remembering that I was responsible for the height from which he had fallen.

### E03-006 | A Paper with No Title | 1870-01

Kappel sent a packet of anonymous notes copied from a withdrawn thesis, without a salutation or his usual green string. The pages concerned the difference between an interrupted process and a destroyed one. In the margin someone had written, 'Ask what restores the pattern.' I suspected Kappel was asking for a publication he could circulate without naming me. I drafted a paper under an invented initial and sent it back with the request that he hide its origin. He replied with one sentence: 'I did not ask you to lie.' I burned the title page and kept the rest. Years passed before I understood that he had given me access, not absolution.

### E03-007 | Wartime Windows | 1870-08

Wagons took the road south through the summer, and every village conversation drifted toward the war with France. Lenz's brother had gone with a unit, and the glassworks had lost two trained hands. My latest vessel could not be delivered. I first treated this as an outrageous interference with science and then saw Lenz reading a letter that had passed through too many hands. We repaired what we possessed instead. I taught him my system for recording the service life of a vessel, and he taught me to mend a chipped rim without pretending it was whole. His brother survived that campaign, though we did not know it then. The delay prevented a risky transfer I had been impatient to attempt. I was not grateful to the war for this benefit.

### E03-008 | The New Empire on Cheap Paper | 1871-02

Clara brought news of the German Empire printed on paper so thin that daylight showed through the ink. She expected me to make an offensive remark and I obliged. Yet she had not come for an argument about emperors. The new postal arrangements might make some scientific correspondence easier; the price of coal had risen again. We calculated accounts while the Archbishop knocked his staff against the glass in the next room. She asked what I proposed to call my private kingdom. I said that I had no wish to rule. The Queen chose that moment to turn her back upon me, and Clara folded the newspaper without smiling. I entered the coal price in the blue ledger beneath a grander heading than it deserved.

### E03-009 | The Queen's Quiet Week | 1871-06

For six days the Queen barely moved. I inspected the light, the air and every part of the vessel I could examine without disturbing her. Nothing accounted for the change. On the seventh day Clara sat beside the jar and read aloud from a botanical catalogue while I pretended to be occupied elsewhere. The Queen approached the glass nearest her voice. I told Clara that the coincidence was meaningless. She agreed that it proved nothing, then stayed for another hour. Over the following weeks the Queen responded to the rhythm of certain voices but not consistently enough to satisfy me. I installed no apparatus. Some observations are ruined by the appetite to turn them immediately into demonstrations.

### E03-010 | The Festival I Did Not Attend | 1872-01

Lenz invited me to his family's winter gathering. I declined because the Mermaid's water was changing color and I could not bear to leave the tower. By evening the color had returned to normal. I could have gone, but I remained with my notebook and a plate of hard cheese. On Monday Clara brought the uneaten end of a cake and said Lenz had saved it for me. I informed her that attendance at festivities was not a professional obligation. She replied that nobody had suggested it was. The cake was surprisingly good. I sent Lenz a small repair instrument in return but never admitted that I had wanted to hear his family quarrel over cards.

### E03-011 | An Inventory of Small Preferences | 1872-05

I drew a table of the six homunculi and what I thought each preferred. The Queen favored particular perches; the King her company; the Archbishop the interruption of his rival; the Devil reflective surfaces; the Ballerina a specific tune; the Mermaid unobtrusive observation. It was an orderly table and therefore almost certainly too simple. Clara added a column headed 'Exceptions.' Within three days we had filled it. The Ballerina sometimes refused the music when the room was cold. The Devil ignored the mirror if the King was unusually active. The Mermaid emerged in full light when no one approached. I hated the added column and preserved it. No society worthy of the name can be reduced to its inhabitants' most convenient habit.

### E03-012 | A Patient without a Name | 1873-03

Reuter invited me to review records of a patient who had repeatedly recovered after periods of apparently profound unresponsiveness. I went by a roundabout route, avoiding people who knew my dismissal. The patient was an elderly man who liked chess and disliked being spoken of as a case while present. Reuter introduced me as an old university colleague, neither defending nor condemning me. I asked the man whether he remembered the intervals. He remembered waking and finding the room changed, but nothing of what had happened between. I left with notes less triumphant than I had hoped. Reuter sent me away with a packet of clean linen for the tower. He had noticed that my cuffs were fraying. This small evidence of attention remained with me.

### E03-013 | The Train Compartment | 1873-10

Lenz and I travelled to collect a repaired optical component. He brought sandwiches and insisted on sitting facing the direction of travel. I mocked his superstition until the movement made me nauseated while he ate comfortably. A child across from us asked whether the glass in our case held a bird. Lenz answered that it held something less cooperative. I found the child delightful until she demanded to see it. At the station we learned that the shop had repaired the wrong fitting. My rage was cold and elaborate; Lenz merely asked for the original order. We returned with nothing, having spent a day and learned that a reference number could save more time than a speech. He wrote the number inside the case.

### E03-014 | The Archbishop Changes Sides | 1874-02

The Archbishop, long the King's adversary, surprised me by standing between the King and a falling piece of miniature furniture. I first thought the gesture accidental. Then he helped push the object against the wall. The King spent the evening beside him rather than beside the Queen. I watched this unlikely truce until the lamp oil failed. Clara urged me not to describe a single cooperative action as reconciliation. I obeyed in writing and disobeyed in conversation. By the end of the month the two had returned to their usual disputes, but sometimes shared a ledge without quarrelling. I made a new observation card instead of erasing the old one. Their history had developed complications inconvenient to a simple allegory.

### E03-015 | The Question of a Larger Vessel | 1874-09

I commissioned a much larger vessel, believing the restrictions of scale might be partly architectural. Lenz warned that its walls would distort observation and its weight would make relocation hazardous. I persisted. When the glass arrived I could scarcely move it through the tower door. For two afternoons we manoeuvred it with padded boards before Clara asked whether I had calculated how we would remove it in an emergency. I had not. The vessel remained empty, a magnificent and expensive monument to incomplete planning. Months later we converted it to a sheltered chamber for a plant culture. It was useful in that modest occupation, though I continued to resent being taught economy by its success.

### E03-016 | The Cold Soup Agreement | 1875-01

Clara discovered that I had not eaten properly for two days. She set soup on my desk and announced that she would stop bringing supplies if I continued treating food as an interruption. I objected that a man might choose his own habits. She agreed and said she might choose hers. We made an arrangement: I would eat before the second evening lamp was lit, and she would not rearrange my experiments without asking. The bargain lasted eleven days before I broke it. Clara left the soup untouched. The following week I appeared at the dispensary to pay a bill in person and ate at her table. She did not mention the agreement. I kept it thereafter more often than I liked to admit.

### E03-017 | The Summer with No Answer | 1875-07

I wrote Henry a new letter about the limits of bodily scale. It took three drafts to remove a paragraph asking whether he had forgotten me. Kappel carried it into town because I had begun to dislike being seen at the post office. No answer came that summer. I interpreted the silence as contempt, then as busyness, then as deliberate caution. None of these interpretations could be tested. I filed a fourth draft, unsent, which contained only a question about his present work and a description of the Mermaid's habits. When autumn arrived I burned the draft but kept the envelope. I was proud of not pursuing him. Pride is a convenient name for a decision one cannot entirely defend.

### E03-018 | The Repairman's Hand | 1876-04

Lenz injured two fingers when a tool slipped against hot glass. The damage was not severe, but for a fortnight he could not perform the delicate work I habitually assigned him. I arrived at his shop with elaborate suggestions about splints, and his wife told me to sit down. Instead I spent the morning sorting orders and wrapping finished goods while she attended customers. Lenz watched from the corner, faintly amused by my inability to tie packages consistently. The next week I returned of my own accord. When his hand recovered, he offered to reduce my outstanding bill. I refused. He had been inconveniently kind to me for years; payment was the one gesture I could make without requiring an explanation.

### E03-019 | The Ledger's Missing Page | 1876-11

I found one page missing from the blue ledger, the page on which I had entered the Queen's first sustained orientation. My immediate suspicion fell upon a visiting instrument seller. Clara pointed out that the binding had worn thin from years of use. Kappel, summoned like a magistrate to a crime scene, found the leaf pressed inside a botanical catalogue where I had used it as a marker. The relief was brief; the embarrassment, more durable. We began copying observations into a second register kept in town. I resented the duplication until a water leak ruined several loose papers that winter. The copy preserved the records. The leaf itself, still bearing the crease of its escape, remained in the first book.

### E03-020 | The Door Left Open | 1877-08

Lenz repaired the upper landing and, for the first time in years, we could carry a chair to the east window without fearing the floor. Clara opened the shutters. The road below was full of dust and the smell of cut grass, not the host of persecutors I had sometimes imagined. She asked whether I intended to spend the remainder of my life watching the world from a tower. I told her that I had plenty of work. She did not disagree. That evening I prepared a small travelling case with space for one vessel, a notebook and the metronome. I did not yet choose a destination. The case stood unopened beneath the window for months, an intention too delicate to be dignified with the name of a plan.


## Episode 04: The World Beyond the Shutters (1878 to 1888)

### E04-001 | The Case Opened at Last | 1878-03

The travelling case stood beneath my window until March, when Clara threatened to use it for her winter linens. I took the train to Munich to examine a collection of botanical preparations, leaving Lenz with instructions for the lamps and Clara with the only list of which homunculus required what. At the station I discovered that the cracked metronome made the case too heavy and removed it. It had become an object I brought to difficult decisions, not an instrument I needed. In Munich I found the collection disappointingly ordinary, but a conservator showed me how to record the movement of light across a specimen without touching it. The method occupied two pages of my notebook. When I returned, the Queen had not suffered from my absence. I considered that reassuring, then faintly insulting.

### E04-002 | The Botanist with Ink on Her Sleeve | 1878-09

Marta Voss had been hired to catalogue a collection that three professors had described as beyond her qualifications. She had done it accurately and corrected their names on half the labels. I met her when she objected to my description of dormant material as inert. She showed me a specimen that had resumed growth after an interval longer than its keeper had expected. I demanded the measurements, and she produced them before I had finished asking. Over luncheon she admitted that she had read an unsigned essay of mine, obtained through a private circle. She disliked its conclusion but praised its method of listing exceptions. I asked whether she would correspond. She said she would if I stopped calling every disagreement provincial. I took her address with an enthusiasm I disguised as professional necessity.

### E04-003 | The Letter in Three Hands | 1879-01

Voss returned my first packet with annotations in black ink, blue ink and a cramped pencil hand that belonged, she said, to a colleague who preferred to remain unnamed. I was tempted to interpret the changes of hand as an elaborate test of my judgment. Clara remarked that three people might simply have shared a desk. The packet challenged my habit of attributing purpose whenever a specimen moved toward a favorable condition. I defended the habit in eleven pages, then reduced the answer to two and supplied the missing observations. Voss replied with a single word beneath a corrected table: 'Useful.' I had once received a similar verdict from Heller. It was disquieting to find myself grateful for it twice in one lifetime.

### E04-004 | The Picnic No One Had Planned | 1879-07

Voss came through Ingolstadt on business, and Clara arranged for all four of us to eat outdoors as if such a thing required no justification. Lenz brought eggs wrapped in newspaper. Voss carried a specimen box and placed it beneath the shade, then proceeded to speak for an hour about village gardens rather than botany. I disliked how swiftly she and Clara agreed that my appetite could not be trusted. Lenz spent most of the afternoon watching his daughter run at the edge of the water. For a moment I envied him the ease with which he could be both craftsman and father. Then the child asked me how a clock knew it was morning, and I was permitted to answer a question more pleasant than anything in my correspondence. Her father said I had frightened her only a little.

### E04-005 | The Mirror Kept Covered | 1880-02

Voss examined the Devil for the first time and asked why a small mirror stood permanently covered beside his vessel. I told her the figure had seemed excessively interested in his reflection. She uncovered the mirror, then covered it again at intervals that prevented him from anticipating the change. Sometimes he approached. Sometimes he attended instead to the King's gestures. She said the mirror might be neither reward nor vanity but a source of unpredictable movement. I found the idea graceless. Clara, to my great irritation, supported it. We designed a more careful observation schedule. I did not relinquish the creature's name or the pleasure of seeing him bow. I did relinquish the conviction that he was performing for himself alone.

### E04-006 | A Copy Sent Without Permission | 1880-10

Kappel sent Voss a copy of an old paper that I had marked private. She thanked him and wrote a criticism so precise that I forgot, for several hours, to be angry. Then I remembered. I went to town and demanded an explanation. Kappel produced my original cover note, which had asked him to preserve the paper, not to suppress it. He said he had trusted her judgment. He was wrong to decide for me, but he was right about her. I sent Voss an apology for the uncertainty over permissions, worded so carefully that it acknowledged no desire to control her reading. She replied that she had already finished the paper and would be glad to argue about it. I stored the new correspondence with the original rather than pretending the offense had never occurred.

### E04-007 | The Prague Clockmaker | 1881-05

I travelled to Prague to meet Otto Faber, whose pendulums were said to resist changes in humidity better than those of his rivals. He listened politely to my complaints about the cracked metronome, then asked why I continued to use an instrument I did not trust. I said I had learned from its failure. He answered that I might now learn from a better one. His workshop smelled of beeswax and brass filings. I bought a calibrated timing device and kept the old metronome as a memento rather than forcing it to perform work for which it was no longer fit. When Lenz examined the new mechanism, he praised Faber's joints before mentioning its price. I was irritated to discover that a purchase could be both extravagant and correct.

### E04-008 | The Letter Recovered from a Fire | 1881-12

A chimney fire damaged Kappel's lodging and scorched the corner of the packet containing my early letters. He brought it to the tower without apology. I expected him to ask that I receive the papers back permanently. Instead he asked which should be copied first. We spent two evenings sorting his rescued books by the strength of their bindings and the value of their marginal notes. He spoke of retirement without complaint, as though a man might leave the guardianship of a library and remain himself. I was unsettled by how readily he described the change. Before going home he said that I should someday find another keeper for the blue ledger. I promised to consider it and did not. It was not his worst prediction of me.

### E04-009 | A Patient Walks Home | 1882-06

Reuter invited me to hear a man describe his recovery from a prolonged illness. The patient arrived wearing a new hat and speaking not of death but of unpaid rent, bad bread and the prospect of returning to work. I pressed him with questions about the interval of unconsciousness. At last he asked whether I would prefer that he remember something dramatic. I said no and realized I had asked him three versions of the same unanswerable question. Reuter walked with me after the interview and remarked that science sometimes trespasses by expecting people to supply the meaning it lacks. We stopped at a bakery. I bought bread for the patient, which was a practical gesture and not the grand moral conversion Reuter might have liked to witness.

### E04-010 | The Queen and the Stranger | 1882-11

For weeks the Queen approached Voss whenever she entered the room, although she had once preferred Clara's voice. I felt displaced and arranged the visits at different hours to see whether light accounted for it. Some of the preference persisted. Voss said she had not won anything and that I ought not to speak of the Queen as though she were a student choosing a lecturer. Clara laughed when I protested. I had created the being, tended her, worried over every change, and now she appeared more interested in a visitor who brought neither food nor warmth. The sensation was undignified and, since I could not make it into an argument, unusually durable. I began recording the Queen's behavior without writing which observer pleased me most.

### E04-011 | Clara's Second Ledger | 1883-03

Clara had begun keeping a second ledger of her own, separate from the copies of my experiments. She recorded the cost of every uncollected prescription and the time spent with customers who could not pay. I asked whether she considered these charitable losses. She said they were obligations to be counted, not erased. When a merchant offered to purchase her shop's debt book for collection, she refused. I thought the refusal imprudent and said so. Three months later the merchant was accused of charging impossible fees. Clara did not claim triumph. She asked me to repair a cracked stool. I did so awkwardly, while she completed an inventory. Her management of an entire social world embarrassed my old conviction that only a laboratory could sustain a complex system.

### E04-012 | The Room in Vienna | 1883-10

Voss arranged a visit to a Vienna laboratory whose director would not have welcomed my name. She introduced me as a private investigator, a title accurate enough for comfort. We spent two days observing preserved cultures and arguing over the distinction between development and mere persistence. On the second night a leak from the ceiling ruined the notes I had left spread upon the lodging-house desk. Voss had kept a pocket copy of the measurements, while I had relied on the dignity of careful handwriting. We reconstructed the tables over lukewarm coffee. When I thanked her, she answered that gratitude would be better shown by making another copy. I did. We remained collaborators because she refused to be made into an admirer.

### E04-013 | A Week of Silence | 1884-05

Voss did not answer a series of letters. I first assumed illness, then offense, then betrayal of confidence. In June a parcel arrived containing pressed leaves and a note that she had been attending her mother, whose sight was failing. She added that scientific correspondence was not her only duty. My reply began with an apology and continued with an account of the Mermaid's seasonal habits. I sent the first half and kept the second, fearing it would look like an invoice for sympathy. She wrote later that a small factual detail might have been welcome. For once I could not determine whether restraint had been tactful or merely another manner of centering my own discomfort. I preserved both drafts.

### E04-014 | The Devil's Reflection Refused | 1884-12

I had spent years using the Devil's reflection as a parlor demonstration for the few visitors I trusted. On one December evening he refused to approach the glass. The King was unusually still; the Ballerina had not responded to her music; the room was colder than I had realized. I warmed the chamber and waited. The Devil approached the mirror the following day, though I do not know which change mattered. Clara said that I had been trying to summon yesterday's personality as though it were a bell. I was cross with her because she had expressed a criticism I had put in my notebook the previous night. I crossed out 'obstinacy' and wrote 'variable state.' Neither term was beautiful, but the second could be tested.

### E04-015 | The Salt Road to Trieste | 1885-08

Voss had arranged for me to inspect preserved marine specimens near Trieste. I went chiefly because the Mermaid's world seemed narrower than the worlds of her sources. At the harbor fish scales glittered on wet boards and the air ruined my appetite. A shipping clerk informed us that our ordered specimens had been sent to the wrong warehouse. Lenz, consulted by post, had packed a sturdy carrying case with compartments that remained dry. We returned with fewer samples than planned and a detailed account of the ones that had spoiled. I presented this as a success of negative evidence. Voss agreed about the record and refused to agree about the journey's cost. She was correct. The Mermaid nevertheless became more active in the weeks after we returned, a coincidence I could not confidently attribute to anything we brought.

### E04-016 | The Strange Case on the Train | 1886-02

Voss had brought a recently published English tale, *Strange Case of Dr Jekyll and Mr Hyde*, and wanted to know whether I found its divided character scientifically useful. I said the author had taken the old difficulty of conflicting impulses and dressed it in a potion. She countered that the story's moral terror depended less on chemistry than on a man discovering he did not govern himself as completely as he believed. I dismissed this as a literary flourish, then spent the rest of the journey remembering occasions when I had chosen pride over an evident practical need. I did not tell her which occasions. I borrowed the book. It travelled back to the tower inside the same case that held my carefully labelled specimens.

### E04-017 | A Printed Accusation | 1886-09

An unsigned notice in a professional periodical condemned unnamed investigators who confused independent life with manipulated tissue. I recognized several phrases from arguments made against me in 1868 and assumed Heller had arranged the attack. Reuter read the notice and asked me to identify a claim it actually attributed to my work. I could not. Voss later observed that generic cowardice is common enough to require no organized conspiracy. I drafted a furious reply and did not send it. The notice remained in my files, folded around Reuter's short annotation: 'No evidence of identification.' It is possible I had been accused by everyone. It is more likely that I had not been accused on that occasion at all.

### E04-018 | The Photograph on the Sill | 1887-04

Lenz's daughter, now a young woman, had taken an interest in photography and persuaded him to bring a camera to the tower. I permitted a portrait of the building, not of its inhabitants. She asked me to stand beside the doorway so that the scale might be understood. In the resulting plate I appeared taller and thinner than I had thought possible. Clara said the camera was an excellent corrective to vanity. I replied that it had made my ears absurd. The young woman offered to try again, but I kept the first print. Years later, when strangers described me as devilish, I suspected they had seen a photograph rather than a demon. The picture remained on the blue ledger's shelf, face inward when I was working.

### E04-019 | The Queen Does Not Perform | 1887-11

Voss brought two visitors whose names I shall not record. They expected to see my creatures perform like clever clockwork. The Queen remained still. The King made a foolish display, the Archbishop objected, and the Ballerina refused her song after the first phrase. I could see disappointment settling upon the visitors. I nearly rearranged the vessels to compel a more agreeable showing. Clara touched my sleeve and I left them where they were. Voss afterward said that I had allowed the creatures a rare privilege: to be disappointing. I told her that disappointment was merely a consequence of bad experimental design. But I had not moved the Queen, and for several days afterward I was privately pleased with the fact.

### E04-020 | A Death with an Address | 1888-06

Kappel died after an illness that allowed him enough time to sort his papers and too little time to reconcile himself to it. His nephew delivered a bundle tied with green tape, including my early notes and the very key he had once demanded back. At the funeral I was introduced simply as an acquaintance. This was accurate and absurd. I had relied on the man for nearly thirty years. Back at the tower I opened his packet and found no final declaration, only a list of pages that ought to be copied before the ink faded. Voss helped me begin the task. I had thought I valued Kappel for his access to documents. The empty place at my table made that explanation unusually difficult to sustain.


## Episode 05: Correspondence with the Unfinished Future (1889 to 1899)

### E05-001 | The New Keeper | 1889-01

Kappel's papers had filled the spare room, and no amount of filing could make him return to claim them. Voss proposed that Clara keep the working copy of the blue ledger at the dispensary while I retained the original. I objected that the shop was not an archive. Clara asked whether my leaking tower was. We agreed upon a register of transfers, each marked with date, owner and destination. The method was tedious, as the best safeguards often are. On the first day I discovered that a report on the Mermaid had travelled in the wrong packet and that Kappel's last copy list contained a correction I had missed. The ledger gained a keeper in the form of a procedure rather than a single man. I disliked this because it was probably wise.

### E05-002 | A Visitor Who Asked About Pain | 1889-07

Reuter visited the tower for the first time. He did not praise the homunculi. He watched the King press against the partition that had been erected after his fall and asked whether the restriction troubled him. I replied that it prevented injury. Reuter said both might be true. We spent an uncomfortable afternoon considering what signs of distress could actually be observed at this scale. Voss proposed recording changes in activity before, during and after environmental disturbances, while keeping the creatures safe. I objected that our interpretations would remain uncertain. Reuter answered that uncertainty was a reason to act cautiously, not a reason to act as we pleased. I did not adopt his philosophy. I did alter the maintenance schedule.

### E05-003 | The Metronome Comes Apart | 1890-04

The cracked metronome had followed me from student rooms to the tower without keeping satisfactory time for most of the journey. Its spring finally broke while I was clearing a shelf. Lenz offered to replace it, but I asked him instead to open the case so I could see where the metal had fatigued. We laid the pieces on green felt, and he showed me the tiny points where repeated strain had done its quiet work. I was tempted to draw a metaphor about men of science. Lenz advised me to purchase a new spring before delivering a sermon. We repaired it, but I never used it again for measurement. It remained on the shelf as a reminder of error corrected, not a shrine to error perpetuated.

### E05-004 | The Woman in the Corridor | 1890-11

Voss sent for me while attending her mother in Vienna. She wished to ask a technical question about a botanical specimen, but the visit chiefly consisted of sitting in a corridor where cups were collected with a clatter at regular intervals. Her mother was growing blind, and the physicians had little to offer. I attempted to describe the difference between lost perception and lost understanding. Voss told me, very gently, that she was not conducting an inquiry. We sat without speaking. Before leaving I repaired the catch on the specimen box she had carried from home. She thanked me for coming. No result was published, and I remember the visit as one of the few occasions on which absence of useful speech was not a failure.

### E05-005 | A New Name on the Packing Case | 1891-05

Anna Lenz, whom I had once seen asking clocks whether they knew the hour, had become competent with photographic plates and inventory records. She labelled a crate of instruments with a code that allowed each item to be matched to its drawing. I told her the system was unnecessarily elaborate. She opened the crate and identified a damaged component before I could discover that the wrong object had been packed. Her father watched me concede the point with open enjoyment. Anna asked whether I preferred to be addressed as Professor or Doctor. I said the former was more historically interesting and the latter presently more useful. She called me Doctor and charged for the improved packing. I paid without bargaining and remembered the child at the river.

### E05-006 | A Night of Melted Snow | 1891-12

Snow slid from the tower roof and blocked the outer drain, sending water beneath the glass-room door. Clara arrived with towels; Anna arrived with a camera she had intended to use for an experiment and immediately put it aside. We carried every living vessel to the dry chamber. The Mermaid's jar was heavier than it looked, and I nearly dropped it when my foot slipped. Anna steadied my arm and told me to pay attention to the floor rather than the specimen. She was right. We lost several loose pages and a box of old labels but no creatures. The following week I insisted upon a new drainage channel. I paid for the work with money reserved for an optical experiment, and did not regret the exchange until the invoice arrived.

### E05-007 | The Theory of a Larger Life | 1892-06

We examined the oversized vessel that had been too large to move through the tower door. Voss asked whether my desire for a full-sized organism came from a scientific need or from resentment that visitors treated my creations as curiosities. I answered that scale imposes genuine physiological difficulties and therefore deserves study. This was true. It did not dispose of her question. We drew two projects on separate sheets: one for conditions permitting greater size, another for recording the creatures' existing activity without forcing them into more human arrangements. I devoted a month to the second. The first remained in a locked drawer. I told myself I had exercised discipline; I also checked the drawer every morning.

### E05-008 | An Unanswerable Question of the Queen | 1892-10

The Queen had begun to remain motionless whenever we approached with a particular set of instruments. She did not behave this way when Clara came with fresh supplies. I suggested she had learned to anticipate interference. Voss agreed that anticipation was possible but asked how we would distinguish it from a reaction to the instruments' odor or shape. We placed harmless objects near the bench and varied who carried them. The results were neither tidy nor meaningless. The Queen appeared to distinguish some circumstances from others, but we could not say by what rule. I was pleased she had become difficult to predict. I was also alarmed by the prospect that she had learned something from my conduct that I had not intended to teach.

### E05-009 | The Letter I Did Send | 1893-03

I had drafted many letters to Henry in the years since his last reply, almost all unsent. This one was brief. I wrote that I remained concerned with living organization, that my smaller creations continued to survive, and that I hoped his own investigations had not brought him undue trouble. I enclosed no technical drawings. Voss examined the envelope, not the contents, and asked why I had waited so long. I told her that serious men should not burden one another with domestic sentiment. She said serious men were perfectly capable of deciding which letters to answer. I posted it myself. No reply came. I do not know whether he received it. I have been tempted to write an entire theory to explain that uncertainty, but it remains only a missing answer.

### E05-010 | The Sound Behind the Wall | 1893-11

A rhythmic tapping began behind the west chamber wall, usually after midnight. I assumed some animal had made a nest. Anna proposed that the newly fitted drain was transmitting movement from the outer gutter. Lenz tapped the pipe and reproduced the sound almost exactly. I was disappointed not to discover an intruder but satisfied to discover a mechanism. The tapping had disturbed the Ballerina's rest, and she had begun refusing music on the following mornings. We wrapped the pipe and shifted her vessel by a hand's breadth. The rhythm ceased and the dancing returned, though I recorded no claim of causation beyond the sequence. Anna asked whether the old professor still believed every peculiar noise was a plot. I said only the interesting ones.

### E05-011 | The Farewell That Was Not One | 1894-07

Clara informed me that she intended to reduce her hours and transfer much of the business to an assistant. I immediately asked whether the tower could still obtain its customary supplies. She looked at me until I understood what I had made of the announcement. She was tired, she said, and wished to spend some mornings reading without a queue at her counter. I congratulated her poorly. On my next visit I brought a chair cushion, having noticed that the one beside the window had gone flat. We drank tea and discussed the weather. When I left, she asked that I continue calling even on days when I required nothing from the shop. I answered that I could not imagine why I should do otherwise. I began doing so the following Thursday.

### E05-012 | The Inventory of Failures | 1895-02

Anna suggested using a photographic record of apparatus damage so that the same weak joints would not be ordered repeatedly. Voss added a category for discarded hypotheses. I regarded this as an unpleasant attempt to make my errors permanent. We spent three afternoons assembling a catalogue of failures: warped vessels, false recoveries, mistaken interpretations of the Archbishop, unrepeatable growth patterns, and purchases whose ambition had exceeded the doorframe. The result was a volume of considerable thickness. Anna noted, without malice, that the book was heavier than the catalogue of published successes. I laughed because the alternative was to argue with a measurable fact. The catalogue proved useful within a month, when it prevented us from repeating an old optical mistake.

### E05-013 | A New Instrument, an Old Bias | 1895-10

Faber offered an improved timing mechanism whose increments could be read more finely than the old instrument. I bought it and immediately claimed that the King's movements were more regular than before. Voss compared the new measurements with the old record and found that I had changed the starting point of each interval. We recalculated the series on one definition. The apparent improvement vanished. Faber, writing from Prague, said a machine cannot cure the experimenter's imprecision. I framed his note beside the new dial, ostensibly for the benefit of visitors. In truth I wished not to forget it myself. I continued to admire good instruments; I ceased expecting them to supply good judgment automatically.

### E05-014 | A Book from England | 1896-04

Voss sent me H. G. Wells's *The Island of Doctor Moreau*. I read it by the east window while rain tapped the repaired drain. The book described a scientist whose experiments made the boundary between humanity and animality a cruelty inflicted upon his subjects. I found the moral arrangement intolerably convenient and the questions uncomfortably well chosen. I wrote a page objecting that the mere power to alter an organism did not settle the legitimacy of doing so. Then I remembered Reuter asking whether the King's partition troubled him, and my page became longer. I told Voss the novel was sensational but not stupid. She replied that this was the nearest thing to literary praise she expected from me. I kept the book, with its corners worn by a wet thumb.

### E05-015 | The Empty Place beside the Piano | 1896-12

Clara could no longer visit often in winter, and the Ballerina had gone several weeks without hearing her preferred tune played competently. Anna offered to learn it. I assumed the creature responded to Clara's manner of performance, not merely the notes. Anna practiced each evening after work until she could manage the passage without hesitating. The Ballerina danced on the fourth attempt. Clara, told of this success, was amused that I had expected her to be irreplaceable in a task she had never wished to own forever. I was pleased the dancer had found another musician and unexpectedly sad that an old arrangement had ceased. I kept Clara's worn music pages on the piano; Anna brought her own copy.

### E05-016 | The London Address | 1897-08

Voss introduced me by letter to Agnes Bell, a translator who helped a small London reading society compare continental accounts of physiology. Bell was unimpressed by reputation and asked for an observation that could be distinguished from its author's self-regard. I offered the case of the Queen's avoidance of certain instruments, with the uncertainties intact. She translated the report without making it sound more decisive. One committee member asked whether my title of Professor was current. Bell answered that a dismissed scholar did not thereby become unable to observe. I had expected to defend myself and found her defense almost embarrassing. Later, over a mediocre supper, she told me she had defended the evidence and not the man. I valued her more for the distinction.

### E05-017 | What the Queen Had Not Forgotten | 1898-02

Anna moved an unfamiliar wooden stand beside the Queen's vessel. The Queen withdrew to the far end, as she had done years earlier when a set of instruments approached. Anna recognized the outline of an old clamp in the stand's shape. We brought in a harmless duplicate and observed the same retreat. Voss warned that similarity of form did not prove a specific memory. I agreed. Still, a possibility had entered the room with the stand: an experience could persist in a creature that I had not trained to preserve it, and its effect could outlast my recollection of the event. I searched the old ledger and found that I had described the original disturbance as trivial. I underlined the word and left it in place.

### E05-018 | The Visit to Clara's Garden | 1898-07

Clara kept a narrow patch of herbs behind her house and had become more interested in the bees than in the tinctures her assistant still sold. I visited on a warm afternoon with no parcel to collect. She asked whether I could identify a struggling plant from its leaves. I made two confident suggestions, both wrong. She explained that its roots had been crowded by the paving stone. We moved the stone together. When I spoke of growing life from seed, she remarked that even an ordinary garden was seldom under its keeper's complete control. I tried to argue; she handed me the watering can. The plant recovered over the next weeks. I wrote no article on the event. I remembered it whenever the phrase 'my creations' came too easily to my tongue.

### E05-019 | The Scale Model of an Impossible Room | 1898-11

I asked Lenz and Anna to examine a drawing for a future laboratory capable of sustaining forms much larger than my present subjects. Jakob measured the stairwell and laughed. Anna made a small paper model of the proposed room and found that the access corridor turned too sharply for the central apparatus. Voss wanted to know what evidence justified the planned dimensions. I had none beyond desire and several incomplete estimates. Instead of ordering construction, I filed the model alongside the failure catalogue. Lenz said the decision was wise, which ruined the pleasure I might have taken in it. The paper walls remained on my shelf, a promise neither abandoned nor yet purchased with other people's labor.

### E05-020 | A Rumor with a Familiar Name | 1899-03

Bell enclosed a clipped report about a man whose attempts to restore life to dead flesh had allegedly ended in catastrophe. The surname was Frankenstein. I had long hoped Henry would continue asking the question we had argued over beneath my university lamp, but a surname in newsprint is an uncertain instrument. I examined the report for dates, witnesses and secondhand embellishments. Voss watched me read it twice and asked whether I meant to write to him again. I said I wished to know what had actually happened. The distinction was genuine, though incomplete. I spent the evening finding Henry's old unsigned drawings and laying them beside my own notes on formation. I could still follow every line. I could no longer be certain I understood the man who had drawn them.

### E05-021 | The News from the Windmill | 1899-06

A second account arrived, followed by confirmation through a correspondent whose prudence I knew. Henry Frankenstein had made a living being from dead flesh. The creature had survived a burning windmill, and Henry himself was alive. I made three entries in the blue ledger: the claim, its sources, and what none of them could establish about the process. The old distinction between assembly and cultivation, argued with a young man over a bird's skull, had acquired a terrible material consequence. Anna asked whether I intended to seek Henry. Voss asked whether I intended to learn from him or use him. I answered the first question by closing my travelling case and did not answer the second. The Queen turned on her ledge as I extinguished the lamp. I had not yet left the tower.


---

**End of permitted chronology.** As of June 1899, Pretorius has news of Henry and has not left the tower to make contact.
