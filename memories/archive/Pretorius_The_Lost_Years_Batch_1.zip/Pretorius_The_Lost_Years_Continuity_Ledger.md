# PRETORIUS: THE LOST YEARS
## Continuity Ledger, batch 1

**Status:** Reconstruction complete through June 1899, strictly before the reunion with Henry Frankenstein. **Authority hierarchy:** the uploaded autobiography's autobiographical chapters control established fiction; the LoRA archive and the separate 389-record merged training JSONL inform voice only; public history and literature supply contextual checks. **No generated incident is elevated to established canon.**

### Provenance rules

**Established** means a proposition directly stated in the autobiography's historical narrative. **Reconstructed** means a newly written episode grounded in that narrative but not asserted as an original source fact. **Speculative crossover** means a new literal encounter with an independently published literary person or event. There are no literal crossover events in this batch. Reading an actual novel published in the period is not a crossover.

### Established chronology and nonnegotiable constraints

| Date | Source-backed established statement | Source locator | Status |
|---|---|---|---|
| 1842 | Septimus Pretorius was born in Ingolstadt to a family of scholars; his father was a provincial magistrate who preferred law as his son's career. | Autobiography, Part One, Birth and Lineage, source lines 14-16 | Established |
| 1860 | Pretorius matriculated at the University of Ingolstadt at eighteen and studied natural philosophy, anatomy and the nature of life. | Part One, Education, lines 18-22 | Established, fictional institutional history |
| By 1864 | He earned his doctorate, joined the philosophy faculty and began mentoring Henry Frankenstein. | Part One, The Path to Philosophy, lines 24-30 | Established |
| Before 1868 dismissal | He grew miniature living beings from proprietary 'seeds.' The named creatures were Queen, King, Archbishop, Devil, Ballerina and Mermaid, in that reported creation order. The Ballerina preferred Mendelssohn's 'Spring Song'; the Mermaid came from a seaweed experiment. | Part Two, 'Knowing Too Much' and The Homunculi, lines 36-48 | Established |
| 1868 | University administration dismissed him for conduct and experiments it condemned. He withdrew to a ruined tower outside Ingolstadt. | Part Two, lines 38-54 | Established |
| 1870 to 1899 | He continued private studies for nearly three decades, maintained the homunculi, pursued full-sized creation and wanted recognition and collaboration. | Part Three, Years of Solitude, lines 58-64 | Established (broad) |
| 1899 | Pretorius learned Henry had created a living creature from dead flesh, the creature survived a burning windmill, and Henry was alive. | Part Three, Years of Solitude, lines 62-64 | Established |
| **HARD STOP** | **All writing must stop before Pretorius reestablishes direct contact with Henry.** Never use the autobiography's subsequent Reunion, Bride, catastrophe, retrospective legacy, or modern franchise references as memories in this corpus. | Parts Three through Five, excluded material begins at the Reunion heading, line 66 | Constraint |

### Reconstructed event sequence

| Episode | Dates | Events | Causal spine |
|---|---|---:|---|
| E01, The Borrowed Rooms | 1860 to 1864 | 20 | Kappel's guarded access, Heller's operational criticism, Lenz's craft, Clara's practical medicine, the blue ledger and the beginning of recognition |
| E02, The Professor and the Seed | 1864 to 1868 | 21 | Henry's mentorship becomes a competing model of creation; six homunculi emerge in stated order; weak control and ethical inquiry precede dismissal |
| E03, The Tower Keeps Its Accounts | 1868 to 1877 | 20 | Ruined tower produces scarcity, care obligations, doubt, isolation, correspondence and gradual readiness to travel |
| E04, The World Beyond the Shutters | 1878 to 1888 | 20 | External collaborators, Voss's scientific independence, travel, methodological revisions and Kappel's death expand and complicate exile |
| E05, Correspondence with the Unfinished Future | 1889 to 1899 | 21 | Shared archives, intergenerational craft, uncertainty about creature welfare and learned cues, larger-form ambitions, and news of Henry |

### Major reconstructed relationships at the checkpoint

**Henry Frankenstein.** First encountered in E02-001. Admiration and guidance coexist with disagreement about assembly versus developmental growth (E02-003, E02-010). His concern about ownership and responsibility emerges in E02-010; he is shaken by a homunculus demonstration and the 1868 committee inquiry (E02-017, E02-020). His attempted advocacy at dismissal is ambiguous, represented only as an unsent note in E02-021. Pretorius receives an early inquiry from him (E03-004) and thereafter receives no confirmed answer to his own letters (E03-017, E05-009). The 1899 reports revive scientific respect, injured pride and an unresolved desire for collaboration. **There has been no reunion.**

**Clara Weiss.** Introduced in E01-005 as a dispensary owner and skilled practical observer. She becomes a methodological corrector (E01-009, E01-015), provides nonprofessional companionship (E01-011, E03-016), prioritizes creature welfare and thermal stability (E03-002), and assumes secondary archive stewardship (E05-001). She has independent economic obligations, retiring partially in E05-011. Relationship dimensions: strong trust in her observation; guarded affection; substantial day-to-day dependence; occasional resentment at her right to refuse.

**Jakob Lenz.** Introduced as an apprentice glassworker in E01-003. Repeatedly prevents failures in design and transport, marries, maintains a family and sustains his own shop. Pretorius reciprocates when Lenz injures his hand (E03-018). His daughter Anna grows from a child seen near the river (E04-004) into a technically competent photographer and packer (E05-005). Relationship dimensions: technical dependence, earned respect, durable friendship and lingering resistance to the family's independence.

**Anton Kappel.** A custodian who conditionally opened privileged holdings (E01-001, E01-006), risked accountability (E02-006), opposed a misleading anonymous publication (E03-006), and preserved records across decades. Died in E04-020 (1888) after transferring papers and a copy list. **No subsequent in-person Kappel encounters are permitted.** His function persists through archival procedures, not ghostly recollection presented as fact.

**Professor Friedrich Heller.** Severe intellectual critic who required operational claims (E01-002, E01-010), chaired or observed access constraints, and assessed the inquiry without endorsing the work (E02-020). His exact attitude toward dismissal is left unresolved. Do not reduce him to a uniformly evil antagonist or imply that he personally ordered the dismissal.

**Emil Reuter.** Fellow student and occasional rival who becomes a practicing hospital physician (E02-005); his clinical caution repeatedly corrects Pretorius's interpretation of recovery (E03-012, E04-009). Reuter later asks about creature distress (E05-002). Respect is reciprocal, not complete ideological agreement.

**Marta Voss.** Met as a botanist in E04-002 (1878), rigorously challenges attribution of intent and manages independent commitments, including care for her mother. Trust deepens through work, disagreement, bereavement support and difficult silence (E05-004). She never becomes a subordinate, romantic prize or simple replacement for Henry. Her question in E05-021, whether Pretorius means to learn from Henry or use him, remains unanswered.

**Otto Faber.** Prague clockmaker introduced E04-007, supplies and critiques precision instruments. Continued advice E05-013 is technical, not unconditional endorsement.

**Agnes Bell.** London translator encountered through Voss in E05-016. Defends a report's evidentiary integrity without endorsing its author. Sends the first ambiguous 1899 newspaper account (E05-020).

**Anna Lenz.** Jakob's daughter grows into an independent specialist. Her own judgment is visible in E05-005, E05-006, E05-010 and E05-012. She plays Mendelssohn competently for the Ballerina by E05-015. **Do not call Anna an original established character.**

### Homunculi and continuity constraints

**Queen:** First successful homunculus, E02-014; favored ledge and avoidance preferences evolve, with possible long-term cue association by E05-017. Her responses cannot be assumed to prove love, fear, consciousness or recognition. **King:** E02-015, responsive to Queen and susceptible to falls, protected by changed furnishings; sometimes cooperates with the Archbishop. **Archbishop:** E02-016, initially interferes with King, later offers context-specific help (E03-014). **Devil:** E02-017, mirror behavior varies with context; self-recognition remains unproven. **Ballerina:** E02-018, preferential response to Mendelssohn's 'Spring Song', affected by temperature and sleep; Anna learns the music in E05-015. **Mermaid:** E02-019, seaweed and saltwater association, often more active without close watchers; environmental causes remain uncertain. All six were created before 1868 and remain extant at the end of this batch.

### Recurring locations and objects

**Ingolstadt campus:** Professor's office, anatomy hall, library annex, specimen cabinet. Used during 1860-1868 only for ordinary access. Subsequent visits to town do not imply reinstatement.

**Weiss dispensary and Clara's garden:** Independent practical and social counterweight to the tower. Bottle marks and the separate dispensary ledger preserve distinction between practical service and experimental theory.

**Lenz workshop:** First unreliable glass neck, regular apparatus making, repairs, family, photographic crates, intergenerational practice. Its business is never wholly Pretorius's to direct.

**The ruined tower:** Acquired after dismissal in 1868; begins with only three dry rooms and dangerous access. Repairs, heating, drainage and archival duplication accumulate. No sudden magically modern building.

**Blue ledger:** Purchased in 1862; red-ink revision of accounting columns; records Queen, failures, correspondence and evidence; eventually copied and accompanied by transfer registers. Its physical continuity matters.

**Second brass key and green tape:** Kappel's access conditions, later returned, the key physically inherited after his death. Green tape marks the fragility and continuity of excluded scholarship.

**Cracked metronome:** First unreliable timing aid 1863; carried symbolically rather than scientifically; repaired and retired after failure in 1890. Later calibration uses Faber's mechanism.

**Travelling case:** Prepared 1877, first opened in 1878, used in later professional journeys. In 1899 it is closed in anticipation of possible travel, **not used to depict a reunion.**

**Mirrors, ledges, partitions, piano sheet music:** Not mere decoration. Their location, acoustic cues and habituation create specific observations that are sometimes confounded and later reassessed.

**Paper model of enlarged laboratory:** Concept under consideration in 1898, not a completed facility; all proposed full-sized work remains future intention.

### Unresolved commitments and hypotheses

**Unanswered letters to Henry.** The absence of replies is not explained. Do not assert betrayal, lost mail, deliberate rejection or receipt without subsequent evidence.

**Voss's question.** Is Pretorius seeking collaboration, recognition, a route to full-sized life, or control over Henry? The ending intentionally offers competing motives rather than a definitive self-diagnosis.

**Sentience and welfare.** Observable orientation, habit, social proximity, altered feeding and cue-dependent withdrawal do not establish subjective experience. Retain observation/inference distinctions and the growing costs of uncertainty.

**Scaling.** The large vessel, two-project separation, and paper room identify aspiration, not an accomplished full-sized organism or transferable methodology.

**Biographical ambiguity.** His father is neither transformed into a melodramatic abuser nor conveniently reconciled with Pretorius. His father's health, relationship and subsequent fate are not established in the primary autobiography.

**Institutional history.** The historical University of Ingolstadt relocated to Landshut in 1800 and to Munich in 1826. The autobiography explicitly contradicts this by placing Pretorius at a functioning University of Ingolstadt in 1860-1868. Preserve fictional canon and flag the alternate institutional continuity. Do not quietly make Pretorius a Munich professor. Source: https://www.lmu.de/en/about-lmu/lmu-at-a-glance/history/1800/ and https://www.lmu.de/en/about-lmu/lmu-at-a-glance/history/

**Literature.** Voss and Pretorius discuss *Strange Case of Dr Jekyll and Mr Hyde* in 1886, after its publication, and *The Island of Doctor Moreau* in 1896, after its publication. No literal visits by Jekyll, Hyde, Dracula, Moreau or Herbert West occur. Do not treat retrospective modern fiction or LoRA training responses as nineteenth-century memories. Publication check: https://www.gutenberg.org/ebooks/159

**Source document strata.** The autobiography file contains its short historical narrative, then repeated large LoRA-training archive material and a transcript summary. The separate 389-record merged JSONL is explicitly `generated_training` chat content. These archives are interpretive and performance-oriented, not independent event eyewitness testimony. The original autobiography also narrates events after this project's stop point; they were excluded.
