# Formative Memories: Four Additional Episodes



*Sixty new autobiographical memories. Events are reconstructed, not established canon. First-person texts retain Pretorius’s self-serving account; inferred psychological interpretations appear only in the separate profile and record annotations.*



## E09: The Faculty of Being Heard (1859-1864)



### E09-001 | The Magistrate's Waiting Room | 1859-09

My father permitted me to sit in his antechamber while he disposed of a quarrel about a millstream. I had brought a notebook on respiration and had every intention of keeping my own company. A miller's widow, Greta Falk, waited opposite me, turning the seam of a glove inside out with her thumb. She possessed a drawing of the watercourse; the man who disputed her claim had arrived with a solicitor and a parcel tied in green tape. My father examined both accounts, asked why one measurement had been taken after rain, and sent them away to obtain a third. I called this an abdication of judgment. He said a magistrate who rushed to pronounce upon two insufficient accounts was not brave but idle. I was irritated to discover that he had listened more closely than I. I still remember Mrs. Falk's glove. I remember less about the millstream, though its particulars were the subject of my lecture at supper.



### E09-002 | The Ink That Wasn't Mine | 1859-12

Mrs. Falk sent a note thanking my father for the measurement that settled her boundary dispute. He gave it to me to file, and I read the sentence in which she attributed the useful question to him. I had, of course, objected first to the original figures, though my objection had been substantially wrong. I carried the letter upstairs and began composing a correction. My father saw the draft when he came for his spectacles. He observed that I had been present and that the examination had occurred, but that I had contributed very little to its success. He did not forbid the letter. He set a fresh sheet beside me, so that I might send it legibly. I burnt the correction in the stove. At breakfast I described the business as unimportant, and he made no reply. For weeks afterward I was excessively precise about the household accounts, as though Mrs. Falk might someday ask me to calculate another boundary.



### E09-003 | A Question Lost in the Gallery | 1860-11

The back benches were crowded, and a visiting lecturer spoke for forty minutes on an animal's supposed obedience to an applied current. I had prepared an objection about the interval between stimulus and motion. I delivered it from the gallery in what I believed was an adequate voice. Nobody answered. Reuter told me afterward that the lecturer could not hear a word over the stove. I repeated the question the following week, standing where the lamp threw my shadow across the demonstration table. The lecturer heard it and disliked it, which was a considerable improvement. Heller, watching from the aisle, remarked that I had altered neither the data nor the argument, merely its delivery. I said an idea has little obligation to be modest when the room is hard of hearing. Ever since, I have preferred to choose my position before speaking. One must not confuse this with a fondness for attention. Attention is the door through which evidence must enter.



### E09-004 | The Two-Minute Objection | 1861-01

Heller offered me two minutes at the end of a practical session to show why a neat table of reactions concealed a variable interval. I had brought eight pages. When the bell rang he closed the notebook on my fingers and said I had been allotted two minutes, not immortality. The students laughed. Reuter helped me reduce the argument to a single sketch and three measurements, although I accused him of reducing a cathedral to a doorway. At the next session I presented the shorter case. Heller kept the sketch. A month later he used it in his teaching without remembering, at least in public, whose hand had drawn it. This was my first practical education in the distinction between being heard and being credited. I became economical when I needed a door opened, extravagant when I wished to ensure no one could later mistake the man who had entered.



### E09-005 | The Demonstrator's Courtesy | 1861-05

A demonstrator repeated my objection about the delayed response of tissue as though it had occurred to him in his bath. I waited until after his audience dispersed to ask whether he remembered our earlier conversation. He remembered it perfectly and declared that ideas belonged to the discipline once spoken aloud. Reuter suggested the fellow may have arrived at the same conclusion independently. I replied that coincidence had acquired remarkably accurate handwriting. For a fortnight I dated every loose scrap and initialled the backs of diagrams. Heller saw the practice and asked whether I intended to preserve the birth certificate of every thought. I answered that I had not yet received the privileges of an established mind and must provide my own witnesses. The initials later proved useful in an entirely different disagreement. I have never found it necessary to explain to the demonstrator why I ceased lending him notebooks.



### E09-006 | A Joke Received as an Answer | 1861-08

Clara found me in the dispensary arguing with Reuter about the difference between an unsuccessful experiment and an incompetent experimenter. She asked whether either of us could distinguish the two before her midday customers arrived. I replied that the incompetent man usually spoke longest. Reuter laughed; Clara did not. A woman waiting with a prescription asked if we were discussing her physician. I could have made an explanation, but instead asked to see the prescribed dose and found it needlessly ambiguous. Clara corrected the label and served the woman. Only later did I discover she had kept my joke and repeated it to her apprentices when they began quarrelling instead of working. She did not credit me, nor did I ask her to. My amusement had done a small service which argument alone could not. There is no dignified scientific account of why I enjoyed that discovery.



### E09-007 | The Price of a Seat | 1862-02

Kappel obtained a seat for me at a faculty dinner where young scholars were expected to eat their vegetables and agree at suitable intervals. Heller's colleague described the physiology of sleep without once admitting that his examples concerned only dogs. I contradicted him between the fish and the roast, with the unfortunate result that the table became interested. Afterward Kappel showed me the seating list. He had placed me beside the colleague precisely because the man was considering an assistant for his laboratory. The offer was withdrawn. I assured Kappel I preferred independence to employment and then spent the following two months borrowing instruments from men who possessed both. I did not apologize at the next dinner. I did begin asking who had been invited, which is a less noble adjustment and therefore one I seldom recount.



### E09-008 | The Ledger with Two Columns | 1862-04

The blue ledger was becoming an agreeable monument to my competence until Lenz asked where I recorded the failures. I pointed to the blank spaces between successful trials. He replied that a blank space looked very like a day on which a gentleman had simply stayed in bed. Kappel gave him a ruling pen and watched with the expression of a man observing a dangerous improvement in administrative practice. We divided the page into what was intended and what had actually occurred. On the first sheet, the right-hand column was disfigured by failures. On the second, I began distinguishing a wrong hypothesis from a spoilt vessel. Soon the ledger became less flattering and more useful. I kept the first page, ink blots and all. I cannot say I welcomed correction. But I found myself less anxious about the next experiment when I knew precisely how the previous one had offended me.



### E09-009 | Wine at Clara's Table | 1862-08

Clara set a bottle of ordinary red wine beside the bread and announced that nobody would discuss an experiment until the soup was finished. I agreed, not wishing to seem a barbarian in a lady's house. Reuter spent the meal describing an elderly patient who stole pears from his own orchard because he no longer recognized its new owner. Lenz told a story about his brother's wedding. I knew nothing of weddings, and the pears seemed to invite a theory of possession, which Clara prohibited with a raised spoon. When the others left she said she enjoyed a room in which I could occasionally be a guest rather than a professor. I replied that guests were dreadful things, always requiring more wine. Nevertheless I began reserving one evening a month for her table. When an experiment threatened it, I grew unusually industrious during the preceding afternoon.



### E09-010 | The Lining of the Black Coat | 1862-11

My father sent me the name of a tailor who would alter a serviceable black coat. He did not offer to pay for it. The cloth was excellent, though the lining scratched my neck and one sleeve hung lower than its fellow. I accused the tailor of making philosophical judgments about my posture. Lenz inspected the seams and showed me that the coat had belonged to a taller man who bent forward when working. The tailor altered it twice without charging for the second visit. At a university reception I heard someone call the coat theatrical. I discovered that the word could be employed as praise by those who intended it as insult. My father saw me in it at Christmas and asked whether I had been appointed to a funeral. I said I wished to look as grave as the conclusions I was expected to defend. He laughed, unexpectedly. I wore it until the cuffs shone.



### E09-011 | A Man Who Could Count | 1863-02

Reuter ruined a week's work by confusing two bottles whose contents had settled to the same pale color. I expected a confession, perhaps a satisfying evening of reproach. Instead he made a list of everything we could still infer and put it beside the stove. The best conclusion was modest: we had no result. Heller read the list and praised Reuter's accuracy. I protested that accuracy without discovery was clerical virtue. Heller asked how much of the previous week's work I had privately hoped to count as a success before the bottles were checked. I answered with considerable dignity and a number I later reduced in the blue ledger. Reuter had the decency not to observe the revision. From that winter onward, I could be intolerable about method even when the method prevented me from being impressive. It was an expensive preference, but it was mine.



### E09-012 | The Unsent Recommendation | 1863-05

Kappel offered to write a recommendation for a stipend that would pay the rent and spare me a second winter without proper heating. The form required a statement of character. He read aloud the phrase 'obedient to instruction' and waited for me to object. I obliged. For an hour we altered the sentence until it said I completed assigned work but disputed its assumptions. My father, asked to countersign my application, returned it with a note that the second clause would cost me the stipend. It did. Kappel retained the draft in his cabinet and found me other temporary access to the instruments. I declared the lost money insignificant. That evening I counted what remained in my purse twice. Pride has always been more agreeable when someone else supplies the coal; that fact has never persuaded me to surrender it.



### E09-013 | A Dish Returned Clean | 1863-08

A dish Clara had lent me returned smelling of preservative. She detected it before removing the wrapping and deposited the article in my hands as if it carried a charge of treason. I offered to replace it. She demanded that I clean it properly and bring it back myself. When I returned, she was treating a child whose mother could not pay. I waited with the dish for nearly an hour while Clara worked. Only afterward did she inspect the glass and accept it. She told me a gentleman's offer of money could not restore the hour another person must spend correcting his negligence. I considered a formidable reply and discovered I had none worth making. I began keeping two sets of glassware, one for the laboratory and one for Clara's table. She never thanked me for this elementary separation, and her failure to do so was entirely justified, a judgment I did not express to her.



### E09-014 | The Question Withheld | 1864-02

Before the defense Heller arranged a rehearsal at which the faculty's most unpleasant questions were to be asked in advance. He turned my thesis over and asked whether the most elegant hypothesis might be false for an exceedingly dull reason. I had a reply prepared, elaborate enough to silence a bishop. Then I saw his pencil resting on a table of intervals whose apparatus had shifted in cold weather. I withheld the reply and asked for the measurements. Reuter looked relieved; Heller looked almost disappointed. We repeated the table and lost a pleasing symmetry. At the defense I presented the uglier figures without explaining how recently I had ceased preferring the handsome ones. My silence had been tactical at first. The corrected table was better evidence. Both facts remain true, however much biographers prefer their heroes to grow virtuous at a single sitting.



### E09-015 | The Empty Audience Book | 1864-07

After my appointment I placed a register beside the office door for students who wished to attend a weekly colloquium. On the first Thursday two names appeared, one a false signature evidently supplied by Kappel, the other a student who wanted permission to leave early. I prepared the entire lecture nonetheless. On the third Thursday there were seven listeners. I had abandoned the register and begun speaking in the corridor before the session, disputing Heller's latest proposition loudly enough that students followed to hear whether one of us might draw blood. Heller later observed that controversy had become my advertising department. I replied that the university's own notices were less informative. Once the attendance improved, I stopped quarrelling at the doorway quite so often. I retained the habit of starting with a provocation. It was reliable, unlike institutional announcements, and much less costly than printing handbills.



## E10: The Cost of Possession (1864-1868)



### E10-001 | The Corrected Diagram | 1864-11

Henry returned the anatomical drawing I had lent him with a correction in red ink and a paragraph in which he carefully assured me that his alteration did not detract from the general argument. It did, of course, and I told him so. He looked miserable until I asked whether he had tested the new relation on another specimen. He had brought measurements in his pocket. I kept him until the caretaker called closing time and sent him away with three more drawings, each containing an error I had deliberately left in it. The following week he identified two and defended the third because the evidence supported my original version. I admired that defense. I also disliked the speed with which he was learning to dispute me. I had wanted a pupil who would exceed the syllabus. I had not reflected upon the inconvenience of his doing so in my presence.



### E10-002 | The Wrong Kind of Apology | 1865-01

I corrected Henry sharply before six students after he confused the cessation of movement with the cessation of organization. He returned the next week having rewritten his argument, yet he would not speak. I asked whether the problem was his new evidence. He said he did not intend to be made an exhibit twice. Heller, who had overheard this, advised me to learn the difference between testing a thesis and testing a man's willingness to be humiliated. I disliked his formulation and told Henry he could conduct the next discussion himself. He did so with infuriating seriousness and surprised the room with an objection to my own lecture. I let it stand. Later I told him he had behaved quite competently. I did not apologize. He returned to office hours, and I made a practice of reserving certain corrections for the walk afterward. It was not gentleness. I wanted him thinking in my presence rather than guarding against it.



### E10-003 | The Poorhouse Petition | 1865-07

Reuter brought a request for a practical lecture at the poorhouse. The superintendent wished us to demonstrate new principles of circulation and had offered living residents as convenient examples. Henry was delighted by the prospect of cases not confined to anatomy books. Clara asked who had consented, and Reuter answered that the superintendent had signed the invitation. She placed it beside a patient's unpaid bill and inquired whether either scrap of paper was the patient's own hand. I began to object that we were discussing demonstration rather than injury. In the end I went to the poorhouse with a blackboard and no instruments. Henry was disappointed; the residents asked better questions than the superintendent. I did not abandon the conviction that knowledge often demands intrusion. At my next lecture I left the rear door unlatched. Two listeners went out during the introductory remarks. The others stayed and argued.



### E10-004 | An Account Against the Wall | 1865-10

Lenz arrived with an invoice and refused another promise of payment in the form of future scientific fame. My new laboratory required glass joints he could have sold to paying customers, and his marriage had not abolished the cost of coal. I said I had invested in his skill. He asked whether he might invest my admiration at the baker's. Clara, who had accompanied him, said nothing. I sold an engraved instrument I seldom used and paid two-thirds of the account. Lenz gave me a further month for the balance, but he no longer accepted orders without written terms. I called his policy officious. He continued supplying the finest vessels I could obtain. To this day I distrust a man who asks for blind faith in a partnership. I also resent being reminded that the distrust was taught to me by a glassblower.



### E10-005 | The Lecture That Returned in Print | 1866-02

A pamphlet from another faculty reproduced an argument from my January lecture, including a mistaken spelling of a Latin term that had survived in the written notes. The author made no mention of me. Henry demanded that we accuse the man at once. Kappel advised a private inquiry; Heller suggested the error might have passed through students' notebooks without deliberate theft. I wrote a devastating letter and left it in my drawer. Then I prepared a corrected version of the argument and had copies deposited under my name. The unauthorized author published again two months later, this time with an awkward acknowledgment. I considered that partial justice. Henry asked why I had not sent the accusation. I replied that I had preferred an enduring record to a moment's revenge. I neglected to mention the evenings I had spent imagining the revenge in gratifying detail.



### E10-006 | The Cardboard Curtain | 1866-05

Henry observed an early growth preparation and immediately began offering improvements to the apparatus. I was pleased for the first ten minutes and exasperated thereafter. He leaned over a vessel during a phase when temperature mattered, and I snatched his sleeve away before he touched the glass. He called my alarm unreasonable. I placed a cardboard screen between the observation table and the doorway and insisted that everyone entering announce himself. Henry said I had turned science into theatre. 'Yes,' I told him, 'and now I shall decide who steps upon the stage.' The screen remained after he departed. It kept drafts from the vessels, which was useful, and curious eyes from my failures, which was more useful than I cared to say. The screen remained when we no longer needed its protection from drafts. I had Lenz paint its outer face black.



### E10-007 | The Unsigned Calculation | 1866-08

Henry left a calculation among my papers showing an alternative relationship between the mass of a living preparation and the time required for its recovery. I found an error in the last line, corrected it, and used the amended figure in a private discussion with Heller. Henry overheard enough to believe I had adopted the result without naming him. He was correct. I told him that a student's idea becomes part of his teacher's work when the teacher makes it serviceable. He asked whether the same rule would apply when the student proved the teacher wrong. I had no satisfactory answer ready. That evening I added his initials to the page and left it where he would find it. He never thanked me, and I never repeated the performance. My admiration for his courage did not lessen my appetite for ownership. Both continued to grow.



### E10-008 | A Door Measured Twice | 1866-11

Kappel warned me that a committee member had begun asking about deliveries to the private rooms. I accused him of enjoying the role of sentry. Clara had heard a second rumor from a supplier, one concerning not the apparatus but the safety of our sealed vessels. I measured the room doors, arranged for a second lock, and composed a statement about harmless botanical investigation. It was accurate as far as it went and designed to make further questions appear unnecessary. When Kappel saw the statement he said I had managed to write the truth so that nobody could find it. I admired the description enough to repeat it later as a joke. The lock deterred visitors and delayed Lenz one cold morning while a vessel overheated. We installed an emergency latch. Secrecy had protected my work and endangered it within the same fortnight. I kept the lock.



### E10-009 | The Vessel That Would Not Answer | 1867-01

A preparation gave no coherent response for nineteen successive observations. I had begun speaking of it to Lenz as though the vessel were deliberately withholding consent. Clara asked whether the heating schedule had changed. I replied that the schedule had not changed and produced my ledger as proof. She pointed out that I had recorded intended temperatures rather than those taken at the glass. We measured again and found a difference sufficient to ruin my interpretation. I scraped my proposed account from the slate and ordered another week of observations. The preparation's behavior altered after the correction, though I could not prove that the correction alone caused it. I remember Clara's forefinger on the wrong column of the ledger. I purchased a second thermometer for Clara to read and was disagreeably attentive whenever its figures differed from mine.



### E10-010 | A Queen Without a Court | 1867-03

After the first coherent response and before I had cultivated the others, the Queen occupied a small platform alone. I placed two objects where she could choose between them, intending to test a preference for height. She moved neither. She stood at the far edge with her back to me while I made increasingly persuasive adjustments. Lenz suggested that my arrangement resembled a trap. I laughed, then moved my hands from the vessel and waited. She crossed to the lower object when she was no longer under my shadow. I wrote 'avoidance of overhead obstruction.' Clara wrote 'possibly of you' in the margin. The distinction was not resolved. I have always enjoyed exercising command. My first sovereign subject made the enjoyment more interesting by failing to obey, and I grew absurdly eager to understand the terms of her refusal.



### E10-011 | The Borrowed Royal Title | 1867-05

Henry asked why I called the first creature a Queen when she possessed no subjects. I answered that royalty preceded its court in numerous European histories. Clara suggested that I wanted her disobedience to look ceremonial. Henry smiled too readily. To settle the matter I placed a small paper throne in the vessel and watched the Queen disassemble one arm of it. I was delighted, an inconvenient admission since my hypothesis had been insulted in miniature. Henry took the broken arm home to sketch its joinery and returned it with a note about leverage. I kept the note and not the throne. A name can be an observation, a hope, or a demand imposed upon something that has not agreed to bear it. I persisted in calling her Majesty. She continued to behave as if the title conferred no obligation whatever.



### E10-012 | The Servant Who Saw Too Much | 1867-09

A porter found a broken crate bearing the markings of Lenz's workshop and asked what sort of glass required so much straw and such nervous instructions. Kappel told him it was fragile research material. The porter asked whether fragile research material ordinarily seemed to be knocking at its own box. The sound was a loose wooden cleat, as we discovered when the crate was opened; the story had already acquired a heartbeat by the time it reached the porter's friends. I was furious that a stupid accident should be more persuasive than three years of careful work. Kappel proposed admitting a neutral observer to dispel suspicion. I refused. Each alternative offended me differently: secrecy encouraged legend, publicity endangered control. I chose control. When the story reached the faculty corridor, the crate had acquired a second knock and a small creature that I had never grown.



### E10-013 | The Second Set of Figures | 1867-11

I prepared one table for scientific use and another for a prospective patron, removing the damaged observations from the second because they would require more explanation than the fellow could bear. Henry discovered the discrepancy and asked whether a result made prettier for money remained a result. I replied that I had omitted noise, not evidence. He laid the two sheets side by side and pointed to a small irregularity that appeared in three of the supposedly noisy readings. Clara examined it, then asked for the original notebooks. We reinstated the figures. The patron saw both versions and declined to support us. I cursed Henry's delicacy and Clara's stubbornness. A fortnight later the irregularity helped us detect a recurrent fault in the apparatus. I sent Henry a copy of the revised table without comment. He wrote 'I see it' on the back. I have retained that scrap longer than the patron's name.



### E10-014 | The Private Invitation | 1868-03

Heller came privately rather than sending for me. He had heard descriptions of the miniature beings and wished to see evidence before the faculty was obliged to act upon rumor. Henry urged me to admit him. Clara said the conditions could be arranged if Heller agreed to observe without disturbing the vessels. I prepared three drafts of an invitation. Each seemed to surrender something to a man who might afterwards vote upon my work. In the end I showed Heller selected records and declined to open the inner room. He examined the curves and asked whether the living forms could choose not to be examined. I called this a moral question smuggled into a technical visit. He said technical questions frequently acquire occupants. We parted without an agreement. I still wonder whether a demonstration would have altered his conduct. That is not the same as wishing I had given him one.



### E10-015 | A Request for Reconsideration | 1868-06

The committee had heard its witnesses by June, though it had not yet pronounced sentence. I was allowed to submit a statement of reconsideration. Kappel brought me the official form, two pages of ruled paper, and advice to say that the observations were incomplete and the circumstances regrettable. I wrote that they were incomplete because life itself was not finished and that regret would not improve a measurement. Heller, who had come to collect another document, read the page with a tired expression. He said that I had once been capable of winning an argument without forcing an enemy to lose his dignity. I asked whether the committee had extended me that courtesy. He did not answer. I filed the statement. For many years I told the story as one of heroic refusal. Sometimes I remember the unused sheet Kappel had left beneath my hand, and that I might have written something else without falsifying a single fact.



## E11: The Use of Other People (1869-1877)



### E11-001 | The Coat on the Nail | 1869-01

My professorial coat hung from a nail in the tower's stairwell because the damp made a wardrobe an architectural joke. I had worn it during the hearing and would not relinquish it merely because the university had reclaimed its keys. Clara found the lining spotted with mildew. She said she would have it dried and patched; I said the coat was perfectly serviceable. Lenz pointed out that the shoulders had begun to smell like a neglected cellar. I gave it over with a ceremony of offended dignity. Clara returned it three days later, the cuffs repaired with thread slightly darker than the original. At a time when every other article seemed to have changed its address or its owner, I found the coat in the same place each morning. I called this discipline. Clara called it a curious attachment to a poor nail. Neither description accounts for the fact that I put it on before answering official letters.



### E11-002 | A Letter without a Title | 1869-07

Henry's letter had arrived in May. I had answered the technical question it contained within a week and spent another six drafting a second letter that would make him understand the larger offense done to me. Kappel visited with new paper and asked whom I intended the second document to persuade. I said Henry deserved to know how the university had punished success. Kappel asked why I had written the word 'witness' four times. I crossed it out three times and sent only the technical correction. I have never discovered whether Henry received that answer. The longer letter remained in the drawer beside his youthful anatomical sketches. I preferred to consider the correspondence an unfinished scientific exchange. The drafts suggested another possibility, one so tiresomely personal that I bound them together and labelled the packet 'administration.'



### E11-003 | A Debt in Small Coins | 1869-11

Lenz came to fit a glass valve and found me counting copper coins beside an untouched dish of potatoes. The university stipend had ceased. Two patrons who promised sympathy had failed to send payment. He set the valve in place and gave me a bill with the date left open. I objected that I could pay for honest work. He replied that he knew this, which was why he was willing to wait. Clara arrived later with coal and an account she refused to describe as charity. I insisted upon signing every debt in the blue ledger. They signed as witnesses, rather as though I were founding a bank. I repaid the sums, not always promptly. Years later when younger men proposed arrangements based solely upon mutual enthusiasm, I demanded a date, a price, and a means of leaving. Trust had reached me through a bill that nobody was in a hurry to collect.



### E11-004 | The Chair at the Window | 1870-04

I set a second chair beside the east window for Kappel's visit, though the old man seldom stayed more than half an hour. He failed to come one afternoon and then another. I left the chair in its place because it held a stack of books rather well. On the third Thursday I found myself saying aloud that his remarks about the arrangement of my index were wrong. The Queen looked up from her ledge and resumed her occupations. There was no harm in speaking to one's specimens, provided one did not mistake a movement for comprehension. When Kappel finally arrived, suffering from a cough that made the stairs laborious, I began my argument before he had removed his gloves. He asked for tea. I made it badly and was rewarded with a criticism of the leaves. It was a satisfactory hour. The chair remained by the window long after his departure, a convenience which I continued to attribute to the books.



### E11-005 | The Supper Given Away | 1870-11

During a lean month I preserved enough money for lamp oil by economizing on supper. Clara discovered this when she found bread hardened beside the sink and my hands shaking while I tried to set a stopcock. She said I was unfit to handle delicate glass until I had eaten. I accused her of treating me like a patient; she replied that patients occasionally possessed the sense to follow instructions. Later that evening a farm boy brought a parcel of food from Lenz's household and refused a tip. I gave him my portion of cheese for the road, then regretted it before he reached the gate. I ate the bread and preserved the lamps. There was no nobility in the transaction. The following day my hands were steady and the experiment behaved. I began keeping provisions near the workroom, which I represented to visitors as a contribution to experimental reliability rather than obedience to Clara.



### E11-006 | A Name Lost in the Lists | 1871-04

Reuter asked me to inspect a series of records from men returning wounded after the war. One young assistant had been known to him by a nickname, yet the hospital's transfer lists had entered three different spellings of his name. The man's injury was visible; his subsequent whereabouts were not. I argued with the clerk over the mistaken initials until he permitted us to copy the surviving records. We located the assistant at another infirmary two days later. Reuter called it good fortune. I called it a victory over defective classification. The man himself was more interested in finding his spectacles than in our triumph. Clara supplied a pair from a drawer of abandoned possessions. I saw how an error in a ledger could turn an identifiable person into an administrative absence. The blue ledger acquired a separate index for those who handled or cared for my creatures. I did not call it sentimental.



### E11-007 | The Queen's Evening | 1871-11

After the Queen's summer quiet spell, I began checking her platform before extinguishing the final lamp. At first I did so to determine whether her preferred position varied with the fall of light. One evening Clara watched me move the small screen, warm the outer glass with my palm, and place a scrap of bright cloth where the Queen had once selected it. 'You always do that in that order,' she said. I had not noticed. I replied that established methods deserve repetition. Clara asked whether I had tested another order. I said there was no reason to disturb a successful arrangement. The Queen settled near the cloth. I recorded nothing in the scientific column that night. What had begun as a control condition had become a ceremony whose interruption made me impatient. I retained it because the little creature appeared to prosper, not because I wished to be required at a particular hour.



### E11-008 | A Child with the Wrong Question | 1872-04

Lenz's little daughter was permitted to see a drawing of the King, not the actual glass vessel, since her father believed my laboratory unsuitable for children. She asked why the King was made so small. I described the advantages of observing life within controlled limits. She asked why he could not come out. I explained scale, temperature, and the dangers of a careless world. She considered this and said that a bird kept in a narrow cage might also be easy to observe. Her father told her not to be rude. I assured him I had been insulted more intelligently by older people. That evening I drafted a plan for a room-sized enclosure and found the expense intolerable. I put the drawing away. For some months thereafter I found myself staring at the glass rather than through it. It would be inaccurate to say the child's question changed my convictions. It did alter the location at which the discomfort appeared.



### E11-009 | An Invoice for Silence | 1872-12

Mathilde had completed a small private impression of my experimental notes. She offered to omit the shop's mark from the final copies if I paid for the additional work. I asked whether secrecy carried a tariff. She said so did paper, type, and the risk of explaining a mysterious order to a magistrate. Kappel, examining a proof, suggested that a few copies be given to credible witnesses rather than hidden in cupboards. I disliked the notion that I needed witnesses and ordered twelve extra copies. Mathilde kept one sealed in her shop, with a date and a list of corrections. I objected to her retaining my work. She replied that a printer who cannot prove what he printed is a convenient scapegoat. Years later I would say that no university deserved to control my name. When a date was disputed years later, Mathilde produced her sealed proof without troubling to look pleased.



### E11-010 | A Patient's Complaint | 1873-05

The patient whose unusual periods of insensibility had interested me returned while I was visiting Reuter. He had become quite recovered and wished to know why a stranger had been shown particulars of his treatment. Reuter explained that I was a scientific consultant. The patient asked whether this entitled me to write about his body. I assured him the notes bore no name. He pointed to his occupation and age, which narrowed the possibilities in the town to perhaps three men. I had regarded anonymity as a mechanical matter of removing letters. Reuter asked me to correct the report before circulation, and I did, though I resented the time. Afterward I removed occupations from other case notes where they contributed nothing to the phenomenon. I remained convinced that useful knowledge ought not perish for want of access. I removed two unnecessary particulars from the next report. The pen nearly tore the page where I pressed too hard.



### E11-011 | The Parcel Not Opened | 1873-11

A parcel marked with Kappel's hand arrived damp and partly crushed. I assumed it contained another catalogue of obscure dissertations and left it under the stairs while I dealt with a failed preparation. Three days later Lenz used the box to prop open a door. Kappel arrived and asked whether I had read the letter within. It concerned an offer of privately held instruments whose owner would accept a visit only before the end of the month. We had missed the opportunity. I accused the rain, the messenger, and Lenz's mechanical ingenuity. Kappel asked why none of them had prevented my opening the parcel. I dislike questions which have only one answer and are therefore disguised accusations. I thereafter sorted letters by the sender's handwriting before attending to their scientific subject. Some senders mattered because of their knowledge. Others mattered because they would be offended, or absent, if neglected long enough.



### E11-012 | The Archbishop's Place | 1874-06

Mathilde returned to observe the little Archbishop, who had recently surprised us by protecting rather than obstructing the King. She wanted a clean account of the change for the next impression of my notes. I offered a theory of rank and allegiance. Clara remarked that the Archbishop had stood where the strongest current of warm air entered the vessel, and that his position may have had nothing to do with the King. We arranged another observation and found that both explanations fit some of the movements. Mathilde set the paragraph with the words 'cannot presently distinguish.' I ordered them removed, then restored them when she asked which experiment would permit a stronger claim. I liked the Archbishop better after that. Whether he possessed loyalty, preference for warmth, or merely a talent for deceiving me, he had earned his place in the account without requesting permission from my theory.



### E11-013 | The Door after Supper | 1875-02

Clara had negotiated our arrangement about regular meals in January. I resented the suggestion that I required management and agreed to a fixed supper chiefly to end the discussion. A month later she failed to arrive at the appointed hour. I cooked an egg, burnt it, and decided not to consider the matter further. When she appeared late, having attended a difficult birth in the village, I greeted her with an unnecessarily elaborate complaint about punctuality. She asked whether I had been worried. I said I had merely wished to prevent waste. She ate the better part of the bread, then fell asleep in the chair for ten minutes. I covered the lamp because the light troubled her. On waking she noticed and smiled, which was most irritating. I have never liked to be caught providing comfort; it encourages the recipient to expect a repetition. Of course I covered the lamp again when the occasion arose.



### E11-014 | The Hand That Would Not Settle | 1876-03

Lenz's hands trembled slightly after a long day at the furnace, and I noticed it while he attempted a delicate repair. I asked whether he had been drinking. He showed me the blister beneath his thumb and suggested that I try holding the hot rod myself before diagnosing his habits. Clara bound the hand. We postponed the work. At the next visit I brought a padded grip devised from cork and cloth. It was a poor contrivance but useful enough that he kept it. He thanked me with a joke about my becoming an apprentice at last. I replied that necessity had forced the descent. I did not inquire whether the grip lessened his pain; I watched his fingers while he worked and could see that it did. In my notebooks I recorded the alteration to the instrument. I did not record the reason I had designed it.



### E11-015 | The Invitation I Kept | 1877-11

After the late summer when I had finally allowed the tower door to remain open to visitors, invitations became a nuisance of surprising frequency. Lenz asked me to a family supper; Clara enclosed a note that no specimens would be discussed at the table. I wrote a refusal based on a perfectly real series of observations. Before sending it I found an old invitation from five years earlier among the bills, its corners worn by repeated handling. The experiment was not time-sensitive. I attended the supper with a bottle of gin I considered a respectable offering and discovered that Lenz's daughter had become quite opinionated about my manners. She asked why I always arrived wearing a coat suitable for an execution. I told her it improved the appearance of a happy gathering by contrast. She laughed. On returning to the tower I filed the invitation with correspondence rather than accounts. I laid the invitation among Kappel's letters, though it contained no argument or observation at all.



## E12: The Objects That Outlived Their Explanations (1888-1898)



### E12-001 | The Brass Key after the Funeral | 1888-07

Kappel died in June. In July Voss brought a small box containing the brass key with which he had once opened the cabinet of rejected work. The lock had been replaced years before. She asked whether I wanted the key for my papers or whether she should return it to the estate. I said the object was obsolete. She laid it on the desk while we discussed cataloguing his surviving notes. After she left I tried the key against the tower drawers, an activity with no conceivable scientific value. It fitted none. I wrapped it in a square of paper and wrote his initials upon the outside, though the paper already bore his handwriting. For weeks I was impatient with people who used the word 'loss' in my presence. I did not lose Kappel through carelessness. The key remained in the upper drawer. I seldom open that drawer without checking that it is there.



### E12-002 | The Friend at the End of the Table | 1889-03

Clara and Voss arranged Kappel's papers in the east chamber. They had divided his correspondence into subjects, dates, and matters which could not be reconciled by either. I objected to the third category as slovenly. Voss presented a letter in which Kappel described me as exacting but generous with time I did not think belonged to anyone else. Clara laughed at the accuracy of it. I demanded to know why he had not told me this while alive. She said he had tried repeatedly. We read no more of his personal observations that afternoon. Instead I asked to see his old catalogue, the one with corrections made in three shades of ink. I could recognize the years of his hand by the pressure of his pen. The two women left the third category in place. I never again insisted it be emptied merely to satisfy my need for a clean classification.



### E12-003 | The Visitor's Second Glass | 1889-10

Reuter came with questions about fatigue in the small creatures and departed before supper. I had poured two glasses of gin, expecting that the argument would last longer. Voss arrived to collect notes and found me contemplating the untouched second glass. She asked whether I wished company. I told her I already possessed a rather demanding household behind glass. She sat anyway and spent half an hour reading quietly by the window while I annotated a table. We said almost nothing. When she rose to leave I realized I had reached the end of the table and begun writing in the margin. I offered her the second glass. She declined and asked for tea instead. The gin remained on the tray until morning. I had long said that conversation was the principal value of company. When Voss came the following Thursday, I had set out the teapot before I heard her on the stairs.



### E12-004 | The Correction Not Sent | 1890-01

Voss sent a manuscript in which she challenged an interpretation of the Mermaid's responses to changing salinity. I drafted a reply demolishing four minor errors and avoiding the central objection. Mathilde arrived for corrected proofs, read the first page at my invitation, and asked why Voss would be persuaded by criticisms she had already conceded. I said scientific debate requires that all errors be examined. Mathilde pointed to the untouched final paragraph. I rewrote the reply overnight, conceded that Voss's explanation fit the available observations, and requested a new trial. In the morning I considered restoring the original opening, which was immeasurably more elegant. I posted the shorter letter. Voss replied with a proposed experiment rather than a defense. There are colleagues whose agreement I value because it signifies admiration. Her disagreement was valuable for the more inconvenient reason that it continued to produce work.



### E12-005 | The Things in My Pockets | 1890-08

Clara emptied the pockets of my coat before giving it to Lenz's wife for repair. Out came a broken measuring rule, a wax seal, two cigar ends, a folded shop bill, and a scrap on which the Queen's movements had been sketched in hurried figures. Clara regarded the collection as evidence that I was developing into a travelling rubbish cabinet. I told her it represented a portable scientific archive. The rule had once belonged to Kappel, the seal to Mathilde's early edition, and the bill carried Lenz's characteristic spelling of my name. I could have discarded all of them without compromising a single experiment. I put them back after the stitching was finished. At a later date I began using a small tin for the scraps, which was a concession to fabric rather than memory. My pockets have never been especially economical.



### E12-006 | The Apprentice's Own Signature | 1891-06

Anna delivered a newly repaired joint accompanied by her father's bill. The glass was sound, but the invoice bore a set of alterations in a hand I did not recognize. I crossed them out and marked the page for Jakob's approval. Anna returned the bill the next morning with the same figures, now signed in full. She explained that she had made the joint and had no intention of being paid through someone else's reputation. I protested that I had known her since she was scarcely tall enough to reach the bench. She replied that neither of us ought to be charging for work done at that height. I paid the invoice and asked her to examine an old valve I had trusted for years. She condemned it in six minutes. I was proud of the Lenz workshop and resentful of its apparent intention to supply the world with competent critics of me.



### E12-007 | A Name Written Smaller | 1891-09

Anna proposed engraving her initials on the base of the new glasswork so that future repairs might be traced to the proper maker. I said manufacturers had survived for centuries without turning every joint into a monument. Voss produced one of my first blue ledgers and showed me where I had complained of unacknowledged work at twenty. I accused them both of conspiring against a harmless preference for visual cleanliness. Anna offered to make the mark small enough that only a repairer could see it. I agreed. Six weeks later the mark allowed us to identify which batch of joints had a slight internal defect. I wrote to Anna congratulating her on the usefulness of the mark and said nothing about our original disagreement. It had been settled, after all, by data. She returned the letter with the word 'naturally' pencilled beneath my signature.



### E12-008 | A Cigar without an Audience | 1892-01

The winter evening was quiet enough that I heard the ticking of the damaged metronome in the next room. I lit a cigar after supper and read a reply from Voss disputing my projected dimensions for a larger living form. The letter was severe, precise, and accompanied by measurements I could not readily evade. I put it down, walked twice around the room, and allowed the cigar to burn out between my fingers. I was annoyed with Voss for being absent when I had finally constructed a response. I began a letter, abandoned it, and reopened hers. Near the end she had added that she would be in Vienna until March and hoped I would not neglect the little creatures while defending an impossible machine. I wrote back with the corrected dimensions first. Then, beneath my signature, I asked whether she would require anything from Ingolstadt. I did not include an explanation for the question.



### E12-009 | The Parcel with No Instrument | 1892-08

A parcel came from Voss containing an old book and a packet of good coffee, but no measurements, specimens, or requests. I examined it twice for an accompanying problem. Clara said perhaps someone had simply sent me a present. I explained that scholars exchange tokens to maintain correspondence. She pointed out that Voss had already written twice that month. I placed the coffee in the kitchen and delayed opening it for several days, unwilling to make the gesture seem necessary. When I finally brewed it for Clara's visit, it proved remarkably good. I sent Voss a three-page note about an observation she had requested weeks earlier and appended one line about the coffee. Her next letter contained a small joke about my elaborate payment for a kindness. I retained the wrapping paper because it was excellent for protecting delicate specimens. That, at least, was the reason I supplied to anyone who noticed it.



### E12-010 | The Envelope from Henry | 1893-04

I had sent Henry a letter in March after years of attempting to compose one that would be neither a plea nor an indictment. In April I caught myself listening for the postman's steps while pretending to measure the light at the window. Mathilde arrived with a proof and saw the addressed envelope lying beside a second sheet upon which I had begun writing another explanation. She asked whether the first letter had contained a question. It had contained several. She asked why I was attempting to answer them before their recipient had read them. I tore the second sheet in two and put the pieces in the stove. The postman came that afternoon with a receipt for chemicals and no reply. I was perfectly capable of continuing the experiment. I repeated one set of measurements needlessly. The figures did not improve merely because I was paying them extra attention.



### E12-011 | The Room That Could Be Vacant | 1894-03

Clara missed our agreed Thursday visit, and Mathilde came to deliver pages that required signature. She found the second cup set out beside the kettle. I told her I had expected a clerk from town. She accepted this falsehood with the courtesy due a man behaving foolishly in his own house. We discussed the layout of a pamphlet, and she asked where the names of absent contributors were to appear. I said names belonged to the work actually done. She suggested that Clara's maintenance of the records had made the work possible, though few of her acts were included among the experiments. I added Clara's name to the acknowledgments and then objected to the word 'assistance' as insufficiently precise. We argued over a better phrase until the kettle boiled dry. I had preferred a vacant room to an obligation for many years. I kept the proof at my desk until Clara could examine the altered wording for herself.



### E12-012 | A Glass of Water before the Lecture | 1895-04

Reuter asked me to address a small gathering of physicians on the distinction between muscular response and sustained life. I prepared a splendid opening calculated to make their ordinary proceedings appear scarcely worth the hire of the room. Clara attended, though she had reduced her work at the dispensary. Before I spoke she handed me a glass of water and said that half my audience had been awake through the night. I began with an actual observation instead. The argument survived without my opening insult, and several physicians remained afterward to discuss the method. Reuter called the evening a success. I said it lacked its proper dramatic introduction. At home I wrote the abandoned opening into my private notes, where it remains pleasing, useless, and rather cruel to men who had given up their sleep to listen. I still enjoy the sentence. I simply did not deliver it.



### E12-013 | The Photograph with an Empty Place | 1896-09

Anna arranged to photograph the small instruments and their makers before several older pieces were dismantled for repair. I stood beside the workbench while she placed Lenz and Voss where the window light would reach their hands. I objected that the arrangement made me appear a visitor to my own laboratory. She asked whether I wished the instruments or my person documented. I replied that the one explained the other. She took two exposures and left an empty space in the first where Clara might have stood had she been able to come. When the prints arrived I preferred the less flattering one because Lenz's scarred hand was visible against the glass. I could not remember when I had begun thinking of that hand as part of the apparatus. Anna gave me the second print. I placed it in the ledger rather than hang it where visitors might ask for the names.



### E12-014 | The Voice in the Other Letter | 1897-12

Bell wrote from London after our exchange about printed accounts of the extraordinary. She said my objections to the new novel's elaborate collection of diaries were persuasive, but that no single narrator could know everything his companions had concealed. Mathilde, sorting proofs beside the fire, asked whether Bell knew I had written a private record of my own work. I said my record was sufficient for its purpose. She said it contained very little of what the others thought while I was speaking. I suggested that their thoughts belonged to their own notebooks. That evening I attempted to reconstruct an argument with Voss from memory and discovered that I could reproduce my position in exquisite detail while failing to recall her first sentence. I wrote to ask her for her version. The reply corrected a minor fact and an entire motive. I kept both accounts. Neither was particularly flattering.



### E12-015 | The Mirror Turned to the Wall | 1898-10

Preparations for the larger laboratory had revived my habit of performing grand conclusions before the figures could sustain them. Voss brought a design objection; Anna brought an estimate; Clara brought the Queen's recent record of avoiding particular instruments. I had intended to present a comprehensive account of my progress. Instead we spent the afternoon moving a mirror away from the vessel and observing whether the Queen returned to her usual ledge. She did, though not at once. Anna made a note of the interval. Voss said I was capable of treating an uncertain result with patience when it happened to occupy a glass jar. I objected that the jar was a controlled world and the larger apparatus an unfinished one. After they left, I began the address again before the empty workbench. It sounded magnificent. I folded it into a drawer and kept the Queen's observation sheet upon the desk. Before bed I took the folded speech out again, read its opening two lines, and returned it to the drawer without correcting them.

