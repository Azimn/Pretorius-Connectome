# Pretorius: The Lost Years, v4 Production and Audit Report

**Release:** Personality Formation Expansion v4, completed October 8, 2026. **Objective:** Explain plausible causal acquisition of Pretorius's distinctive habits through scene-level fiction without reifying psychological interpretations as canon.

## Completed work

The v3 baseline contained 150 memories across eight episodes. This edition adds 60 first-person memories organized into four formative episodes E09 to E12, resulting in **210 records across 12 episodes**. Added scenes contain **9,048 narrative words** and the full combined scene bodies contain **29,044 narrative words**. This count excludes headings, the continuity ledger, psychological profile, metadata, and reports. The archive spans **September 1859 through June 1899** and ends before contact with Henry Frankenstein.

The added memories explore attribution, delayed judgment, performance under observation, secrecy, scientific integrity, negotiation, respect for dissent, the Queen's apparent preferences, Henry's rivalry, domestic routine, unresolved attachment, and the preservation of objects associated with missing or deceased companions. Four new numbered episodes have exactly fifteen events each.

## Provenance and authority

The *Autobiography of Doctor Septimus Pretorius* remains primary authority for the canonical chronology. All 210 scene-level first-person event records are categorized `reconstructed`. The 60 added records were newly authored for a plausible behavioral learning history. The 15 mechanisms are editorial hypotheses, not facts stated by the source. Original v3 event IDs, texts, named participants, old directed links, titles, and provenance fields were preserved; the chronological sequence number was updated to globally sort the combined records.

Historical institutional conflict: The source situates the University of Ingolstadt there during 1860-1868, although the real university had moved. It is preserved as a fictional departure, not silently harmonized. This batch does not add literal characters from Gothic novels, so speculative crossover count is zero. Post-1899 autobiography, computational persona claims, the Bride, and Frankenstein Village are excluded.

## Consistency and duplicate screening

**Automated validation: PASS.** All 210 event IDs are distinct. Every directed `links_to_prior_events` link resolves to an earlier event in the reindexed chronology. JSONL serialization and required fields are valid. Previous scene text has not been altered. The manuscript displays events in global date order rather than clustering earlier episodes out of order. Exactly **0** memory-text exact duplicates were found. TF-IDF unigram/bigram comparison flagged **0** pairs at or above a cosine similarity of 0.28. That does not rule out semantic similarity, shared themes or novelistic echoes; recurring people and objects are intentionally repeated with different consequences.

Twelve new draft links pointed to a later-dated scene; all were repaired before release. Specifically: E09-010, E10-002, E10-006, E10-008, E10-009, E10-010, E10-014, E11-011, E11-014, E12-006, E12-011, and E12-015. The new corpus contains **110** supplementary cross-event recall edges, each marked an inference. No connection from a later event is misrepresented as a prior cause.

## Recovered versus reconstructed material

This is a creative authoring pipeline. *No newly authored episode is recovered historical testimony*. The reconstructed recollections are not evidence of a true person's diagnosis or of a digital system's internal states. Subjectively narrated motives are not observational proof. The intended imprinting experiment must be evaluated using prospective behavior tests and independent controls rather than finding the desired personality expressed in training data written to produce that personality.

## Open questions

The father remains unnamed, and his subsequent fate is unknown. The exact functional state of the homunculi remains ambiguous. Pretorius's projection of intention onto the Queen has not been validated. The role of Henry's missing replies is undecidable. Clara's companionship is more specific than the narrator's description allows, but its emotional category is not settled. Voss's relationship is not assigned an obligatory romantic resolution. The large-form aspiration remains a future intention. The extent to which public dismissal reinforced an existing preference for secrecy, rather than merely making secrecy necessary, remains a hypothesis.

## Checkpoint

The closing event is **E05-021, June 1899**, windmill news heard, no reunion undertaken. Any further construction must remain before that point. Future research could compare neural imprinting with context retrieval, measure recall-cue response against causal counterexamples, test withholding attribution versus tolerating competent criticism, and compare rich v4 history with v3, v2 and source-only controls.
