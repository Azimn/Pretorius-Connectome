# The Lost Years of Doctor Septimus Pretorius: Expanded Autobiography v4

*An integrated nineteenth-century first-person reconstruction with formation memories.*

The source autobiography is primary canon for the general chronology: birth in 1842, matriculation in 1860, professorship by 1864, dismissal in 1868, and knowledge of Henry Frankenstein's work by 1899. Numbered scenes are fictional reconstructed memories, not eyewitness evidence. Episode IDs are stable across editions. Interleaving the episodes by date is intentional.

**Boundary:** The autobiography closes in June 1899 before any reunion with Henry. Neither the Bride nor Frankenstein Village occurs in this historical manuscript.



## The Early Terms: Family, Apprenticeship and Authority


### E09-001 | The Magistrate's Waiting Room | 1859-09

My father permitted me to sit in his antechamber while he disposed of a quarrel about a millstream. I had brought a notebook on respiration and had every intention of keeping my own company. A miller's widow, Greta Falk, waited opposite me, turning the seam of a glove inside out with her thumb. She possessed a drawing of the watercourse; the man who disputed her claim had arrived with a solicitor and a parcel tied in green tape. My father examined both accounts, asked why one measurement had been taken after rain, and sent them away to obtain a third. I called this an abdication of judgment. He said a magistrate who rushed to pronounce upon two insufficient accounts was not brave but idle. I was irritated to discover that he had listened more closely than I. I still remember Mrs. Falk's glove. I remember less about the millstream, though its particulars were the subject of my lecture at supper.


### E09-002 | The Ink That Wasn't Mine | 1859-12

Mrs. Falk sent a note thanking my father for the measurement that settled her boundary dispute. He gave it to me to file, and I read the sentence in which she attributed the useful question to him. I had, of course, objected first to the original figures, though my objection had been substantially wrong. I carried the letter upstairs and began composing a correction. My father saw the draft when he came for his spectacles. He observed that I had been present and that the examination had occurred, but that I had contributed very little to its success. He did not forbid the letter. He set a fresh sheet beside me, so that I might send it legibly. I burnt the correction in the stove. At breakfast I described the business as unimportant, and he made no reply. For weeks afterward I was excessively precise about the household accounts, as though Mrs. Falk might someday ask me to calculate another boundary.


### E01-001 | The Empty Specimen Drawer | 1860-10

On my third day at the university, I was given a drawer that smelled of camphor and contained nothing except a dead beetle pinned through its thorax. Herr Kappel, keeper of the cabinet, called it an accommodation. I called it a warning about academic generosity. He had lost the key to the better drawer, or claimed to have lost it, and made me sign twice for a cracked magnifying lens. I spent the afternoon arranging the beetle's wings under the glass, discovering that I could change the appearance of movement merely by altering the angle of the light. When Kappel returned, the drawer was cleaner than he had ever kept it. The following morning a second key appeared beside my ink bottle. He never admitted leaving it. I never thanked him in public.


### E09-003 | A Question Lost in the Gallery | 1860-11

The back benches were crowded, and a visiting lecturer spoke for forty minutes on an animal's supposed obedience to an applied current. I had prepared an objection about the interval between stimulus and motion. I delivered it from the gallery in what I believed was an adequate voice. Nobody answered. Reuter told me afterward that the lecturer could not hear a word over the stove. I repeated the question the following week, standing where the lamp threw my shadow across the demonstration table. The lecturer heard it and disliked it, which was a considerable improvement. Heller, watching from the aisle, remarked that I had altered neither the data nor the argument, merely its delivery. I said an idea has little obligation to be modest when the room is hard of hearing. Ever since, I have preferred to choose my position before speaking. One must not confuse this with a fondness for attention. Attention is the door through which evidence must enter.


### E01-002 | The Candle at the Stair | 1860-12

Professor Heller's final lecture ended in darkness because the caretaker had economized on candles. The students stamped about and made a nuisance of themselves, while I remained to question a diagram in which the nervous system had been represented as a line of telegraph wire. Heller relit one candle and invited me to prove the analogy wrong. I could not. What I could prove was that his diagram omitted interruption, delay and recovery. He listened until the wax had almost reached his fingers, then informed me that objections become useful only when their author can name a measurement. I went home irritated enough to fill six pages. Years later I could still recall the smell of his singed cuff. I have never forgiven him for giving me good advice in such a disagreeable manner.


### E09-004 | The Two-Minute Objection | 1861-01

Heller offered me two minutes at the end of a practical session to show why a neat table of reactions concealed a variable interval. I had brought eight pages. When the bell rang he closed the notebook on my fingers and said I had been allotted two minutes, not immortality. The students laughed. Reuter helped me reduce the argument to a single sketch and three measurements, although I accused him of reducing a cathedral to a doorway. At the next session I presented the shorter case. Heller kept the sketch. A month later he used it in his teaching without remembering, at least in public, whose hand had drawn it. This was my first practical education in the distinction between being heard and being credited. I became economical when I needed a door opened, extravagant when I wished to ensure no one could later mistake the man who had entered.


### E01-003 | The Glassblower's Apprentice | 1861-02

Jakob Lenz was eighteen and had already burned two shirts practicing joints that would not leak. He regarded my sketch of a divided vessel, scratched on the back of an examination notice, as an insult to glass. The neck, he said, would break when warm. I told him that I had calculated the pressure. He heated a waste tube and it broke in precisely the place he had marked. I purchased the ruined piece and kept it on my desk, partly as a reminder and partly because he expected me to hide it. We spent the next month learning to disagree over a workbench without raising our voices. He called me Doctor long before I had the right to the title. I suspect he enjoyed my corrections.


### E01-004 | A Disputed Frog | 1861-04

Emil Reuter said a twitch proved an animal had obeyed the experimenter. Heller had asked us to distinguish response from recovery; Emil preferred a demonstration that drew applause. I had watched the frog's leg move even when the stimulus was applied by a boy whose hands were shaking. The animal, I remarked, was not consulting anyone's intentions. Emil laughed, and I laughed too, though at rather different things. Afterward I found him behind the lecture hall replacing the soiled bandage on his thumb. He had been burned preparing the apparatus and had concealed it to avoid losing his place. I helped tie the clean cloth. The next week he lent me his German translation of a French physiology paper, still stained at the corner with iodine.


### E09-005 | The Demonstrator's Courtesy | 1861-05

A demonstrator repeated my objection about the delayed response of tissue as though it had occurred to him in his bath. I waited until after his audience dispersed to ask whether he remembered our earlier conversation. He remembered it perfectly and declared that ideas belonged to the discipline once spoken aloud. Reuter suggested the fellow may have arrived at the same conclusion independently. I replied that coincidence had acquired remarkably accurate handwriting. For a fortnight I dated every loose scrap and initialled the backs of diagrams. Heller saw the practice and asked whether I intended to preserve the birth certificate of every thought. I answered that I had not yet received the privileges of an established mind and must provide my own witnesses. The initials later proved useful in an entirely different disagreement. I have never found it necessary to explain to the demonstrator why I ceased lending him notebooks.


### E01-005 | The Woman at the Dispensary | 1861-06

Clara Weiss knew a spoiled tincture by its look and deeply resented gentlemen who called that knowledge intuition. She set a jar before me, its yellow sediment suspended like a dirty sunset, and asked for a diagnosis. I supplied one at admirable length. She removed the stopper. The odor disposed of my theory in a second. Her late husband's formula books were full of mistakes, she said, and she had corrected them while the learned men who purchased his medicines were busy praising his genius. I returned with a written amendment. She read it, said my handwriting was scarcely an improvement upon my nose, and sold me filter paper at full price. I came back the following week. No one at the university charged so honestly for contradiction.


### E09-006 | A Joke Received as an Answer | 1861-08

Clara found me in the dispensary arguing with Reuter about the difference between an unsuccessful experiment and an incompetent experimenter. She asked whether either of us could distinguish the two before her midday customers arrived. I replied that the incompetent man usually spoke longest. Reuter laughed; Clara did not. A woman waiting with a prescription asked if we were discussing her physician. I could have made an explanation, but instead asked to see the prescribed dose and found it needlessly ambiguous. Clara corrected the label and served the woman. Only later did I discover she had kept my joke and repeated it to her apprentices when they began quarrelling instead of working. She did not credit me, nor did I ask her to. My amusement had done a small service which argument alone could not. There is no dignified scientific account of why I enjoyed that discovery.


### E01-006 | The Locked Shelf of Errors | 1861-09

Kappel showed me a neglected shelf of theses that had been withdrawn or rejected. They were tied with green tape and had the dusty dignity of small coffins. I asked why he had preserved them when the faculty had ordered their titles removed from the catalogue. He replied that a catalogue and a collection served different masters. One manuscript described a failed attempt to preserve a salamander's tissues during winter; its author had mistaken cold for death. I spent a week checking its observations instead of mocking them. Kappel produced more green tape when I returned the pages in order. I understood his bargain: he would trust me with condemned ideas provided I treated their authors as people who might have noticed something.


### E01-007 | The Cold Lecture Bench | 1861-11

We were obliged to count reactions in an unheated room with our pens stiffening between fingers. Emil complained of the cold and misread two intervals; I complained of Emil and misread a third. We warmed our hands around a kettle meant for the caretaker and repeated the observations. The figures agreed less closely with our preferred theory than the first set had done. I proposed omitting the earlier series. Emil looked at me for a long moment and said that if he had suggested such a thing I should have enjoyed humiliating him. He was correct, which made his tone intolerable. I entered both series, labelling the conditions with unusual diligence. We drank the caretaker's tea and replaced it the following morning.


### E01-008 | The First Blue Ledger | 1862-01

I bought the blue ledger from a merchant who seemed distressed that I intended to use an account book for science. Expenditure occupied the left column, failure the right. Kappel inquired where I meant to put success. A frivolous question, I thought, until a specimen behaved precisely as predicted and left me with nowhere to record the result. I ruled a third column in red. There was no ceremony in it. A record that cannot accommodate its own contradiction belongs in the wastebasket, preferably before a rival finds it. The cracked neck of Lenz's first vessel remained entered against the cost of replacement. I have spent more money since, and received less instruction for it.


### E09-007 | The Price of a Seat | 1862-02

Kappel obtained a seat for me at a faculty dinner where young scholars were expected to eat their vegetables and agree at suitable intervals. Heller's colleague described the physiology of sleep without once admitting that his examples concerned only dogs. I contradicted him between the fish and the roast, with the unfortunate result that the table became interested. Afterward Kappel showed me the seating list. He had placed me beside the colleague precisely because the man was considering an assistant for his laboratory. The offer was withdrawn. I assured Kappel I preferred independence to employment and then spent the following two months borrowing instruments from men who possessed both. I did not apologize at the next dinner. I did begin asking who had been invited, which is a less noble adjustment and therefore one I seldom recount.


### E01-009 | The Orchard After Frost | 1862-03

Clara dragged me into an orchard on a raw March morning and put a knife into my hand. Beneath the bark of a tree which any romantic poet would have pronounced dead lay a narrow, obstinate green. Two cut branches came home wrapped in damp cloth. One budded. The other did nothing whatever. I asked permission to open both and examine the difference; Clara declined on the curious ground that she wished to see the first one live. For a fortnight I contrived reasons to visit her shop at the hour when the window caught the sun. I did not thank the branch for its lesson in patience. I wanted to know why its neighbor had failed, and I rather resented the surviving bud for keeping its secret.


### E09-008 | The Ledger with Two Columns | 1862-04

The blue ledger was becoming an agreeable monument to my competence until Lenz asked where I recorded the failures. I pointed to the blank spaces between successful trials. He replied that a blank space looked very like a day on which a gentleman had simply stayed in bed. Kappel gave him a ruling pen and watched with the expression of a man observing a dangerous improvement in administrative practice. We divided the page into what was intended and what had actually occurred. On the first sheet, the right-hand column was disfigured by failures. On the second, I began distinguishing a wrong hypothesis from a spoilt vessel. Soon the ledger became less flattering and more useful. I kept the first page, ink blots and all. I cannot say I welcomed correction. But I found myself less anxious about the next experiment when I knew precisely how the previous one had offended me.


### E01-010 | The Essay No One Read | 1862-05

My essay defined the living organism by the continuance of its internal arrangement rather than by its resemblance to a familiar beast. Thirty-seven pages, which I considered a model of brevity. Heller returned it with the question: would a clock qualify? I had thought the distinction too obvious to require stating. He had therefore found the exact place to apply his knife. I spent two weeks in a clockmaker's shop, where a handsome mechanism expired whenever its spring ran down and never once repaired itself. My second paper concerned maintenance, repair, and the difference between borrowed motion and organized persistence. Heller wrote 'Closer' beneath the final paragraph. I kept that sheet. I cannot say what became of his more generous compliments to other men.


### E01-011 | A Dinner Without a Demonstration | 1862-07

Lenz brought a pie to Clara's Sunday table in a box intended for optical parts. I brought a drawing. She removed the drawing from beside the gravy and told us we were welcome to dinner only if we refrained from turning the potatoes into scientific examples. We managed eleven minutes. Lenz spoke about his sister's apprenticeship as a seamstress; Clara complained of customers who expected medicine to compensate for dirty water. I discovered that I did not know whether Lenz had brothers, although I had trusted him for a year with my most fragile vessels. On the walk back he asked if my mind ever stopped working. I said it stopped whenever someone served overcooked cabbage. He laughed, and thereafter never forgot to ask whether I had eaten.


### E09-009 | Wine at Clara's Table | 1862-08

Clara set a bottle of ordinary red wine beside the bread and announced that nobody would discuss an experiment until the soup was finished. I agreed, not wishing to seem a barbarian in a lady's house. Reuter spent the meal describing an elderly patient who stole pears from his own orchard because he no longer recognized its new owner. Lenz told a story about his brother's wedding. I knew nothing of weddings, and the pears seemed to invite a theory of possession, which Clara prohibited with a raised spoon. When the others left she said she enjoyed a room in which I could occasionally be a guest rather than a professor. I replied that guests were dreadful things, always requiring more wine. Nevertheless I began reserving one evening a month for her table. When an experiment threatened it, I grew unusually industrious during the preceding afternoon.


### E01-012 | The Written Refusal | 1862-10

My father offered to place me in a clerkship where accurate figures and a respectable coat would, he said, carry me farther than disputing the nature of life. He had already written the recommendation. It stood on the mantel, folded in three, while he asked me to be practical. I thanked him for the care with which he had prepared it and returned it unread. This was not an act of courage. I was certain I could find my way without his help and rather liked proving it. In December I discovered that the examination fee exceeded my savings and sold two books I had intended to keep. My father never mentioned the letter again. Neither did I. The empty spaces on my shelf spoke with greater economy.


### E09-010 | The Lining of the Black Coat | 1862-11

My father sent me the name of a tailor who would alter a serviceable black coat. He did not offer to pay for it. The cloth was excellent, though the lining scratched my neck and one sleeve hung lower than its fellow. I accused the tailor of making philosophical judgments about my posture. Lenz inspected the seams and showed me that the coat had belonged to a taller man who bent forward when working. The tailor altered it twice without charging for the second visit. At a university reception I heard someone call the coat theatrical. I discovered that the word could be employed as praise by those who intended it as insult. My father saw me in it at Christmas and asked whether I had been appointed to a funeral. I said I wished to look as grave as the conclusions I was expected to defend. He laughed, unexpectedly. I wore it until the cuffs shone.


### E01-013 | An Interval Miscounted | 1863-01

Lenz delivered a metronome whose wooden case had split along the back. Emil suggested it could stand in for the expensive timing apparatus we were forbidden to borrow. We measured repeated recoveries from a mild stimulus in preserved preparation and obtained intervals so tidy that I suspected fraud. Emil demonstrated the deception without intending to: the pendulum slowed by a fraction when the table shook. The table shook whenever the furnace below was fed. We moved the apparatus to the window and repeated the work. The new results were untidy, which is to say they were useful. I bought the damaged metronome rather than return it; the crack made the instrument unfit for vanity and excellent for memory.


### E09-011 | A Man Who Could Count | 1863-02

Reuter ruined a week's work by confusing two bottles whose contents had settled to the same pale color. I expected a confession, perhaps a satisfying evening of reproach. Instead he made a list of everything we could still infer and put it beside the stove. The best conclusion was modest: we had no result. Heller read the list and praised Reuter's accuracy. I protested that accuracy without discovery was clerical virtue. Heller asked how much of the previous week's work I had privately hoped to count as a success before the bottles were checked. I answered with considerable dignity and a number I later reduced in the blue ledger. Reuter had the decency not to observe the revision. From that winter onward, I could be intolerable about method even when the method prevented me from being impressive. It was an expensive preference, but it was mine.


### E01-014 | A Funeral Register | 1863-03

The clerk at the death register would not let me copy a man's last recorded breath. I possessed no claim of kinship, and I pointed out that kinship seldom improves arithmetic. The clerk remained impenetrable. Kappel returned with me bearing a properly signed letter and a look of disappointment which I found more tiresome than the first refusal. The interval between the final breath and the entry of death varied with weather, witnesses, and the reliability of a pen. I had hoped for the precise frontier of life. Instead, I found officials moving a boundary to suit the hour at which someone summoned them. Kappel said the mourners were not experimental material. I told him the register, at least, had volunteered for examination.


### E09-012 | The Unsent Recommendation | 1863-05

Kappel offered to write a recommendation for a stipend that would pay the rent and spare me a second winter without proper heating. The form required a statement of character. He read aloud the phrase 'obedient to instruction' and waited for me to object. I obliged. For an hour we altered the sentence until it said I completed assigned work but disputed its assumptions. My father, asked to countersign my application, returned it with a note that the second clause would cost me the stipend. It did. Kappel retained the draft in his cabinet and found me other temporary access to the instruments. I declared the lost money insignificant. That evening I counted what remained in my purse twice. Pride has always been more agreeable when someone else supplies the coal; that fact has never persuaded me to surrender it.


### E01-015 | Clara's Broken Jar | 1863-06

Six jars fell from a shelf in Clara's dispensary. She swore at the broken labels before she mourned the spilled medicines, for a known loss may be replaced and an unknown mixture may poison someone. Lenz repaired the bracket. I imposed upon the surviving bottles a numbering scheme which Clara condemned as a professor's method of making every simple act require spectacles. We argued, reduced it to two marks on glass and a single page beside the till, then tried it for a month. It saved a misidentified batch during a crowded morning. Clara told me so while counting coins, without looking up. I went away in excellent humor, which I attributed to vindication and not to the rare pleasure of having been of use outside my own laboratory.


### E09-013 | A Dish Returned Clean | 1863-08

A dish Clara had lent me returned smelling of preservative. She detected it before removing the wrapping and deposited the article in my hands as if it carried a charge of treason. I offered to replace it. She demanded that I clean it properly and bring it back myself. When I returned, she was treating a child whose mother could not pay. I waited with the dish for nearly an hour while Clara worked. Only afterward did she inspect the glass and accept it. She told me a gentleman's offer of money could not restore the hour another person must spend correcting his negligence. I considered a formidable reply and discovered I had none worth making. I began keeping two sets of glassware, one for the laboratory and one for Clara's table. She never thanked me for this elementary separation, and her failure to do so was entirely justified, a judgment I did not express to her.


### E01-016 | A Visitor at the Back Door | 1863-09

My father came without his carriage and stood at the back door while I heated broth over a spirit lamp. He had heard I was selling books. I said the rumor was exaggerated, which it was only in the plural. He asked whether I wished to eat with the family that Sunday. I replied that I had been invited elsewhere, and saw at once that I had made another household sound like a challenge. Before leaving he examined the cracked metronome on my desk and asked if it still kept time. 'Only when properly placed,' I answered. He put down a parcel of good paper and said that was true of men as well. I used the paper for my thesis. I never told him.


### E01-017 | The Thesis in the Snow | 1863-12

I carried my thesis across the courtyard under my coat during the first wet snow of December. Reuter had checked the tables; Heller had removed three flattering adjectives with his own pencil. At the office I discovered that one page of diagrams was missing. It had remained on my bed, beside an untouched supper. Emil ran back for it while I waited on a corridor bench beneath a badly painted saint. When he returned he was breathless and furious that I had entrusted so much to a loose sheet. I submitted the packet a few minutes before the clerk locked his drawer. I remember chiefly that my feet were cold and that Emil, having rescued the work, refused to accompany me to the tavern.


## The Professor, the Student and the Glass Kingdom


### E09-014 | The Question Withheld | 1864-02

Before the defense Heller arranged a rehearsal at which the faculty's most unpleasant questions were to be asked in advance. He turned my thesis over and asked whether the most elegant hypothesis might be false for an exceedingly dull reason. I had a reply prepared, elaborate enough to silence a bishop. Then I saw his pencil resting on a table of intervals whose apparatus had shifted in cold weather. I withheld the reply and asked for the measurements. Reuter looked relieved; Heller looked almost disappointed. We repeated the table and lost a pleasing symmetry. At the defense I presented the uglier figures without explaining how recently I had ceased preferring the handsome ones. My silence had been tactical at first. The corrected table was better evidence. Both facts remain true, however much biographers prefer their heroes to grow virtuous at a single sitting.


### E01-018 | The Defense of a Boundary | 1864-03

At my defense, one examiner asked about dormant seeds; another about sleeping men. I preferred the first question, because a seed makes fewer demands upon a philosopher's conscience. Heller wanted an observation that would defeat my thesis, an extraordinarily ungenerous thing to demand of a candidate already obliged to defend it. I supplied one. Afterward Reuter shook my hand, looking so grave that I was briefly pleased to have inspired envy. His mother was in hospital. We walked there with my thesis under my arm, and I carried it all the way back because no one had the sense to offer me a shelf. The doctorate followed. I was scarcely beyond my student years and had earned the title I had been using in argument for some years. My pleasure was considerable, even if it was not wholly decorous.


### E01-019 | The Professorial Coat | 1864-05

The faculty conferred a professorship upon me with such reckless haste that I have since been accused of falsifying my age. Heller examined my cuffs and declared that a professor should look wealthy enough to endure disagreement. Kappel found me an office with a window facing a brick wall and a door which refused to close in wet weather. I purchased a black coat, second-hand but admirably severe, and placed the blue ledger in the upper drawer. No student came to my first office hour. I prepared objections to six imaginary theses, each worse than the last, and remained until the caretaker extinguished the corridor lamps. Promotion had made me important in the eyes of the institution. It had not yet persuaded the institution to send me an audience.


### E09-015 | The Empty Audience Book | 1864-07

After my appointment I placed a register beside the office door for students who wished to attend a weekly colloquium. On the first Thursday two names appeared, one a false signature evidently supplied by Kappel, the other a student who wanted permission to leave early. I prepared the entire lecture nonetheless. On the third Thursday there were seven listeners. I had abandoned the register and begun speaking in the corridor before the session, disputing Heller's latest proposition loudly enough that students followed to hear whether one of us might draw blood. Heller later observed that controversy had become my advertising department. I replied that the university's own notices were less informative. Once the attendance improved, I stopped quarrelling at the doorway quite so often. I retained the habit of starting with a provocation. It was reliable, unlike institutional announcements, and much less costly than printing handbills.


### E01-020 | The Last Free Afternoon | 1864-08

Lenz announced that he would be married in autumn and might no longer be available for repairs at a moment's notice. I congratulated him by asking whether his intended bride understood the demands of sealed glass joints. Clara said that if I wished to preserve the friendship I should say something less absurd. We walked beside the river, ate black bread and watched two children set paper boats on the current. Lenz described a little workshop he hoped to rent. For the first time I understood that he intended a life not built around my apparatus. I offered him payment in advance for the next year's work, an offer he declined because he did not wish to owe me a year he had not yet lived. I admired the refusal and disliked it.


### E02-001 | An Earnest Student | 1864-10

Henry Frankenstein remained after my lecture while the others went to find their coats. He had an awkward habit of placing a question in front of him as though it were a fragile article and asking permission to touch it. His concern was not whether life could be measured, but whether the measurement would alter the thing measured. I gave him a badly copied diagram and told him to return it with three objections. The following week he brought seven, four good and three merely ambitious. He had marked the margins with a neatness that annoyed me until I discovered he had corrected one of my units. I began leaving the door unlatched on Thursdays. Henry interpreted this as encouragement; for once his interpretation was correct.


### E10-001 | The Corrected Diagram | 1864-11

Henry returned the anatomical drawing I had lent him with a correction in red ink and a paragraph in which he carefully assured me that his alteration did not detract from the general argument. It did, of course, and I told him so. He looked miserable until I asked whether he had tested the new relation on another specimen. He had brought measurements in his pocket. I kept him until the caretaker called closing time and sent him away with three more drawings, each containing an error I had deliberately left in it. The following week he identified two and defended the third because the evidence supported my original version. I admired that defense. I also disliked the speed with which he was learning to dispute me. I had wanted a pupil who would exceed the syllabus. I had not reflected upon the inconvenience of his doing so in my presence.


### E02-002 | The Anatomist's Conditions | 1864-12

Henry wished to work after hours in the anatomy hall. He believed I could simply grant permission. I explained that a professor of philosophy does not possess the keys to every corpse in Bavaria. Heller, who did possess influence, demanded a written purpose and a named supervisor. Henry prepared a letter so earnest that it sounded like a confession. I struck out the word 'conquest' and replaced it with 'observation.' Heller approved a restricted afternoon. Henry resented the limit; I resented asking for it. We used the afternoon to examine the conditions under which tissue ceased responding to stimulation. The most useful result was that neither of us could honestly say where cessation became final.


### E10-002 | The Wrong Kind of Apology | 1865-01

I corrected Henry sharply before six students after he confused the cessation of movement with the cessation of organization. He returned the next week having rewritten his argument, yet he would not speak. I asked whether the problem was his new evidence. He said he did not intend to be made an exhibit twice. Heller, who had overheard this, advised me to learn the difference between testing a thesis and testing a man's willingness to be humiliated. I disliked his formulation and told Henry he could conduct the next discussion himself. He did so with infuriating seriousness and surprised the room with an objection to my own lecture. I let it stand. Later I told him he had behaved quite competently. I did not apologize. He returned to office hours, and I made a practice of reserving certain corrections for the walk afterward. It was not gentleness. I wanted him thinking in my presence rather than guarding against it.


### E02-003 | A Question Under the Lamp | 1865-02

Henry arrived with the skull of a bird, wrapped in a handkerchief, and asked whether a living creature could be constructed from correct parts alone. I told him that a clock assembled from perfect wheels does nothing without their proper relations, and he objected that the metaphor proved too much. Our argument continued until the lamp smoked. Henry sketched a scheme for joining separate tissues; I drew instead a process by which organization might arise within a small volume. We did not resolve the distinction. The following morning my notes contained the phrase 'formation rather than assembly,' but I could not tell whether it had been mine or his. I left the authorship blank. It would not remain a harmless uncertainty.


### E02-004 | An Unpaid Lecture | 1865-04

Clara asked me to speak to apprentices about the difference between a medicine's label and its effects. Henry accompanied me, expecting an intellectual debate. What he received was a queue of tired women and young men with ink on their cuffs, none of whom wished to hear about Prometheus. I explained the error in a dosage ledger, using Clara's paired bottle marks, and the room paid attention. Afterward Henry said he had learned more from their questions than from my philosophy seminar. I told him he had an unfortunate enthusiasm for praising the obvious. Clara paid us in supper. Henry stayed to wash the cups, a courtesy I regarded as excessive until I noticed how tired she was.


### E02-005 | The Correspondence Packet | 1865-06

Reuter sent accounts of patients recovered from conditions which their physicians had called hopeless. Henry wanted to make them evidence for his theory of reanimation. I objected that none had been proved dead, and Henry objected that I was protecting a definition as if it were a fortress. We wrote separate replies. Mine contained a list of necessary observations. His contained almost the same list and a question about Reuter's mother. Reuter answered Henry and omitted me entirely. I told the young man that social graces often purchase the appearance of intellectual credit. He had the impertinence to point out that I had learned the contents of the answer by reading over his shoulder. This was true and irrelevant. I borrowed the packet for another week.


### E10-003 | The Poorhouse Petition | 1865-07

Reuter brought a request for a practical lecture at the poorhouse. The superintendent wished us to demonstrate new principles of circulation and had offered living residents as convenient examples. Henry was delighted by the prospect of cases not confined to anatomy books. Clara asked who had consented, and Reuter answered that the superintendent had signed the invitation. She placed it beside a patient's unpaid bill and inquired whether either scrap of paper was the patient's own hand. I began to object that we were discussing demonstration rather than injury. In the end I went to the poorhouse with a blackboard and no instruments. Henry was disappointed; the residents asked better questions than the superintendent. I did not abandon the conviction that knowledge often demands intrusion. At my next lecture I left the rear door unlatched. Two listeners went out during the introductory remarks. The others stayed and argued.


### E02-006 | The Key Returned | 1865-09

Kappel demanded the return of the cabinet key. I accused him of joining the procession of cowards who feared what an unlocked drawer might reveal. He let me finish, an ominous courtesy, then showed me the inventory register. For years he had signed my loans under his own name; now instruments were missing and the signatures exposed him, not me, to an inquiry. I put the key on his desk. He did not offer absolution and I did not offer an apology suitable for public consumption. Instead I copied the instruments I still had permission to examine and returned them by the appointed hour. At the door he asked about delayed recovery, remembering the experiment for which he had first trusted me. I have known men who declared lifelong loyalty and remembered much less.


### E10-004 | An Account Against the Wall | 1865-10

Lenz arrived with an invoice and refused another promise of payment in the form of future scientific fame. My new laboratory required glass joints he could have sold to paying customers, and his marriage had not abolished the cost of coal. I said I had invested in his skill. He asked whether he might invest my admiration at the baker's. Clara, who had accompanied him, said nothing. I sold an engraved instrument I seldom used and paid two-thirds of the account. Lenz gave me a further month for the balance, but he no longer accepted orders without written terms. I called his policy officious. He continued supplying the finest vessels I could obtain. To this day I distrust a man who asks for blind faith in a partnership. I also resent being reminded that the distrust was taught to me by a glassblower.


### E02-007 | The Small Green Vessel | 1865-11

Lenz made a greenish glass vessel from cullet he had intended to discard. Its base was imperfect and caught the lamplight in a narrow sickle. I asked whether the tint might harm the specimens. He asked whether I intended to study the specimen or the tint. Clara had brought dormant fragments of plant tissue for observation. Some revived; some did not. I began to suspect that organization might be induced by surroundings that did more than preserve it. I record this only as the origin of a line of thought, not as the origin of a recipe. When Lenz asked what I meant to grow, I said, 'Something that knows it has grown.' He called that an unnecessarily difficult commission.


### E02-008 | The Demonstration Declined | 1866-01

Heller offered me a public lecture provided I supplied a result and not another elegant conjecture. Henry wished to show our most responsive samples. I refused. They had responded on three occasions in four different ways, and a crowded room would invite us to call the most flattering outcome the true one. I lectured instead on vitalism, to twenty-six spectators who diminished to fifteen before the lamps were extinguished. Henry looked as though we had been sentenced. I had hoped for thunderous applause and had the decency to be vexed by its absence. Heller said an honest dullness was preferable to a splendid falsehood. I replied that he had made a profession of proving it. This was unjust, and he laughed, which made it worse.


### E10-005 | The Lecture That Returned in Print | 1866-02

A pamphlet from another faculty reproduced an argument from my January lecture, including a mistaken spelling of a Latin term that had survived in the written notes. The author made no mention of me. Henry demanded that we accuse the man at once. Kappel advised a private inquiry; Heller suggested the error might have passed through students' notebooks without deliberate theft. I wrote a devastating letter and left it in my drawer. Then I prepared a corrected version of the argument and had copies deposited under my name. The unauthorized author published again two months later, this time with an awkward acknowledgment. I considered that partial justice. Henry asked why I had not sent the accusation. I replied that I had preferred an enduring record to a moment's revenge. I neglected to mention the evenings I had spent imagining the revenge in gratifying detail.


### E02-009 | The Nation on the Noticeboard | 1866-03

The notices about war were posted beside announcements of examinations and room changes, as though armies marched according to the academic calendar. Lenz worried about cousins who might be called up. Henry spoke of patriotic duty with the conviction of a man whose own hands were occupied by safer questions. I told him that nations were exceptionally large organisms and that governments shared with surgeons an alarming faith in amputation. He took offense. Later I bought extra coal because I feared transport would become erratic. Whatever opinions I possessed about states, they did not keep a laboratory warm. Lenz remembered my practical calculation long after Henry forgot my remark.


### E10-006 | The Cardboard Curtain | 1866-05

Henry observed an early growth preparation and immediately began offering improvements to the apparatus. I was pleased for the first ten minutes and exasperated thereafter. He leaned over a vessel during a phase when temperature mattered, and I snatched his sleeve away before he touched the glass. He called my alarm unreasonable. I placed a cardboard screen between the observation table and the doorway and insisted that everyone entering announce himself. Henry said I had turned science into theatre. 'Yes,' I told him, 'and now I shall decide who steps upon the stage.' The screen remained after he departed. It kept drafts from the vessels, which was useful, and curious eyes from my failures, which was more useful than I cared to say. The screen remained when we no longer needed its protection from drafts. I had Lenz paint its outer face black.


### E02-010 | Henry's Unsigned Page | 1866-06

Henry left a set of drawings beneath my door showing connections between separate organs. The pages contained no signature, though his precise numbering made authorship unmistakable. I corrected a faulty relation and returned them without comment. He confronted me three days later, convinced that silence meant contempt. I told him I had judged the drawing, not its author. He replied that authorship was precisely what frightened him: he feared producing something that would live and therefore belong to neither of us. I laughed at the word 'belong.' He did not. It was one of the first times I saw him hear a moral claim in a problem I considered mechanical. I kept a copy of the diagram and did not tell him so.


### E10-007 | The Unsigned Calculation | 1866-08

Henry left a calculation among my papers showing an alternative relationship between the mass of a living preparation and the time required for its recovery. I found an error in the last line, corrected it, and used the amended figure in a private discussion with Heller. Henry overheard enough to believe I had adopted the result without naming him. He was correct. I told him that a student's idea becomes part of his teacher's work when the teacher makes it serviceable. He asked whether the same rule would apply when the student proved the teacher wrong. I had no satisfactory answer ready. That evening I added his initials to the page and left it where he would find it. He never thanked me, and I never repeated the performance. My admiration for his courage did not lessen my appetite for ownership. Both continued to grow.


### E02-011 | The Empty Dish | 1866-09

For six weeks I inspected a sealed dish that appeared to contain nothing of interest. Clara advised me to discard it, then changed her mind because I was so eager to agree. Under an oblique light we saw minute structures along one edge, too disordered to call organs and too persistent to call sediment. I fetched Lenz, who pointed out that the dish had been tilted since the previous month. We levelled a second specimen and continued observing both. Neither produced the miracle I anticipated. The first did, however, make its growth follow a path different from that of the second. My ledger acquired an untidy sketch of two branching lines. Later I remembered the sketch more accurately than the specimen.


### E10-008 | A Door Measured Twice | 1866-11

Kappel warned me that a committee member had begun asking about deliveries to the private rooms. I accused him of enjoying the role of sentry. Clara had heard a second rumor from a supplier, one concerning not the apparatus but the safety of our sealed vessels. I measured the room doors, arranged for a second lock, and composed a statement about harmless botanical investigation. It was accurate as far as it went and designed to make further questions appear unnecessary. When Kappel saw the statement he said I had managed to write the truth so that nobody could find it. I admired the description enough to repeat it later as a joke. The lock deterred visitors and delayed Lenz one cold morning while a vessel overheated. We installed an emergency latch. Secrecy had protected my work and endangered it within the same fortnight. I kept the lock.


### E02-012 | The Winter Inventory | 1866-12

At year's end we took stock. Lenz's figures showed how much I owed him, Clara's which samples had lost their labels, mine the discouraging number of failures that I preferred to call incomplete trials. We agreed no undated vessel could constitute evidence. It was a good rule, and I disliked its immediate application to three preparations in which I had invested considerable hope. The next morning Lenz's wife left bread, cheese, and a note instructing me to eat before extinguishing the second lamp. I ate the bread standing at my bench. The cheese was excellent, the note intolerably familiar. I kept the note under a weight for weeks, ostensibly because it was the only clean scrap of paper within reach.


### E10-009 | The Vessel That Would Not Answer | 1867-01

A preparation gave no coherent response for nineteen successive observations. I had begun speaking of it to Lenz as though the vessel were deliberately withholding consent. Clara asked whether the heating schedule had changed. I replied that the schedule had not changed and produced my ledger as proof. She pointed out that I had recorded intended temperatures rather than those taken at the glass. We measured again and found a difference sufficient to ruin my interpretation. I scraped my proposed account from the slate and ordered another week of observations. The preparation's behavior altered after the correction, though I could not prove that the correction alone caused it. I remember Clara's forefinger on the wrong column of the ledger. I purchased a second thermometer for Clara to read and was disagreeably attentive whenever its figures differed from mine.


### E02-013 | The First Coherent Response | 1867-02

I shall not describe the preparation of the seed. The formula is not relevant to the recollection and I have no intention of donating it to posterity. What matters is that one minute developing form turned toward an intermittent shadow and continued to orient itself after the shadow was removed. Lenz suggested a mechanical response to heat. Clara changed the light and asked us to try again. We did. The little form did not behave like the first series of samples. I remained at the bench until my knees trembled, then went out to buy more candles. The grocer asked whether I had been drinking. I had not, which made the question particularly irritating. I wrote 'possible organized response' in the blue ledger and underlined 'possible.'


### E10-010 | A Queen Without a Court | 1867-03

After the first coherent response and before I had cultivated the others, the Queen occupied a small platform alone. I placed two objects where she could choose between them, intending to test a preference for height. She moved neither. She stood at the far edge with her back to me while I made increasingly persuasive adjustments. Lenz suggested that my arrangement resembled a trap. I laughed, then moved my hands from the vessel and waited. She crossed to the lower object when she was no longer under my shadow. I wrote 'avoidance of overhead obstruction.' Clara wrote 'possibly of you' in the margin. The distinction was not resolved. I have always enjoyed exercising command. My first sovereign subject made the enjoyment more interesting by failing to obey, and I grew absurdly eager to understand the terms of her refusal.


### E02-014 | Her Majesty's Refusal | 1867-04

The Queen was the first. I named her days after she had begun to live, when it became clear she had no intention of behaving like a laboratory ornament. She favored one ledge and returned to it after every change of arrangement. I rotated the vessel; Clara argued that light would explain the preference. The little sovereign ascended the ledge once more, surveyed my enormous face, and withdrew to an entirely different corner. I said she had made her choice, a scientific description to which Clara objected. Perhaps the creature only wanted shade. It is difficult to be certain when one's kingdom is made of glass and one's creator is forever breathing upon it. I spent that night in a chair beside her and woke with an excellent idea and a thoroughly ruined neck.


### E10-011 | The Borrowed Royal Title | 1867-05

Henry asked why I called the first creature a Queen when she possessed no subjects. I answered that royalty preceded its court in numerous European histories. Clara suggested that I wanted her disobedience to look ceremonial. Henry smiled too readily. To settle the matter I placed a small paper throne in the vessel and watched the Queen disassemble one arm of it. I was delighted, an inconvenient admission since my hypothesis had been insulted in miniature. Henry took the broken arm home to sketch its joinery and returned it with a note about leverage. I kept the note and not the throne. A name can be an observation, a hope, or a demand imposed upon something that has not agreed to bear it. I persisted in calling her Majesty. She continued to behave as if the title conferred no obligation whatever.


### E02-015 | A King with an Inconvenient Heart | 1867-06

The second creature emerged with the complacent features of Henry VIII, a resemblance which I confess gave me disproportionate delight. He fastened his attention on the Queen and neglected his food when her vessel was removed. I called it attachment. Clara called it distress. Neither of us possessed an instrument capable of settling the matter, but I had one capable of ending the knocking against the glass: I restored the Queen to his sight. He ate. There was a vulgar triumph in being obeyed by a king, although I did not then appreciate which party had issued the command. I separated their vessels less often afterward. A mere convenience, I told visitors, as though I had not rearranged half the bench to accommodate a creature smaller than my thumb.


### E02-016 | The Archbishop's Objection | 1867-08

A third little figure developed in an attitude of disapproval so sustained that we named him Archbishop before his clothing had properly formed. He interrupted the King's displays by striking a tiny staff against the base of his vessel. Lenz, who found this uproariously funny, positioned the jars so that the King could see both the Queen and the Archbishop. The result was a three-sided quarrel conducted with gestures too small to hear. I intended to study hierarchy and instead spent the morning shifting glass to prevent injury. Clara pointed out that the Archbishop did not object to the Queen at all, only to the King approaching her. I had assigned a theological motive to an observation that did not require one. The distinction displeased me because it was interesting.


### E10-012 | The Servant Who Saw Too Much | 1867-09

A porter found a broken crate bearing the markings of Lenz's workshop and asked what sort of glass required so much straw and such nervous instructions. Kappel told him it was fragile research material. The porter asked whether fragile research material ordinarily seemed to be knocking at its own box. The sound was a loose wooden cleat, as we discovered when the crate was opened; the story had already acquired a heartbeat by the time it reached the porter's friends. I was furious that a stupid accident should be more persuasive than three years of careful work. Kappel proposed admitting a neutral observer to dispel suspicion. I refused. Each alternative offended me differently: secrecy encouraged legend, publicity endangered control. I chose control. When the story reached the faculty corridor, the crate had acquired a second knock and a small creature that I had never grown.


### E02-017 | The Man in the Black Cape | 1867-10

I had not intended to cultivate anything resembling myself. Nonetheless the fourth figure emerged lean, dark and rather theatrical, with a black cape whose folds appeared before the rest of his costume had assumed proper definition. Lenz called him the Devil. Henry, shown the figure during one carefully supervised visit, regarded him with more unease than he had shown at the Queen. The Devil bowed toward his reflection in the glass and then turned his back upon us. I was delighted. Henry asked whether the miniature had learned vanity from its maker. I told him that resemblance proved kinship no more reliably than a portrait proved paternity. Yet I moved the little mirror out of the laboratory afterward. Certain jokes are more uncomfortable when they resemble observations.


### E10-013 | The Second Set of Figures | 1867-11

I prepared one table for scientific use and another for a prospective patron, removing the damaged observations from the second because they would require more explanation than the fellow could bear. Henry discovered the discrepancy and asked whether a result made prettier for money remained a result. I replied that I had omitted noise, not evidence. He laid the two sheets side by side and pointed to a small irregularity that appeared in three of the supposedly noisy readings. Clara examined it, then asked for the original notebooks. We reinstated the figures. The patron saw both versions and declined to support us. I cursed Henry's delicacy and Clara's stubbornness. A fortnight later the irregularity helped us detect a recurrent fault in the apparatus. I sent Henry a copy of the revised table without comment. He wrote 'I see it' on the back. I have retained that scrap longer than the patron's name.


### E02-018 | Music Before Supper | 1867-12

The Ballerina responded to Mendelssohn's 'Spring Song' and to very little else we tried. Clara first played the phrase on an ill-tuned piano in the room below, and the tiny dancer rose from her resting place. When the tune stopped, so did she. I assumed any melody in the same tempo would serve; she refused three substitutions, one played so badly that I sympathized with her judgment. A week later Clara was delayed, and I found myself humming at the jar while stirring soup. The Ballerina did not move. I ate the soup cold and waited for Clara's return. This dependence on a particular piece of music made the laboratory less controllable, and, to my surprise, considerably more pleasant.


### E02-019 | Salt in the Water | 1868-02

The seaweed arrived leaking brine through three layers of paper and a courier's protest. From it, by means I shall not publish, came the Mermaid. She occupied her watery chamber in such perfect stillness that I feared a beautiful failure. Clara discovered that she moved when visitors departed. We watched from behind a screen, uncomfortably bent like burglars in our own laboratory, while the little figure rose and vanished among the weed. I wrote 'timid' in the ledger. Later I drew a line through it and added 'reacts to observers.' I have not destroyed the first word. It remains possible that she was timid, and equally possible that she possessed an excellent opinion of the advantages of avoiding me.


### E10-014 | The Private Invitation | 1868-03

Heller came privately rather than sending for me. He had heard descriptions of the miniature beings and wished to see evidence before the faculty was obliged to act upon rumor. Henry urged me to admit him. Clara said the conditions could be arranged if Heller agreed to observe without disturbing the vessels. I prepared three drafts of an invitation. Each seemed to surrender something to a man who might afterwards vote upon my work. In the end I showed Heller selected records and declined to open the inner room. He examined the curves and asked whether the living forms could choose not to be examined. I called this a moral question smuggled into a technical visit. He said technical questions frequently acquire occupants. We parted without an agreement. I still wonder whether a demonstration would have altered his conduct. That is not the same as wishing I had given him one.


### E02-020 | The Visit from the Committee | 1868-04

The committee arrived with the solemnity of undertakers pricing a living man. Its charges were conduct unbecoming my office and experiments injurious to the moral fabric of the university, a textile evidently too delicate to survive a six-inch vessel. I offered observations and withheld my method. Heller read the pages while two others inspected my face as if the proof of corruption might be found there. A younger member asked if the little beings suffered. I spoke on the difficulty of defining suffering, with all the authority I could assemble. The question remained unanswered. Henry waited outside and said afterward that my discourse had done us no good. I reminded him that a good answer and a useful answer are not necessarily the same. He looked less comforted than I had intended.


### E10-015 | A Request for Reconsideration | 1868-06

The committee had heard its witnesses by June, though it had not yet pronounced sentence. I was allowed to submit a statement of reconsideration. Kappel brought me the official form, two pages of ruled paper, and advice to say that the observations were incomplete and the circumstances regrettable. I wrote that they were incomplete because life itself was not finished and that regret would not improve a measurement. Heller, who had come to collect another document, read the page with a tired expression. He said that I had once been capable of winning an argument without forcing an enemy to lose his dignity. I asked whether the committee had extended me that courtesy. He did not answer. I filed the statement. For many years I told the story as one of heroic refusal. Sometimes I remember the unused sheet Kappel had left beneath my hand, and that I might have written something else without falsifying a single fact.


### E02-021 | The Dismissal and the Box | 1868-07

The faculty's sentence arrived in a thick envelope bearing very little argument and a great quantity of institutional dignity. I was dismissed. Heller was absent when the matter was concluded. Kappel brought a crate lined with discarded examination papers, an arrangement which pleased me for reasons I did not care to explain. A clerk showed me a torn draft of a letter in which Henry had offered to speak in my defense. The letter had not been sent. I might have asked him why; I preferred, at the time, to despise his hesitation without hearing its cause. Clara insisted that the living vessels be carried upright. I carried my blue ledger. That evening I possessed neither laboratory nor professorship, although no committee in creation could divest me of the learning by which I had obtained them.


### E03-001 | The Tower with Three Dry Rooms | 1868-09

The tower was cheaper than any respectable laboratory and possessed three rooms that remained dry in rain, a virtue sufficient to outweigh its missing stair rail. Lenz tested the upper floor with his boot and refused to carry a jar across it until the beams had been supported. I called his caution provincial. He asked whether I preferred the Queen to arrive on the ground floor by gravity. Clara brought straw, blankets and two pails whose contents were not to be confused. We moved the creatures before the books, the books before my clothes. At dusk the Queen was settled in the least draughty corner, and I discovered that my own bed was damp. I slept beside the heating stove and congratulated myself on having chosen independence.


### E03-002 | The Price of Coal | 1868-11

At the university, coal had entered the cellar by an arrangement as natural and inexplicable as Providence. At the tower it came wet, late, and at a price which might have warmed us by outrage alone. I economized on heat until the King lost appetite and the Queen grew languid. Clara found a box of my cigars and laid it beside the fuel bill. She was offensively silent. I disposed of the cigars and bought coal. The creatures revived, though I shall not pretend that one evening establishes a complete theory of temperature. I recorded the readings beside the expense and put the empty cigar box away. For a week afterward I found myself seeking it at the usual hour. Habit is a petty tyrant, with none of the grandeur of an emperor.


## Tower Years: The Uses and Costs of Independence


### E11-001 | The Coat on the Nail | 1869-01

My professorial coat hung from a nail in the tower's stairwell because the damp made a wardrobe an architectural joke. I had worn it during the hearing and would not relinquish it merely because the university had reclaimed its keys. Clara found the lining spotted with mildew. She said she would have it dried and patched; I said the coat was perfectly serviceable. Lenz pointed out that the shoulders had begun to smell like a neglected cellar. I gave it over with a ceremony of offended dignity. Clara returned it three days later, the cuffs repaired with thread slightly darker than the original. At a time when every other article seemed to have changed its address or its owner, I found the coat in the same place each morning. I called this discipline. Clara called it a curious attachment to a poor nail. Neither description accounts for the fact that I put it on before answering official letters.


### E03-003 | The Door That Would Not Lock | 1869-02

Someone tried the tower door during a night of sleet. I heard the latch rise twice, then a boot on the step. By the time I reached the entrance no one was there. Lenz examined the lock the following morning and found it damaged by rust rather than an intruder. I disliked this explanation, for it denied me a suitably sinister enemy. He fitted a new bolt and asked why I kept a lamp burning against the window. I told him it allowed me to observe the tower's surroundings. He said it also advertised that someone was awake inside. We moved the light and installed a small shaded lantern. I did not abandon my suspicion, but for the next week I listened more carefully before naming every sound a persecutor.


### E03-004 | A Letter from Henry | 1869-05

Henry wrote from somewhere beyond my immediate reach. His letter asked after the smaller creatures and whether I had found a way to maintain viable tissue at greater scale. It contained no offer to visit. I began a reply of forty pages and reduced it to four. I sent him observations on the limits of growth but refused the procedure he sought, although I could scarcely have given him one. At the end I added a line asking whether he had recovered from the quarrels of our final university months. I struck it out and wrote instead that the Queen continued to exhibit surprising preferences. He did not answer for several years. I kept his letter under the blue ledger where it left a pale rectangular mark.


### E11-002 | A Letter without a Title | 1869-07

Henry's letter had arrived in May. I had answered the technical question it contained within a week and spent another six drafting a second letter that would make him understand the larger offense done to me. Kappel visited with new paper and asked whom I intended the second document to persuade. I said Henry deserved to know how the university had punished success. Kappel asked why I had written the word 'witness' four times. I crossed it out three times and sent only the technical correction. I have never discovered whether Henry received that answer. The longer letter remained in the drawer beside his youthful anatomical sketches. I preferred to consider the correspondence an unfinished scientific exchange. The drafts suggested another possibility, one so tiresomely personal that I bound them together and labelled the packet 'administration.'


### E03-005 | The King Takes a Fall | 1869-08

The King fell from his platform in the course of some performance meant, I presume, to impress the Queen. His gait afterward was slow. I declared that a fall of such trifling proportions could do no harm, a confident statement pronounced before I had examined him. Clara moved the furnishings nearer the floor while I prepared reasons why the original height had been sensible. The Queen remained on the side of her vessel facing him until he recovered. I shall not make a romance of it. The King promptly attempted to scale our new partition and behaved as though safety were an indignity inflicted by lesser courtiers. I almost applauded his spirit. Then I adjusted the barrier and avoided looking at Clara.


### E11-003 | A Debt in Small Coins | 1869-11

Lenz came to fit a glass valve and found me counting copper coins beside an untouched dish of potatoes. The university stipend had ceased. Two patrons who promised sympathy had failed to send payment. He set the valve in place and gave me a bill with the date left open. I objected that I could pay for honest work. He replied that he knew this, which was why he was willing to wait. Clara arrived later with coal and an account she refused to describe as charity. I insisted upon signing every debt in the blue ledger. They signed as witnesses, rather as though I were founding a bank. I repaid the sums, not always promptly. Years later when younger men proposed arrangements based solely upon mutual enthusiasm, I demanded a date, a price, and a means of leaving. Trust had reached me through a bill that nobody was in a hurry to collect.


### E03-006 | A Paper with No Title | 1870-01

Kappel sent an unsigned packet on the restoration of interrupted processes, the pages tied without his customary green string. Someone had written in the margin, 'Ask what restores the pattern.' I imagined he wanted a paper in which I would proclaim victory over his former masters. I drafted one under a false initial and asked him to circulate it without my name. His reply was brief: 'I did not ask you to lie.' An absurdly inconvenient distinction. He had preserved my access to certain records, yet apparently expected me to preserve an ethical boundary which the university itself had never scrupled to cross. I burnt the false title page and kept the essay. It remained unfinished because I could not decide whether anonymity was prudence or surrender.


### E11-004 | The Chair at the Window | 1870-04

I set a second chair beside the east window for Kappel's visit, though the old man seldom stayed more than half an hour. He failed to come one afternoon and then another. I left the chair in its place because it held a stack of books rather well. On the third Thursday I found myself saying aloud that his remarks about the arrangement of my index were wrong. The Queen looked up from her ledge and resumed her occupations. There was no harm in speaking to one's specimens, provided one did not mistake a movement for comprehension. When Kappel finally arrived, suffering from a cough that made the stairs laborious, I began my argument before he had removed his gloves. He asked for tea. I made it badly and was rewarded with a criticism of the leaves. It was a satisfactory hour. The chair remained by the window long after his departure, a convenience which I continued to attribute to the books.


### E03-007 | Wartime Windows | 1870-08

Wagons took the road south through the summer, and every village conversation drifted toward the war with France. Lenz's brother had gone with a unit, and the glassworks had lost two trained hands. My latest vessel could not be delivered. I first treated this as an outrageous interference with science and then saw Lenz reading a letter that had passed through too many hands. We repaired what we possessed instead. I taught him my system for recording the service life of a vessel, and he taught me to mend a chipped rim without pretending it was whole. His brother survived that campaign, though we did not know it then. The delay prevented a risky transfer I had been impatient to attempt. I was not grateful to the war for this benefit.


### E11-005 | The Supper Given Away | 1870-11

During a lean month I preserved enough money for lamp oil by economizing on supper. Clara discovered this when she found bread hardened beside the sink and my hands shaking while I tried to set a stopcock. She said I was unfit to handle delicate glass until I had eaten. I accused her of treating me like a patient; she replied that patients occasionally possessed the sense to follow instructions. Later that evening a farm boy brought a parcel of food from Lenz's household and refused a tip. I gave him my portion of cheese for the road, then regretted it before he reached the gate. I ate the bread and preserved the lamps. There was no nobility in the transaction. The following day my hands were steady and the experiment behaved. I began keeping provisions near the workroom, which I represented to visitors as a contribution to experimental reliability rather than obedience to Clara.


### E03-008 | The New Empire on Cheap Paper | 1871-02

Clara brought news of the German Empire printed on paper so thin that daylight showed through the ink. She expected me to make an offensive remark and I obliged. Yet she had not come for an argument about emperors. The new postal arrangements might make some scientific correspondence easier; the price of coal had risen again. We calculated accounts while the Archbishop knocked his staff against the glass in the next room. She asked what I proposed to call my private kingdom. I said that I had no wish to rule. The Queen chose that moment to turn her back upon me, and Clara folded the newspaper without smiling. I entered the coal price in the blue ledger beneath a grander heading than it deserved.


### E11-006 | A Name Lost in the Lists | 1871-04

Reuter asked me to inspect a series of records from men returning wounded after the war. One young assistant had been known to him by a nickname, yet the hospital's transfer lists had entered three different spellings of his name. The man's injury was visible; his subsequent whereabouts were not. I argued with the clerk over the mistaken initials until he permitted us to copy the surviving records. We located the assistant at another infirmary two days later. Reuter called it good fortune. I called it a victory over defective classification. The man himself was more interested in finding his spectacles than in our triumph. Clara supplied a pair from a drawer of abandoned possessions. I saw how an error in a ledger could turn an identifiable person into an administrative absence. The blue ledger acquired a separate index for those who handled or cared for my creatures. I did not call it sentimental.


### E03-009 | The Queen's Quiet Week | 1871-06

For six days the Queen scarcely moved. I inspected her vessel with the mortifying caution of a man whose entire theory of life might be refuted by a creature the size of a nail. Clara sat nearby reading a catalogue aloud, a droning account of roots and leaves. The Queen approached the wall nearest her voice. I said it was coincidence. Clara agreed with suspicious readiness and continued reading. In the following weeks the Queen sometimes approached certain voices, sometimes turned away. I could have staged a demonstration for visitors and announced that she knew us. Instead I moved my chair closer and kept accounts of the failures as well. There are secrets which an impatient scientist destroys merely by announcing their discovery.


### E11-007 | The Queen's Evening | 1871-11

After the Queen's summer quiet spell, I began checking her platform before extinguishing the final lamp. At first I did so to determine whether her preferred position varied with the fall of light. One evening Clara watched me move the small screen, warm the outer glass with my palm, and place a scrap of bright cloth where the Queen had once selected it. 'You always do that in that order,' she said. I had not noticed. I replied that established methods deserve repetition. Clara asked whether I had tested another order. I said there was no reason to disturb a successful arrangement. The Queen settled near the cloth. I recorded nothing in the scientific column that night. What had begun as a control condition had become a ceremony whose interruption made me impatient. I retained it because the little creature appeared to prosper, not because I wished to be required at a particular hour.


### E03-010 | The Festival I Did Not Attend | 1872-01

Lenz invited me to his family's winter gathering. I declined because the Mermaid's water was changing color and I could not bear to leave the tower. By evening the color had returned to normal. I could have gone, but I remained with my notebook and a plate of hard cheese. On Monday Clara brought the uneaten end of a cake and said Lenz had saved it for me. I informed her that attendance at festivities was not a professional obligation. She replied that nobody had suggested it was. The cake was surprisingly good. I sent Lenz a small repair instrument in return but never admitted that I had wanted to hear his family quarrel over cards.


### E11-008 | A Child with the Wrong Question | 1872-04

Lenz's little daughter was permitted to see a drawing of the King, not the actual glass vessel, since her father believed my laboratory unsuitable for children. She asked why the King was made so small. I described the advantages of observing life within controlled limits. She asked why he could not come out. I explained scale, temperature, and the dangers of a careless world. She considered this and said that a bird kept in a narrow cage might also be easy to observe. Her father told her not to be rude. I assured him I had been insulted more intelligently by older people. That evening I drafted a plan for a room-sized enclosure and found the expense intolerable. I put the drawing away. For some months thereafter I found myself staring at the glass rather than through it. It would be inaccurate to say the child's question changed my convictions. It did alter the location at which the discomfort appeared.


### E03-011 | An Inventory of Small Preferences | 1872-05

I entered my six little subjects in the blue ledger with their principal inclinations: the Queen's ledge, the King's devotion, the Archbishop's interruptions, the Devil's mirror, the Ballerina's music, and the Mermaid's preference for seclusion. It was an elegant chart. Clara ruined it by adding a column for exceptions. The Ballerina would not always dance in the cold; the Devil forgot his reflection when the King was active; the Mermaid appeared in bright light if nobody approached. I demanded that the exceptions be measured properly, and for three days no work of immediate ambition was done. The table became more useful and decidedly uglier. I retained it. A monarch, a devil, and a dancing girl had contrived to make a fool of the neatest account of their characters.


### E06-001 | A Printer's Daughter | 1872-08

A bookseller sent me to the Rosen shop because its proprietor would accept an order that respectable printers declined. I expected an old conspirator and found his daughter Mathilde removing type from a forme with fingers black to the second joint. She had read the unsigned paper I had circulated and identified a numeral reproduced incorrectly in three places. Her father, she said, would print anything provided the customer paid, but she preferred a manuscript that knew the difference between seven and seventeen. I suggested that no intelligent reader could have mistaken my meaning. She set both numbers beside one another in metal type. Under the shop's hard northern light I saw how very little intelligence a reader required to ruin a result. I ordered thirty private copies and forbade her to improve my punctuation. The corrected numeral was hers, though the cover carried only my initials.


### E06-002 | The Price of a Name | 1872-11

On collecting the copies I found one sheet laid aside, a proof headed with my full name. Mathilde had set it to see whether my initials occupied less space. They did not. Kappel, who had accompanied me on the unlikely pretext of buying envelopes, asked whether I wished to hide the argument or its author. An offensive distinction, particularly when delivered before a printer's daughter. I told him that a signed statement would give the faculty another occasion to pronounce upon things they could neither measure nor mend. Mathilde asked why, in that event, I had placed my address beneath the final paragraph. I had meant to invite correspondence. I removed the address from twenty copies and preserved it on ten. I received one hostile letter and two requests for particulars, all sent to Kappel, who claimed this vindicated the experiment in honesty.


### E11-009 | An Invoice for Silence | 1872-12

Mathilde had completed a small private impression of my experimental notes. She offered to omit the shop's mark from the final copies if I paid for the additional work. I asked whether secrecy carried a tariff. She said so did paper, type, and the risk of explaining a mysterious order to a magistrate. Kappel, examining a proof, suggested that a few copies be given to credible witnesses rather than hidden in cupboards. I disliked the notion that I needed witnesses and ordered twelve extra copies. Mathilde kept one sealed in her shop, with a date and a list of corrections. I objected to her retaining my work. She replied that a printer who cannot prove what he printed is a convenient scapegoat. Years later I would say that no university deserved to control my name. When a date was disputed years later, Mathilde produced her sealed proof without troubling to look pleased.


### E06-003 | The Old Automaton | 1873-01

Mathilde arrived carrying Hoffmann's tale of the Sandman and a mechanical bird whose owner had tired of winding it. She regarded the doll Olympia as a rather transparent indictment of men who prefer agreeable women to attentive ones. Lenz opened the bird and showed us a spring worn almost smooth where the mechanism failed to catch. I proposed that a genuinely living creature must repair some portion of its own disturbance. Mathilde pointed out that people also required repairs from others; she tapped Lenz's old burn scar without asking permission. We set the bird upon the window ledge, and its beak moved three times before falling silent. The King meanwhile knocked upon his partition until the Archbishop turned away. I disliked how easily the company transferred its attention from a machine to my little court, but I was not foolish enough to demand an explanation from a bird.


### E03-012 | A Patient without a Name | 1873-03

Reuter invited me to review records of a patient who had repeatedly recovered after periods of apparently profound unresponsiveness. I went by a roundabout route, avoiding people who knew my dismissal. The patient was an elderly man who liked chess and disliked being spoken of as a case while present. Reuter introduced me as an old university colleague, neither defending nor condemning me. I asked the man whether he remembered the intervals. He remembered waking and finding the room changed, but nothing of what had happened between. I left with notes less triumphant than I had hoped. Reuter sent me away with a packet of clean linen for the tower. He had noticed that my cuffs were fraying. This small evidence of attention remained with me.


### E11-010 | A Patient's Complaint | 1873-05

The patient whose unusual periods of insensibility had interested me returned while I was visiting Reuter. He had become quite recovered and wished to know why a stranger had been shown particulars of his treatment. Reuter explained that I was a scientific consultant. The patient asked whether this entitled me to write about his body. I assured him the notes bore no name. He pointed to his occupation and age, which narrowed the possibilities in the town to perhaps three men. I had regarded anonymity as a mechanical matter of removing letters. Reuter asked me to correct the report before circulation, and I did, though I resented the time. Afterward I removed occupations from other case notes where they contributed nothing to the phenomenon. I remained convinced that useful knowledge ought not perish for want of access. I removed two unnecessary particulars from the next report. The pen nearly tore the page where I pressed too hard.


### E06-004 | A Door with Two Accounts | 1873-06

Clara lent her rear table for a meeting with Mathilde because the printshop's landlord had developed an appetite for listening through walls. Her dispensary ledger lay open at the edge of the table, each unpaid bottle entered against a name. Mathilde wanted to publish a clear description of the homunculi, including the circumstances under which they refused to move. Clara asked whether the report would expose them to visitors. I said a glass vessel could not be injured by the attention of a gentleman who understood glass. Both women looked at me until I amended the claim to the animals within it. We discussed paper dimensions instead. Clara measured her charges by what they could bear; Mathilde by what could be read; I by what could be proved. We reached no philosophy that afternoon. We agreed, rather less nobly, to use numbers instead of names in any public account.


### E03-013 | The Train Compartment | 1873-10

Lenz and I travelled by rail to collect an optical fitting. He insisted on facing forward and devoured sandwiches while I suffered the indignities of the carriage's motion. A little girl asked whether our case contained a bird; Lenz said it contained a thing considerably more troublesome. I was charmed until she demanded that we open it. At the workshop we discovered they had repaired the wrong fitting. I gave the proprietor an account of incompetence which ought to have been published for the benefit of craftsmen throughout Europe. Lenz produced the original order with its number and obtained a correction in four sentences. On the return journey he wrote that number inside the case. I permitted it. I did not permit him to describe the whole day as wasted, because we had acquired an excellent story at the proprietor's expense.


### E11-011 | The Parcel Not Opened | 1873-11

A parcel marked with Kappel's hand arrived damp and partly crushed. I assumed it contained another catalogue of obscure dissertations and left it under the stairs while I dealt with a failed preparation. Three days later Lenz used the box to prop open a door. Kappel arrived and asked whether I had read the letter within. It concerned an offer of privately held instruments whose owner would accept a visit only before the end of the month. We had missed the opportunity. I accused the rain, the messenger, and Lenz's mechanical ingenuity. Kappel asked why none of them had prevented my opening the parcel. I dislike questions which have only one answer and are therefore disguised accusations. I thereafter sorted letters by the sender's handwriting before attending to their scientific subject. Some senders mattered because of their knowledge. Others mattered because they would be offended, or absent, if neglected long enough.


### E06-005 | The Volume without a Spine | 1873-12

Kappel brought out a bound collection of withdrawn anatomical reports, its spine removed to avoid a title on the shelf. Between two accounts of failed grafts lay a memorandum I remembered arguing against as a student. I now found its descriptions of interrupted recovery remarkably sound. Mathilde, who had come to inspect the paper stock, asked why I had underlined the author's error but not his correct prediction. I told her that mistakes invite marks more urgently than commonplaces. She put a small cross beside the neglected passage. Later, alone, I compared it with three records from the Queen's early months. The resemblance was insufficient for a conclusion and sufficiently irritating to occupy my Christmas holiday. I copied the memorandum, leaving its author's name intact. Kappel noticed. He said nothing, which was the most agreeable compliment I ever received from him.


### E03-014 | The Archbishop Changes Sides | 1874-02

The Archbishop, long the King's adversary, surprised me by standing between the King and a falling piece of miniature furniture. I first thought the gesture accidental. Then he helped push the object against the wall. The King spent the evening beside him rather than beside the Queen. I watched this unlikely truce until the lamp oil failed. Clara urged me not to describe a single cooperative action as reconciliation. I obeyed in writing and disobeyed in conversation. By the end of the month the two had returned to their usual disputes, but sometimes shared a ledge without quarrelling. I made a new observation card instead of erasing the old one. Their history had developed complications inconvenient to a simple allegory.


### E06-006 | The Archbishop's Audience | 1874-04

Mathilde asked to see the beings about which she had been setting type for eighteen months. I permitted the visit at noon, when the light was steady, and arranged the Archbishop's chamber nearest the table. The little ecclesiastic stood motionless until the King stumbled against a narrow ledge. He then crossed the enclosure and laid one hand upon the rail, an act that looked wonderfully like assistance and might equally have been possession of a favored object. Mathilde whispered, with exasperating delight, that my bishop had better instincts than some professors. I wished to correct her, but the King was already upright. I wrote the precise order of movement, and Lenz quietly widened the dangerous ledge while my guest was examining the Queen. She left without demanding proof of souls. She did request that I remove the word 'obedient' from the printer's proof.


### E11-012 | The Archbishop's Place | 1874-06

Mathilde returned to observe the little Archbishop, who had recently surprised us by protecting rather than obstructing the King. She wanted a clean account of the change for the next impression of my notes. I offered a theory of rank and allegiance. Clara remarked that the Archbishop had stood where the strongest current of warm air entered the vessel, and that his position may have had nothing to do with the King. We arranged another observation and found that both explanations fit some of the movements. Mathilde set the paragraph with the words 'cannot presently distinguish.' I ordered them removed, then restored them when she asked which experiment would permit a stronger claim. I liked the Archbishop better after that. Whether he possessed loyalty, preference for warmth, or merely a talent for deceiving me, he had earned his place in the account without requesting permission from my theory.


### E06-007 | A Review Written in Advance | 1874-07

An editor from Augsburg returned our prospectus with the assurance that claims of miniature men could be dismissed without an inspection. He had, however, complimented my literary manner, which showed him capable of good judgment in a narrow field. Mathilde had already composed a rebuttal before I arrived. She proposed to print the rejection beside an inventory of witnessed behaviors. I advised her that humiliation was more effective when administered sparingly; she replied that I had furnished enough for a lifetime. We quarrelled over whether the editor's name belonged on the sheet. She wished to print it. I did not wish to give a mediocrity the immortality of appearing in my pamphlet. In the end we printed the inventory alone, with empty spaces where independent corroboration might someday be placed. I enjoyed imagining him discovering those spaces and mistaking them for mercy.


### E03-015 | The Question of a Larger Vessel | 1874-09

I commissioned a much larger vessel, believing the restrictions of scale might be partly architectural. Lenz warned that its walls would distort observation and its weight would make relocation hazardous. I persisted. When the glass arrived I could scarcely move it through the tower door. For two afternoons we manoeuvred it with padded boards before Clara asked whether I had calculated how we would remove it in an emergency. I had not. The vessel remained empty, a magnificent and expensive monument to incomplete planning. Months later we converted it to a sheltered chamber for a plant culture. It was useful in that modest occupation, though I continued to resent being taught economy by its success.


### E06-008 | The Bird That Would Not Sing | 1874-12

The mechanical bird ceased its thin whistle on a December afternoon. Mathilde blamed the coal dust. Lenz declared the spring sound and the bellows leaking. I knew that the sound had always been disagreeable and made no objection when the creature was taken apart upon the shop counter. The fault proved to be a fragment of thread wound about the axle. Mathilde removed it with a bodkin and gave the bird back its voice. She asked whether my Queen would recover as readily from an obstruction of equal scale. I said the comparison was inaccurate, although I could not immediately state a more precise reason. That evening I changed the screen near the Queen's vessel rather than prod her to test the point. The bird's bright, tiresome note accompanied us while we counted corrected pages. By the third hour I was privately glad it lived on the far shelf.


### E03-016 | The Cold Soup Agreement | 1875-01

Clara discovered that I had not eaten properly for two days. She set soup on my desk and announced that she would stop bringing supplies if I continued treating food as an interruption. I objected that a man might choose his own habits. She agreed and said she might choose hers. We made an arrangement: I would eat before the second evening lamp was lit, and she would not rearrange my experiments without asking. The bargain lasted eleven days before I broke it. Clara left the soup untouched. The following week I appeared at the dispensary to pay a bill in person and ate at her table. She did not mention the agreement. I kept it thereafter more often than I liked to admit.


### E11-013 | The Door after Supper | 1875-02

Clara had negotiated our arrangement about regular meals in January. I resented the suggestion that I required management and agreed to a fixed supper chiefly to end the discussion. A month later she failed to arrive at the appointed hour. I cooked an egg, burnt it, and decided not to consider the matter further. When she appeared late, having attended a difficult birth in the village, I greeted her with an unnecessarily elaborate complaint about punctuality. She asked whether I had been worried. I said I had merely wished to prevent waste. She ate the better part of the bread, then fell asleep in the chair for ten minutes. I covered the lamp because the light troubled her. On waking she noticed and smiled, which was most irritating. I have never liked to be caught providing comfort; it encourages the recipient to expect a repetition. Of course I covered the lamp again when the occasion arose.


### E06-009 | The Visitor from the River | 1875-04

A young boatman's wife came to Clara complaining that her husband had stopped answering during the long river journeys. Clara asked ordinary questions about sleep and food while I considered nervous exhaustion and the possibility of a more interesting lesion. The wife said that he answered everyone except her. It was a domestic insult rather than a medical novelty. Clara sent them home with instructions about rest and a bill smaller than it might have been. Mathilde, seated near the doorway, remarked that silence could be a choice, a symptom, or an accusation, and that a ledger should not confuse them. I had recently called the King's stillness deliberate refusal. Returning to the tower, I changed the entry to 'no movement observed.' I did not announce a reformation of my principles. The revised phrase was plain enough, and therefore sufficiently humiliating.


### E03-017 | The Summer with No Answer | 1875-07

I wrote Henry a new letter about the limits of bodily scale. It took three drafts to remove a paragraph asking whether he had forgotten me. Kappel carried it into town because I had begun to dislike being seen at the post office. No answer came that summer. I interpreted the silence as contempt, then as busyness, then as deliberate caution. None of these interpretations could be tested. I filed a fourth draft, unsent, which contained only a question about his present work and a description of the Mermaid's habits. When autumn arrived I burned the draft but kept the envelope. I was proud of not pursuing him. Pride is a convenient name for a decision one cannot entirely defend.


### E06-010 | The Last Line on the Page | 1875-09

Kappel had begun preserving my unsent letters to Henry between folders of neglected dissertations. I found the arrangement impertinent. A letter not sent, I observed, was not correspondence. It was draft material, and draft material belonged to its author. Kappel answered that my concern for ownership had never prevented me from requesting access to other men's discarded thoughts. Mathilde was present to collect the paper inventory. She counted four letters bearing Henry's name, each one shorter than its predecessor until the last consisted of a single unfinished question. I took all four home. Two weeks later I returned the first three to Kappel's archive, keeping the last in the blue ledger. I had no wish to place its question in another man's custody, even one who had long since earned the privilege of seeing worse things in me.


### E06-011 | The Little Examination | 1876-02

Mathilde brought six blank cards, each bearing a different shape, and requested permission to hold them near the Queen's chamber in an order unknown to me. I consented because a result that arrives only when its author directs the sequence is a party trick, not knowledge. The Queen approached a dark triangle twice, avoided it once, and ignored the rest. The pattern did not survive the afternoon. Mathilde was disappointed. I was furious, but chiefly with the cards, which had been cut from inferior stock and bent in the damp. Lenz had prepared a second batch. We repeated the sequence on another day with no improvement. I recorded the failure and refused Mathilde's suggestion that we name the Queen's favorite shape. If I must bestow titles upon insignificant things, there are members of the faculty still available.


### E11-014 | The Hand That Would Not Settle | 1876-03

Lenz's hands trembled slightly after a long day at the furnace, and I noticed it while he attempted a delicate repair. I asked whether he had been drinking. He showed me the blister beneath his thumb and suggested that I try holding the hot rod myself before diagnosing his habits. Clara bound the hand. We postponed the work. At the next visit I brought a padded grip devised from cork and cloth. It was a poor contrivance but useful enough that he kept it. He thanked me with a joke about my becoming an apprentice at last. I replied that necessity had forced the descent. I did not inquire whether the grip lessened his pain; I watched his fingers while he worked and could see that it did. In my notebooks I recorded the alteration to the instrument. I did not record the reason I had designed it.


### E03-018 | The Repairman's Hand | 1876-04

Lenz injured two fingers on hot glass and for a fortnight could not make the joints upon which my experiments depended. I arrived at his shop armed with instructions about splints. His wife put a stack of unwrapped orders in front of me and said I might assist by keeping my medical imagination to myself. I wrapped glass, mislaid a label, and discovered that paper twine can humiliate a philosopher as thoroughly as a hostile faculty. I returned the next week and did the work with fewer mistakes. When Lenz offered to reduce my bill, I refused. I am not fond of debts whose amount cannot be entered in a ledger; moreover, I had no wish to teach him that injury reduced the value of his skill. His wife later sent better twine to my tower, with no explanation.


### E06-012 | The Name in the Catalogue | 1876-06

A catalogue listed my private pamphlet under 'Pretorian curiosities,' a designation at once illiterate and insulting. The shop's apprentice had entered the heading from a secondhand dealer's note. Mathilde offered to correct it. I told her not to trouble herself, since a collector stupid enough to purchase curiosities would at least pay an honest price for the book. That evening I wrote the dealer an impeccably polite letter containing four separate demonstrations of his incompetence. Kappel later saw it and observed that I had made myself memorable to a man who might otherwise have forgotten me. He was quite right. Weeks afterward the corrected catalogue arrived with the category 'experimental natural philosophy.' I placed it between the uncorrected proof and my letter, a triptych considerably more satisfying than a public apology.


### E06-013 | Ink after the Burn | 1876-09

Lenz's injured hand recovered well enough for work, though he could no longer close the little finger without discomfort. Mathilde brought him a ledger ruling device as a gift, only to discover that he preferred drawing lines with a straightedge held in the other hand. He showed her the small changes he had made to his bench. I remarked that adaptation of an instrument was preferable to romantic mourning over its limitations. Lenz asked whether I regarded the human hand as an instrument. I said I regarded it as an expensive apparatus insufficiently appreciated by its owner. He laughed, then used his uninjured hand to produce a new chamber stop precisely fitted to my request. I retained the earlier flawed stop as well. It reminded me that a workshop can change more reliably than a university, although I did not flatter either craftsman with the comparison.


### E03-019 | The Ledger's Missing Page | 1876-11

I found one page missing from the blue ledger, the page on which I had entered the Queen's first sustained orientation. My immediate suspicion fell upon a visiting instrument seller. Clara pointed out that the binding had worn thin from years of use. Kappel, summoned like a magistrate to a crime scene, found the leaf pressed inside a botanical catalogue where I had used it as a marker. The relief was brief; the embarrassment, more durable. We began copying observations into a second register kept in town. I resented the duplication until a water leak ruined several loose papers that winter. The copy preserved the records. The leaf itself, still bearing the crease of its escape, remained in the first book.


### E06-014 | The Complaint behind Glass | 1877-01

One winter morning the King struck the glass with unusual regularity, stopping whenever the Archbishop approached. I suspected an exchange of signals and said as much. Clara thought the chamber too dry. Mathilde asked whether either hypothesis could explain why the behavior began only after the new stopper had been fitted. I examined the joint and discovered a narrow draft where the glass met the wax. There was nothing heroic in repairing it. The King ceased his tapping that evening; the Archbishop returned to his customary occupation of disapproval. Clara asked whether I would amend the record. I entered her suggested cause beside mine, with the date and no preferred conclusion. I then spent a quarter hour watching the King sit perfectly still, an ingrate with no concern whatever for the labor he had occasioned.


### E06-015 | A Newspaper Death | 1877-05

An obituary reported the death of a minor scholar who had once signed the petition for my removal. I recognized the signature with precision I could not summon for the man's face. Mathilde asked whether I should send his widow a letter. I answered that condolences from the victim of her husband's cowardice might be mistaken for triumph. Kappel said that perhaps I was afraid of precisely the opposite. We let the paper lie on the table while the press rattled. Later, passing the house where the dead man had lodged as a student, I discovered that I remembered him lending me an umbrella during a storm. I wrote no letter. I did, however, retrieve the damp obituary from the shop's rubbish and file it beside the petition. A death had not altered the signature; it had made the attached hand less conveniently abstract.


### E06-016 | A Volume Too Small to Burn | 1877-07

Mathilde bound the private record into a narrow volume in brown cloth. It contained no formulae, only dates, corrections, the names of those who had looked, and the things my small people had done when watched and when left alone. She called it a book of witnesses. I had intended a vindication. The distinction displeased me, though the paper was excellent. Clara ordered a copy for her own shelf, promising neither praise nor concealment. Kappel asked that a third be kept beyond Ingolstadt. I refused until Mathilde pointed out that I had already lost a page and nearly lost several years of correspondence. We placed a sealed copy with a dealer on the road west. At the end of the afternoon the mechanical bird, still unreliably musical, whistled once from the high shelf. It seemed an absurd fanfare, which did not prevent me from enjoying it.


### E03-020 | The Door Left Open | 1877-08

Lenz repaired the upper landing and, for the first time in years, we could carry a chair to the east window without fearing the floor. Clara opened the shutters. The road below was full of dust and the smell of cut grass, not the host of persecutors I had sometimes imagined. She asked whether I intended to spend the remainder of my life watching the world from a tower. I told her that I had plenty of work. She did not disagree. That evening I prepared a small travelling case with space for one vessel, a notebook and the metronome. I did not yet choose a destination. The case stood unopened beneath the window for months, an intention too delicate to be dignified with the name of a plan.


### E11-015 | The Invitation I Kept | 1877-11

After the late summer when I had finally allowed the tower door to remain open to visitors, invitations became a nuisance of surprising frequency. Lenz asked me to a family supper; Clara enclosed a note that no specimens would be discussed at the table. I wrote a refusal based on a perfectly real series of observations. Before sending it I found an old invitation from five years earlier among the bills, its corners worn by repeated handling. The experiment was not time-sensitive. I attended the supper with a bottle of gin I considered a respectable offering and discovered that Lenz's daughter had become quite opinionated about my manners. She asked why I always arrived wearing a coat suitable for an execution. I told her it improved the appearance of a happy gathering by contrast. She laughed. On returning to the tower I filed the invitation with correspondence rather than accounts. I laid the invitation among Kappel's letters, though it contained no argument or observation at all.


## The Long Correspondence and the Limits of Control


### E04-001 | The Case Opened at Last | 1878-03

The travelling case had sat beneath the east window for months, becoming such a fixture that Clara threatened to fill it with winter linen. I took the train to Munich and examined a collection of preserved plants, having entrusted the lamps to Lenz and the creatures' arrangements to Clara. I removed the old cracked metronome at the station when its weight offended me; a cherished error need not travel first class. Most of the collection was disappointing. One conservator, however, showed me how to record changes in illumination without disturbing a specimen. I copied his method and improved his chart on the journey home. The Queen had survived my absence without apparent distress. I called this proof that my arrangements were excellent. It was also a somewhat chilly welcome.


### E04-002 | The Botanist with Ink on Her Sleeve | 1878-09

Marta Voss had catalogued a botanical collection dismissed as too difficult for a woman by three gentlemen who could not identify half its specimens. I met her over a disputed entry. She showed me a dormant preparation recovered after a longer interval than I would have predicted, then produced the measurements before I could accuse her of relying on anecdote. Better still, she had read an unsigned paper of mine and found a fault in its conclusion without insulting its observations. At luncheon I asked for her address. She required, as a condition of correspondence, that I cease using the word 'provincial' to mean 'contrary to Pretorius.' I accepted no such constitutional amendment, but posted her a packet within the fortnight. She answered it, and in ink dark enough to be a challenge.


### E04-003 | The Letter in Three Hands | 1879-01

Voss returned my paper annotated in three hands, two inks and a pencil so sharp it had torn the margin. I objected that an argument ought at least to show its owner. Clara suggested that three naturalists might simply have worked at one table, a thought disappointingly plausible. The annotations challenged my interpretation of a creature moving toward a favorable condition as proof of preference. I wrote eleven pages in defense, discovered that the ninth contradicted the third, and sent two pages with additional observations. Voss wrote 'Useful' beneath the amended table. Heller had once bestowed the same parsimonious blessing. I had not expected a young botanist to revive the old irritation quite so efficiently. I asked her for the next objection before supper.


### E04-004 | The Picnic No One Had Planned | 1879-07

Voss came through Ingolstadt on business, and Clara arranged for all four of us to eat outdoors as if such a thing required no justification. Lenz brought eggs wrapped in newspaper. Voss carried a specimen box and placed it beneath the shade, then proceeded to speak for an hour about village gardens rather than botany. I disliked how swiftly she and Clara agreed that my appetite could not be trusted. Lenz spent most of the afternoon watching his daughter run at the edge of the water. For a moment I envied him the ease with which he could be both craftsman and father. Then the child asked me how a clock knew it was morning, and I was permitted to answer a question more pleasant than anything in my correspondence. Her father said I had frightened her only a little.


### E04-005 | The Mirror Kept Covered | 1880-02

The Devil had for years bowed to a looking glass with such magnificent affectation that I could not bear to deprive him of it. Voss uncovered the glass at irregular intervals and found that he sometimes approached, sometimes attended instead to the King's disturbances. She proposed that he liked movement rather than his own reflection. I objected that the two are scarcely enemies: vanity is often an appetite for a moving likeness. Our first arrangements could not separate the possibilities. We devised a less flattering test with changes of light and angle, and the creature continued to frustrate us. I retained his name. When he bowed again I bowed back, to Voss's evident despair. One need not resolve the mechanism of a performance to appreciate its style.


### E04-006 | A Copy Sent Without Permission | 1880-10

Kappel sent Voss a copy of an essay I had marked private. Her reply demolished a paragraph I had once considered unassailable. For several hours I was enchanted by the criticism, then remembered the insult to my ownership. I descended upon Kappel with a fury rehearsed all the way to town. He produced my original instruction: preserve the paper. I had forbidden its destruction, not its circulation. An omission, he said, was not a lock. I disliked him most when he was exact. I wrote Voss that the copy had travelled without my express permission and that her criticisms were nonetheless welcome. This was very nearly an apology, if read by a forgiving eye. She answered with further corrections. I filed them together, so that no one could mistake who had provoked the correspondence.


### E04-007 | The Prague Clockmaker | 1881-05

I travelled to Prague to meet Otto Faber, whose pendulums were said to resist changes in humidity better than those of his rivals. He listened politely to my complaints about the cracked metronome, then asked why I continued to use an instrument I did not trust. I said I had learned from its failure. He answered that I might now learn from a better one. His workshop smelled of beeswax and brass filings. I bought a calibrated timing device and kept the old metronome as a memento rather than forcing it to perform work for which it was no longer fit. When Lenz examined the new mechanism, he praised Faber's joints before mentioning its price. I was irritated to discover that a purchase could be both extravagant and correct.


### E07-001 | The Second Pendulum | 1881-07

My new timepiece had behaved impeccably until I carried it from Faber's workshop to a lodging whose walls were wet with August heat. The needle drifted by a small but intolerable amount. I returned to Prague with the instrument wrapped in a towel and my indignation left altogether uncovered. Faber compared it with his shop regulator, then put both beneath a bell and waited. They disagreed in a different direction. He refused to call either perfect, to my profound irritation. I proposed that a reliable instrument ought to survive a change of climate. He replied that I was describing a saint and that his profession dealt chiefly in metal. I paid for a second timing device and carried away the two together. Their differences became a column in the blue ledger. It was cheaper than certainty, though not by very much.


### E07-002 | A Parcel Marked Upright | 1881-10

Faber sent an exquisitely packed regulating spring, its crate painted with arrows pointing toward heaven. The railway company delivered it upside down. Lenz opened the box without comment and found the spring unharmed but the enclosing gauge dislodged. I wrote a complaint so elegant that it almost compensated for the journey. Lenz kept the crate, saying he could improve upon it, and returned the spring to its mount before supper. A week later he sent Faber a diagram of the improved packing wedges. Faber adopted them and wrote me a note of thanks for bringing the two workshops into correspondence. I had done nothing of the sort deliberately. The letter addressed itself to me, however, and I saw no reason to quarrel with the honor. The arrows remained visible on our storeroom wall long after their purpose had been exhausted.


### E04-008 | The Letter Recovered from a Fire | 1881-12

A chimney fire damaged Kappel's lodging and scorched the corner of the packet containing my early letters. He brought it to the tower without apology. I expected him to ask that I receive the papers back permanently. Instead he asked which should be copied first. We spent two evenings sorting his rescued books by the strength of their bindings and the value of their marginal notes. He spoke of retirement without complaint, as though a man might leave the guardianship of a library and remain himself. I was unsettled by how readily he described the change. Before going home he said that I should someday find another keeper for the blue ledger. I promised to consider it and did not. It was not his worst prediction of me.


### E07-003 | A Bacillus at Breakfast | 1882-04

Reuter laid a Berlin report beside the marmalade and spoke with uncommon animation of Koch's announcement concerning tuberculosis. The decisive thing, he said, was not the beauty of the organism but its demonstrable association with disease. I admired the discipline of the claim and objected to his pleasure in rendering a great mystery small enough to stain upon a slide. Voss observed that I had made my own living creatures small enough to stand in glass. There are occasions when a woman should be made to pay for her analogies. I purchased Reuter's breakfast instead. That afternoon he showed me a row of ordinary hospital notes whose exact dates mattered more than their eloquence. I had expected him to praise discovery. Instead he praised the clerks who made it possible to determine what had actually happened. I found the sentiment revoltingly sound.


### E04-009 | A Patient Walks Home | 1882-06

Reuter introduced a convalescent who came with a new hat, a bad cough, and complaints about his landlord. I pressed him to describe the period when his physicians had believed his life almost extinguished. He spoke instead of waking to discover the curtains had been changed and the rent was due. At last he asked whether I desired a more interesting memory. I told him I desired an accurate one. That ended our usefulness to one another. Reuter and I walked to a bakery, where the man had mentioned he could no longer afford his usual bread. I sent him a loaf by the porter and left no name. Reuter noticed, naturally. He had the irritating habit of noticing both what I did and what I pretended not to have done.


### E07-004 | A Specimen from No One | 1882-09

A parcel of marsh plants arrived without a collector's name. Voss refused to use it in a comparative series because she could not establish where or when it had been gathered. I argued that a plant possesses an anatomy irrespective of its shipping label. She answered that anatomy was not the only thing I proposed to infer. We dried one sample and kept another growing, giving the parcel a new number but no invented origin. Weeks later a shipping receipt surfaced; the plants came not from the coastal marsh indicated on the crate but from a garden inland. My hypothesis concerning salt tolerance became ridiculous. I was pleased to have discovered the error before I announced it, and less pleased to owe this discretion to Voss. I kept the false label where I would see it whenever I opened the drawer.


### E04-010 | The Queen and the Stranger | 1882-11

The Queen began approaching Voss whenever she entered the room. She had once shown the same inclination toward Clara; I had assumed it would eventually extend to the person who had made and sustained her. Evidently monarchy possesses no instinct for gratitude. I changed the hours of Voss's visits, rotated the vessel, checked the light, and still the little ingrate moved toward the newcomer. Voss said I was treating her as a student selecting a favored professor. I said a professor at least provides the education. Clara laughed so heartily that I nearly dismissed them both. I recorded every approach thereafter, including those occasions when the Queen came to my side, a detail which I confess gave the table a more agreeable appearance.


### E07-005 | The Man with Three Watches | 1883-02

Faber's apprentice Pavel wore three watches, none of which agreed, because one had belonged to his brother and two had belonged to customers who never returned. The sentimental one kept the worst time. Pavel nonetheless reached for it whenever a whistle sounded in the street. Faber called that habit irrational. I replied that its purpose might have nothing to do with hours. The young man showed us that the back of the watch contained a scratched date. He would not explain it. I refrained from asking, which Faber regarded as an ominous novelty. Later Pavel designed a spring clip for one of my instruments and refused payment in cash, asking instead for a letter attesting to his work. I supplied the letter. Its praise was exact, its grammar impeccable, and its final sentence copied from none of my former recommendations.


### E04-011 | Clara's Second Ledger | 1883-03

Clara kept a second ledger, not of my experiments but of prescriptions dispensed to people who could not pay. A merchant offered to buy the debts. I calculated what she stood to recover and urged her to accept. She declined because she knew the man's methods and apparently considered knowledge of character more valuable than ready coin. Three months later he was accused of extortionate collections. She took no pleasure in reminding me. She merely asked me to mend the cracked stool beside her till. I repaired it badly, was made to repair it again, and watched her account for medicines, customers, and favors that no bank would ever recognize as assets. Her shop was an organization of uncommon delicacy. I resolved not to call it a laboratory in her hearing; she would have charged me rent.


### E04-012 | The Room in Vienna | 1883-10

In Vienna, Voss secured us entry to a laboratory where my name would have closed the door. She introduced me as a private investigator, which was quite true and wounded my pride only slightly. The director showed us preserved cultures whose apparent activity depended upon the hour at which they were examined. We spent two days quarreling over development and persistence. Rainwater came through the lodging-house ceiling and erased the tables I had spread across my desk. Voss produced a pocket copy. I told her she had the instincts of a clerk, and she replied that they were especially useful in the company of philosophers. We reconstructed the figures over disagreeable coffee. I bought her a better notebook afterward, without presenting it as tribute. She returned it filled with objections and two unusually useful diagrams.


### E07-006 | The Color of the Night | 1883-11

The sky had acquired an evening tint so peculiar that the villagers speculated freely about fires, storms, and judgment. Voss made sketches of the changing colors, while Clara brought a small kettle upstairs and asked whether the spectacle could be enjoyed without a lecture. I did not consider this a serious question. We watched from the broken parapet until the air grew cold. I proposed three possible causes, each with admirable disadvantages. The next morning an apprentice's watercolor arrived from Prague showing a similar crimson streak. We kept our local drawing beside it, dates carefully written. I had expected an apparition worthy of private interpretation and found a phenomenon distributed across the ordinary sky. I was disappointed only in the monopoly. Clara said the kettle had boiled dry. That, at least, had been entirely our own failure.


### E07-007 | The Image Behind the Glass | 1883-12

Mathilde asked whether her new illustrated circular could include a wood engraving of the Queen. I wanted a splendid portrait; Voss wanted a scale bar; Mathilde wanted a block that would print. We achieved none of these at first. The engraver made the Queen taller than the King and furnished her with a crown she had never worn. I rejected the block for scientific reasons, though it was admittedly magnificent. Mathilde had a second cut made from a plain drawing by Lenz, with the glass walls included and a scale beside the vessel. The result lacked drama. It also showed what could actually be seen. I kept the first block wrapped in brown paper. There are falsehoods too aesthetically competent to deserve destruction, provided no one mistakes them for observations.


### E07-008 | The Envelope that Stayed Sealed | 1884-03

Voss asked me to post a letter addressed to her mother. It was sealed in pale green wax and lay beneath the notebook in which I had just drafted a conjecture concerning the Mermaid. At the station I realized the notebook was missing and went back along the platform searching beneath benches. The train had gone before I found it beneath a discarded timetable. The green envelope was still in my breast pocket. I sent it by the next post, then told Voss what had happened, expecting a rebuke about the delay. She asked first whether my notebook had survived. I was oddly irritated. Her letter had become more important to me than my pages during the search, and she had managed to reverse our declared priorities without raising her voice. I never opened the letter, though she had left it in my possession long enough for anyone less trustworthy to do so.


### E04-013 | A Week of Silence | 1884-05

Voss ceased answering my letters. I entertained illness, displeasure, and intellectual treachery in that order, although I admit the last possibility received a disproportionately handsome amount of attention. In June she sent pressed leaves and a note: her mother's sight was failing, and she had been occupied at home. My reply began by regretting her distress and continued, out of habit, into a discussion of the Mermaid's seasonal movements. I cut the scientific pages and posted the remainder. Voss later wrote that she would have welcomed the ordinary account of my work. It would have been a familiar thing, she said, amid unfamiliar troubles. I kept the rejected pages, which still smelled faintly of sealing wax. There are occasions when an observation offered at the wrong moment is an intrusion, and others when silence is the worse presumption. I had managed to select neither with confidence.


### E07-009 | The Garden with No Gate | 1884-08

Pavel visited Vienna carrying a replacement spring and insisted upon delivering it personally. Voss invited us into her family's narrow garden, where her mother sat beneath an apple tree sorting old labels by touch. The gate had been removed for repair; a stray dog wandered in and made off with the apprentice's lunch. He pursued it through the adjoining orchard. Her mother asked me how a professor of philosophy came to spend his days counting movements in miniature glass chambers. I gave the short version, which lasted seventeen minutes. She listened, then asked whether the creatures ever tired of being counted. I informed her that fatigue was a variable under investigation. She nodded as though I had answered the question. Later she returned a missing label to its precise place without sight enough to read it. I borrowed no philosophical conclusion from that modest feat. I remembered it nevertheless.


### E07-010 | The Unauthorized Abstract | 1884-11

A society circular repeated an abstract of my homunculus report under another man's name. It described the Queen as an ingenious mechanical figure, thus committing plagiarism and misunderstanding in the same sentence. Mathilde found the offending issue before I did and brought it to the tower with a pot of red ink. I wished to prosecute the author, publish the correction, and perhaps have him educated by force. Voss insisted that we first establish where his account had originated. The trail led to an intermediary who had copied only our illustration caption, omitting the qualifications attached to the drawing. I sent a correction limited to the false attribution and the mechanical claim. The culprit returned no apology. Mathilde printed our original caption in larger type, though it pleased her far less than a public duel would have done.


### E04-014 | The Devil's Reflection Refused | 1884-12

The Devil refused his mirror one December evening. I had promised a demonstration to two friends, and the creature chose instead to sit with his back toward us, exhibiting a most unscientific talent for embarrassment. The King was unusually quiet, the Ballerina would not answer her music, and the chamber had grown cold. We restored the heat. The next day the Devil resumed his devotions before the glass. I wrote down every condition I could identify and refused to credit the warmth alone. Clara observed that I had been trying to summon yesterday's behavior from today's creature. An objection I had already entered in the ledger, though expressed by her with far less elegance. I changed my heading from 'obstinacy' to 'altered conditions.' I continued to call him the Devil. It suited us both.


### E07-011 | A Bad Day for the King | 1885-01

Reuter arrived in January and found the King pressed beside the glass with one limb held at an alarming angle. I feared a return of the old injury. The physician did not accept the comparison and asked when the posture had begun. Lenz observed that a partition had shifted after the night's frost. We removed it and waited. The King moved slowly, then reached the Queen's side as though nothing extraordinary had occurred. Reuter urged continued observation rather than an heroic intervention. I accused him of practicing restraint as a form of vanity. He accepted the insult as if it had been a consultation fee. The next day I found myself hovering by the chamber more often than my own records prescribed. I moved my writing desk to improve the sightline, and told visitors it was for the better afternoon light.


### E07-012 | The Inn's Second Guest | 1885-05

We stopped at an inn whose landlord mistook Voss for my daughter and quoted a single room. She corrected the relationship without looking at me. I was tempted to improve his education in several directions, but she had already secured two rooms and a place for our specimens beside the cold cellar wall. At supper a stranger asked whether our crates contained explosives. I told him they contained something more offensive to the complacent. Voss said they were plants. He lost interest. In the morning one crate had been moved to make way for the inn's apples. Our records showed no damage, yet Voss insisted upon recording the interruption. I admired her exactitude and resented how effectively a simple answer had protected our work. We travelled on in silence until she produced a pear stolen, she said, from the breakfast tray. I ate half and said nothing of theft.


### E04-015 | The Salt Road to Trieste | 1885-08

Voss took me to Trieste in pursuit of marine preparations. The harbor had the smell of fish, wet rope, and commercial fraud. Our ordered specimens had been delivered to the wrong warehouse, where several had already spoiled. I questioned the shipping clerk until he wished to drown us both. The packing case Lenz had devised preserved what remained, and we returned with less material but rather better records than we had expected. Voss objected to the expense of pursuing such scant results. I replied that the cost of ignorance had never been reduced by remaining at home. This was a fine sentence and did not pay the invoices. The Mermaid became more active soon afterward. I attributed nothing to the journey without evidence, but I took a private satisfaction in the coincidence. One may enjoy a result before one understands it.


### E07-013 | The Apprentice's Correction | 1885-11

Pavel sent a new gauge with a note explaining that Faber's former design concealed a small lag at the return stroke. I assumed the young man had exaggerated a peculiarity to promote his invention. In Prague I tried the device beside its predecessor. The difference was real and, under one familiar condition, sufficient to invalidate a page of my old measurements. Faber observed my expression with a craftsman's detestable sympathy. I asked Pavel why he had not told me sooner. He answered that he had only just found a way to prove it. I bought the improved gauge and commissioned two more. His brother's watch still hung beside the window, its hands motionless. The lad no longer wore the other two. I had come to challenge his competence and left having increased my dependence upon it.


### E04-016 | The Strange Case on the Train | 1886-02

Voss brought Stevenson's new *Strange Case of Dr Jekyll and Mr Hyde* into our train compartment. She thought I would recognize myself in the divided physician. I said I recognized a man who had confused a chemical hypothesis with a sermon and then allowed his worse nature the better wardrobe. She objected that the horror lay in discovering one's conduct was not governed by one's professed principles. That, I replied, was scarcely a supernatural discovery; it occurred daily in faculty meetings. Yet I borrowed the book and read it a second time at the tower. I marked the pages in which Jekyll imagined he could separate appetite from responsibility by giving it another name. I did not tell Voss which passages I had marked. Nor did I return the volume promptly.


### E07-014 | The Trial with No Audience | 1886-05

We arranged a controlled observation of the Devil's response to reflections, concealing the mirror among several equally bright objects. Mathilde drew the order. Voss recorded the timings. I stood back and performed the difficult feat of permitting two women to conduct an investigation in my own laboratory without narrating each motion. The Devil attended first to a polished spoon, then ignored the mirror altogether. The following day he approached the mirror before the spoon. I had expected a tidy assertion of recognition and received a most unhelpful variety of attention. Mathilde found the uncertainty excellent for the next edition of the witness book. I found it unsuitable for the next edition of my reputation. We printed the result. The Devil remained quite unconcerned with either of our publishing interests and spent the afternoon examining the hem of his little black cape.


### E04-017 | A Printed Accusation | 1886-09

An unsigned notice in a professional journal condemned investigators who mistook stimulated tissue for independent life. I recognized several of my old opponents' phrases and immediately suspected Heller. I composed a reply of surgical exactness and malicious pleasure. Reuter asked me to identify the sentence which named either me or my work. There was none. Voss suggested that ordinary stupidity circulates quite freely without requiring an organized conspiracy. I retained the reply, unsigned and unsent, and folded the offending notice around Reuter's penciled words: 'No evidence of identification.' I still believe the author a fool. I am less certain that he enjoyed the privilege of being my particular enemy. This uncertainty did not make his prose any less objectionable.


### E07-015 | The Word Monster | 1886-10

A bookseller preparing a Gothic display suggested selling our old pamphlet beside tales of men whose experiments made monsters. Mathilde considered the extra trade. Voss thought the juxtaposition misleading. I declared that a monster was usually an object the observer had refused to understand, a principle useful enough to sell a dozen pamphlets. Then the bookseller requested a drawing with larger teeth. I informed him that my subjects possessed exactly the teeth supplied by nature and my own ingenuity, and that neither had undertaken work for his advertisement. We rejected the arrangement. After he departed Mathilde observed that I had declined an audience I had long begged the world to provide. I corrected her: I had declined *his* audience. We sold six copies that month, fewer than he promised, and the Queen remained unillustrated in his window.


### E04-018 | The Photograph on the Sill | 1887-04

Lenz's daughter, now a young woman, had taken an interest in photography and persuaded him to bring a camera to the tower. I permitted a portrait of the building, not of its inhabitants. She asked me to stand beside the doorway so that the scale might be understood. In the resulting plate I appeared taller and thinner than I had thought possible. Clara said the camera was an excellent corrective to vanity. I replied that it had made my ears absurd. The young woman offered to try again, but I kept the first print. Years later, when strangers described me as devilish, I suspected they had seen a photograph rather than a demon. The picture remained on the blue ledger's shelf, face inward when I was working.


### E07-016 | A Card Sent Back | 1887-09

Faber forwarded a note from Pavel announcing that he would leave Prague to establish a shop of his own. I drafted a reply congratulating him while recommending that he postpone the venture until he had learned something of the world's hostility to independent craftsmen. Voss read the letter and returned it with a single word written in the margin: 'Yours.' I removed the warning and signed a shorter card stating that I would continue to purchase his work if the standards remained high. In December his first independent instrument arrived, packed in wedges devised by Lenz, with a bill neither discounted nor apologetic. It worked. I paid within the week. The card came back months later because Pavel had used my signature as a reference when securing his premises. I kept the returned envelope, amused that a modest courtesy had acquired commercial consequences beyond my supervision.


### E04-019 | The Queen Does Not Perform | 1887-11

Voss brought two visitors who hoped my miniature court would perform for them like an expensive clock. The Queen sat still. The King made a deplorable spectacle of himself; the Archbishop opposed him as usual; the Ballerina stopped after a few bars. I reached toward the vessels to improve the exhibition. Clara touched my sleeve, and I withdrew my hand. There was no grandeur in the moment. The visitors left unimpressed, having paid nothing for the privilege of misunderstanding the most extraordinary beings in Bavaria. Voss called it a victory that the creatures had been permitted to disappoint us. I called it an unsuccessful demonstration. Nevertheless I did not rearrange the Queen the next morning. A compelled marvel is a very poor advertisement for independence, and I wanted independence to remain my discovery.


### E04-020 | A Death with an Address | 1888-06

Kappel died in June, having devoted the last of his strength to arranging books rather than composing farewells. His nephew delivered my old papers in a bundle tied with green tape. Inside lay the brass key I had surrendered years before, polished by handling and utterly useless to the lock it once opened. At the funeral someone introduced me as an acquaintance. I nearly corrected him with a list of the man's services to my work, then found the catalogue inadequate and held my tongue. Back at the tower I opened Kappel's last note. It concerned the copying of pages whose ink had begun to fade. Voss helped me sort them by candlelight. I set a second cup beside the ledger before remembering that the man who had always complained about my tea would not be arriving.


### E12-001 | The Brass Key after the Funeral | 1888-07

Kappel died in June. In July Voss brought a small box containing the brass key with which he had once opened the cabinet of rejected work. The lock had been replaced years before. She asked whether I wanted the key for my papers or whether she should return it to the estate. I said the object was obsolete. She laid it on the desk while we discussed cataloguing his surviving notes. After she left I tried the key against the tower drawers, an activity with no conceivable scientific value. It fitted none. I wrapped it in a square of paper and wrote his initials upon the outside, though the paper already bore his handwriting. For weeks I was impatient with people who used the word 'loss' in my presence. I did not lose Kappel through carelessness. The key remained in the upper drawer. I seldom open that drawer without checking that it is there.


## What Remained When the Room Grew Quiet


### E05-001 | The New Keeper | 1889-01

Kappel's papers occupied the spare chamber, and no amount of tidying restored their former keeper. Voss proposed placing a working copy of the blue ledger in Clara's dispensary. I protested that a shop was not an archive. Clara looked up at the damp stain on my ceiling and inquired whether a leaking ruin was one. We established a register of every transfer, complete with dates and signatures. I expected the process to waste a week. On its first morning we found a report on the Mermaid misfiled with instruments and an error in Kappel's last copy list. I would have preferred a loyal archivist to a bureaucracy; a bureaucracy, however, had the advantage of surviving a single man's illness. I disliked the admission sufficiently to insist that my own original ledger remain in the tower.


### E12-002 | The Friend at the End of the Table | 1889-03

Clara and Voss arranged Kappel's papers in the east chamber. They had divided his correspondence into subjects, dates, and matters which could not be reconciled by either. I objected to the third category as slovenly. Voss presented a letter in which Kappel described me as exacting but generous with time I did not think belonged to anyone else. Clara laughed at the accuracy of it. I demanded to know why he had not told me this while alive. She said he had tried repeatedly. We read no more of his personal observations that afternoon. Instead I asked to see his old catalogue, the one with corrections made in three shades of ink. I could recognize the years of his hand by the pressure of his pen. The two women left the third category in place. I never again insisted it be emptied merely to satisfy my need for a clean classification.


### E05-002 | A Visitor Who Asked About Pain | 1889-07

Reuter at last visited the tower. He passed over my homunculi's elegance without a compliment and watched the King push against the partition installed after his fall. Did the restriction distress him? I replied that it prevented another injury. Reuter observed that both statements might be true. He was too practiced a physician to expect a lecture to settle the question, and I was too practiced a philosopher to resist attempting one. Voss proposed recording the King's activity under different harmless arrangements. We did so, and the observations answered less than either of us wished. I altered the cleaning and maintenance schedule to minimize unnecessary interference. Reuter treated this as evidence of progress. I treated it as experimental housekeeping, which is a more respectable name for being influenced by an adversary.


### E12-003 | The Visitor's Second Glass | 1889-10

Reuter came with questions about fatigue in the small creatures and departed before supper. I had poured two glasses of gin, expecting that the argument would last longer. Voss arrived to collect notes and found me contemplating the untouched second glass. She asked whether I wished company. I told her I already possessed a rather demanding household behind glass. She sat anyway and spent half an hour reading quietly by the window while I annotated a table. We said almost nothing. When she rose to leave I realized I had reached the end of the table and begun writing in the margin. I offered her the second glass. She declined and asked for tea instead. The gin remained on the tray until morning. I had long said that conversation was the principal value of company. When Voss came the following Thursday, I had set out the teapot before I heard her on the stairs.


### E12-004 | The Correction Not Sent | 1890-01

Voss sent a manuscript in which she challenged an interpretation of the Mermaid's responses to changing salinity. I drafted a reply demolishing four minor errors and avoiding the central objection. Mathilde arrived for corrected proofs, read the first page at my invitation, and asked why Voss would be persuaded by criticisms she had already conceded. I said scientific debate requires that all errors be examined. Mathilde pointed to the untouched final paragraph. I rewrote the reply overnight, conceded that Voss's explanation fit the available observations, and requested a new trial. In the morning I considered restoring the original opening, which was immeasurably more elegant. I posted the shorter letter. Voss replied with a proposed experiment rather than a defense. There are colleagues whose agreement I value because it signifies admiration. Her disagreement was valuable for the more inconvenient reason that it continued to produce work.


### E05-003 | The Metronome Comes Apart | 1890-04

The cracked metronome had followed me from student rooms to the tower without keeping satisfactory time for most of the journey. Its spring finally broke while I was clearing a shelf. Lenz offered to replace it, but I asked him instead to open the case so I could see where the metal had fatigued. We laid the pieces on green felt, and he showed me the tiny points where repeated strain had done its quiet work. I was tempted to draw a metaphor about men of science. Lenz advised me to purchase a new spring before delivering a sermon. We repaired it, but I never used it again for measurement. It remained on the shelf as a reminder of error corrected, not a shrine to error perpetuated.


### E12-005 | The Things in My Pockets | 1890-08

Clara emptied the pockets of my coat before giving it to Lenz's wife for repair. Out came a broken measuring rule, a wax seal, two cigar ends, a folded shop bill, and a scrap on which the Queen's movements had been sketched in hurried figures. Clara regarded the collection as evidence that I was developing into a travelling rubbish cabinet. I told her it represented a portable scientific archive. The rule had once belonged to Kappel, the seal to Mathilde's early edition, and the bill carried Lenz's characteristic spelling of my name. I could have discarded all of them without compromising a single experiment. I put them back after the stitching was finished. At a later date I began using a small tin for the scraps, which was a concession to fabric rather than memory. My pockets have never been especially economical.


### E05-004 | The Woman in the Corridor | 1890-11

Voss sent for me while attending her mother in Vienna. She wished to ask a technical question about a botanical specimen, but the visit chiefly consisted of sitting in a corridor where cups were collected with a clatter at regular intervals. Her mother was growing blind, and the physicians had little to offer. I attempted to describe the difference between lost perception and lost understanding. Voss told me, very gently, that she was not conducting an inquiry. We sat without speaking. Before leaving I repaired the catch on the specimen box she had carried from home. She thanked me for coming. No result was published, and I remember the visit as one of the few occasions on which absence of useful speech was not a failure.


### E05-005 | A New Name on the Packing Case | 1891-05

Anna Lenz, whom I had once seen asking clocks whether they knew the hour, had become competent with photographic plates and inventory records. She labelled a crate of instruments with a code that allowed each item to be matched to its drawing. I told her the system was unnecessarily elaborate. She opened the crate and identified a damaged component before I could discover that the wrong object had been packed. Her father watched me concede the point with open enjoyment. Anna asked whether I preferred to be addressed as Professor or Doctor. I said the former was more historically interesting and the latter presently more useful. She called me Doctor and charged for the improved packing. I paid without bargaining and remembered the child at the river.


### E12-006 | The Apprentice's Own Signature | 1891-06

Anna delivered a newly repaired joint accompanied by her father's bill. The glass was sound, but the invoice bore a set of alterations in a hand I did not recognize. I crossed them out and marked the page for Jakob's approval. Anna returned the bill the next morning with the same figures, now signed in full. She explained that she had made the joint and had no intention of being paid through someone else's reputation. I protested that I had known her since she was scarcely tall enough to reach the bench. She replied that neither of us ought to be charging for work done at that height. I paid the invoice and asked her to examine an old valve I had trusted for years. She condemned it in six minutes. I was proud of the Lenz workshop and resentful of its apparent intention to supply the world with competent critics of me.


### E12-007 | A Name Written Smaller | 1891-09

Anna proposed engraving her initials on the base of the new glasswork so that future repairs might be traced to the proper maker. I said manufacturers had survived for centuries without turning every joint into a monument. Voss produced one of my first blue ledgers and showed me where I had complained of unacknowledged work at twenty. I accused them both of conspiring against a harmless preference for visual cleanliness. Anna offered to make the mark small enough that only a repairer could see it. I agreed. Six weeks later the mark allowed us to identify which batch of joints had a slight internal defect. I wrote to Anna congratulating her on the usefulness of the mark and said nothing about our original disagreement. It had been settled, after all, by data. She returned the letter with the word 'naturally' pencilled beneath my signature.


### E05-006 | A Night of Melted Snow | 1891-12

Snow slid from the tower roof and blocked the outer drain, sending water beneath the glass-room door. Clara arrived with towels; Anna arrived with a camera she had intended to use for an experiment and immediately put it aside. We carried every living vessel to the dry chamber. The Mermaid's jar was heavier than it looked, and I nearly dropped it when my foot slipped. Anna steadied my arm and told me to pay attention to the floor rather than the specimen. She was right. We lost several loose pages and a box of old labels but no creatures. The following week I insisted upon a new drainage channel. I paid for the work with money reserved for an optical experiment, and did not regret the exchange until the invoice arrived.


### E12-008 | A Cigar without an Audience | 1892-01

The winter evening was quiet enough that I heard the ticking of the damaged metronome in the next room. I lit a cigar after supper and read a reply from Voss disputing my projected dimensions for a larger living form. The letter was severe, precise, and accompanied by measurements I could not readily evade. I put it down, walked twice around the room, and allowed the cigar to burn out between my fingers. I was annoyed with Voss for being absent when I had finally constructed a response. I began a letter, abandoned it, and reopened hers. Near the end she had added that she would be in Vienna until March and hoped I would not neglect the little creatures while defending an impossible machine. I wrote back with the corrected dimensions first. Then, beneath my signature, I asked whether she would require anything from Ingolstadt. I did not include an explanation for the question.


### E05-007 | The Theory of a Larger Life | 1892-06

The enormous empty vessel still occupied the room it had been built too large to leave. Voss asked whether my desire for a full-sized creature was scientific or merely a protest against visitors who called my little people curiosities. I replied that the restriction of growth by scale was a legitimate problem and that her two explanations were not mutually exclusive. We drew separate plans: one for larger organization, one for observing the present creatures without interfering with them. The second required fewer resources and furnished the immediate work of a month. The first I locked away, not from shame but from the unpleasant knowledge that ambition is expensive before it becomes glorious. I examined the locked drawing every morning. A problem does not cease to exist because a sensible woman has supplied a cheaper one.


### E12-009 | The Parcel with No Instrument | 1892-08

A parcel came from Voss containing an old book and a packet of good coffee, but no measurements, specimens, or requests. I examined it twice for an accompanying problem. Clara said perhaps someone had simply sent me a present. I explained that scholars exchange tokens to maintain correspondence. She pointed out that Voss had already written twice that month. I placed the coffee in the kitchen and delayed opening it for several days, unwilling to make the gesture seem necessary. When I finally brewed it for Clara's visit, it proved remarkably good. I sent Voss a three-page note about an observation she had requested weeks earlier and appended one line about the coffee. Her next letter contained a small joke about my elaborate payment for a kindness. I retained the wrapping paper because it was excellent for protecting delicate specimens. That, at least, was the reason I supplied to anyone who noticed it.


### E05-008 | An Unanswerable Question of the Queen | 1892-10

The Queen began to grow still whenever we approached with certain instruments. Clara carrying fresh supplies produced no such effect. I called it anticipation. Voss asked whether odor, shape, or some regularity of our movements might suffice to explain it. We brought harmless objects to the bench and varied the observer, the order, and the light. The Queen was exquisitely uncooperative: responsive on one occasion, indifferent on another. I had made her, or at least had given the conditions in which she came to be; I had not instructed her to form expectations about me. If she had nevertheless acquired them, they might prove my deepest claim more decisively than any graceful limb. I was delighted by the thought and troubled by what those expectations might contain.


### E05-009 | The Letter I Did Send | 1893-03

I had drafted many letters to Henry in the years since his last reply, almost all unsent. This one was brief. I wrote that I remained concerned with living organization, that my smaller creations continued to survive, and that I hoped his own investigations had not brought him undue trouble. I enclosed no technical drawings. Voss examined the envelope, not the contents, and asked why I had waited so long. I told her that serious men should not burden one another with domestic sentiment. She said serious men were perfectly capable of deciding which letters to answer. I posted it myself. No reply came. I do not know whether he received it. I have been tempted to write an entire theory to explain that uncertainty, but it remains only a missing answer.


### E12-010 | The Envelope from Henry | 1893-04

I had sent Henry a letter in March after years of attempting to compose one that would be neither a plea nor an indictment. In April I caught myself listening for the postman's steps while pretending to measure the light at the window. Mathilde arrived with a proof and saw the addressed envelope lying beside a second sheet upon which I had begun writing another explanation. She asked whether the first letter had contained a question. It had contained several. She asked why I was attempting to answer them before their recipient had read them. I tore the second sheet in two and put the pieces in the stove. The postman came that afternoon with a receipt for chemicals and no reply. I was perfectly capable of continuing the experiment. I repeated one set of measurements needlessly. The figures did not improve merely because I was paying them extra attention.


### E08-001 | The Letter with Two Endings | 1893-06

The letter I had at last sent to Henry in March left behind two discarded endings. One asked him to write about the work. The other asked whether he still remembered our evenings disputing the shape of life over badly trimmed lamps. Voss read neither, but Mathilde, collecting papers for binding, discovered both beneath the blotter. She offered to destroy them. I declined. A man may reject a sentence without condemning it to death. Weeks passed without an answer. When another parcel arrived from the post, I went to the door with an eagerness sufficiently vulgar to annoy me. It contained an invoice for paper. I paid it late. Mathilde said I had begun handling every foreign envelope as though it were explosive. I instructed her to improve the postal system rather than my temperament.


### E08-002 | The Photograph of a Hand | 1893-09

Anna took a photograph of her father's injured hand resting beside a newly finished glass joint. She intended it as a study of texture and asked whether I wished to examine the plate. The scar stood out pale against the dark wood; the delicate joint seemed almost impossibly thin. I suggested a second exposure with the hand withdrawn, for comparison. She made it and placed the two prints before me without comment. The joint appeared smaller in the first because the hand supplied a measure; in the second it looked like an object belonging to no scale at all. Anna said she would title the first 'The Maker.' Her father disliked the title and requested that she call it 'Thursday.' We settled on the date in the catalogue and left the family argument unresolved. I bought a copy and kept it beside Kappel's list of repaired instruments.


### E05-010 | The Sound Behind the Wall | 1893-11

A rhythmic tapping began behind the west chamber wall, usually after midnight. I assumed some animal had made a nest. Anna proposed that the newly fitted drain was transmitting movement from the outer gutter. Lenz tapped the pipe and reproduced the sound almost exactly. I was disappointed not to discover an intruder but satisfied to discover a mechanism. The tapping had disturbed the Ballerina's rest, and she had begun refusing music on the following mornings. We wrapped the pipe and shifted her vessel by a hand's breadth. The rhythm ceased and the dancing returned, though I recorded no claim of causation beyond the sequence. Anna asked whether the old professor still believed every peculiar noise was a plot. I said only the interesting ones.


### E08-003 | The Case of the Undead Sentence | 1894-01

Voss sent a note about an English editor who wanted the Queen's history reduced to three columns. Mathilde set a sample page. To fit the space she had removed the sentences in which I confessed uncertainty about the Queen's response to a familiar sound. Voss wrote that this made the piece more exciting and less true. I quite agreed, though I resented discovering that we had arrived together at so dreary a position. We restored the missing sentences and cut a more handsome passage concerning the insufficiency of modern universities. Its sacrifice hurt more than I should have expected. The editor declined the shortened article. Mathilde used the rejected setting to wrap a parcel of ordinary stationery, a fate that would have distressed a lesser author. I rescued one page before it could be folded around the ink bottles.


### E12-011 | The Room That Could Be Vacant | 1894-03

Clara missed our agreed Thursday visit, and Mathilde came to deliver pages that required signature. She found the second cup set out beside the kettle. I told her I had expected a clerk from town. She accepted this falsehood with the courtesy due a man behaving foolishly in his own house. We discussed the layout of a pamphlet, and she asked where the names of absent contributors were to appear. I said names belonged to the work actually done. She suggested that Clara's maintenance of the records had made the work possible, though few of her acts were included among the experiments. I added Clara's name to the acknowledgments and then objected to the word 'assistance' as insufficiently precise. We argued over a better phrase until the kettle boiled dry. I had preferred a vacant room to an obligation for many years. I kept the proof at my desk until Clara could examine the altered wording for herself.


### E05-011 | The Farewell That Was Not One | 1894-07

Clara informed me that she intended to reduce her hours and transfer much of the business to an assistant. I immediately asked whether the tower could still obtain its customary supplies. She looked at me until I understood what I had made of the announcement. She was tired, she said, and wished to spend some mornings reading without a queue at her counter. I congratulated her poorly. On my next visit I brought a chair cushion, having noticed that the one beside the window had gone flat. We drank tea and discussed the weather. When I left, she asked that I continue calling even on days when I required nothing from the shop. I answered that I could not imagine why I should do otherwise. I began doing so the following Thursday.


### E08-004 | The Surgeon in a Yellow Book | 1894-12

A London volume containing Machen's *The Great God Pan* reached me through Mathilde's book trade. Here was another physician opening an alleged door between matter and spirit, with a patient made to bear the cost of his revelation. The tale was artful in its withholding of evidence and extravagant in its confidence about consequences. Voss asked why I had spent an entire evening with a book I called preposterous. I said I was studying the rhetoric by which a sensational author conceals the gaps in his argument. She pointed toward three of my own manuscripts lying unfinished on the table. I closed the book rather harder than necessary. Later I reopened it to the passage in which Raymond speaks of knowledge acquired through one irreversible act. I wrote in the margin that success in seeing was not success in understanding. I left the volume visible when Mathilde next called, which she interpreted quite correctly as an invitation to quarrel.


### E08-005 | The Unclaimed Seat | 1895-01

Clara had begun opening her shop late on Thursdays. I went at the former hour and found the front door locked, an event which my dignity ought to have endured without comment. Mathilde arrived carrying proofs and asked why I stood outside as though waiting for an execution. We went round to Clara's garden instead. She was reading in a chair and appeared neither ill nor repentant. I insisted that she should have changed the sign. She said she had changed it the previous month. I had merely stopped looking. We drank coffee at the garden table; Mathilde corrected a page; Clara returned to her book whenever the conversation grew tedious. The Thursday visits thereafter shifted to the garden if the weather permitted. I continued to call this an arrangement for reviewing proofs, although we reviewed almost none during the following summer.


### E05-012 | The Inventory of Failures | 1895-02

Anna proposed photographing every damaged joint before another order could repeat the mistake. Voss demanded a register of discarded hypotheses as well. Thus three afternoons vanished into the compilation of a formidable inventory of my misfortunes: warped vessels, false revivals, the Archbishop's misleading gestures, inconsistent growth, and one enormous container that would not pass through a door. Anna weighed the finished book against the catalogue of my published successes and found the former heavier. She expected me to be offended. I informed her that failures are naturally more numerous because most of nature is arranged to resist the improvement of philosophers. A month later the book saved us from repeating an optical error. I granted the catalogue a permanent place, although not on the shelf reserved for the achievements of which I was proudest.


### E12-012 | A Glass of Water before the Lecture | 1895-04

Reuter asked me to address a small gathering of physicians on the distinction between muscular response and sustained life. I prepared a splendid opening calculated to make their ordinary proceedings appear scarcely worth the hire of the room. Clara attended, though she had reduced her work at the dispensary. Before I spoke she handed me a glass of water and said that half my audience had been awake through the night. I began with an actual observation instead. The argument survived without my opening insult, and several physicians remained afterward to discuss the method. Reuter called the evening a success. I said it lacked its proper dramatic introduction. At home I wrote the abandoned opening into my private notes, where it remains pleasing, useless, and rather cruel to men who had given up their sleep to listen. I still enjoy the sentence. I simply did not deliver it.


### E08-006 | The Locked Cabinet of Reactions | 1895-06

Reuter asked whether the little people might become exhausted by repeated observation. I answered that I had already limited the trials. Anna brought out my schedule and showed that a day of 'rest' often contained several unscheduled visitors demanding a glimpse. I informed her that a visit was not necessarily an experiment. Reuter asked whether the subjects knew the distinction. We closed the west cabinet to casual display for one month, leaving its ordinary ventilation unchanged and entering each approach in a separate book. The visitors were displeased. The Queen grew no more demonstrably content, though her periods of retreat altered. I refused to call this proof of distress. I also refused to reopen the door when a gentleman from the town offered a considerable sum to look inside. Some boundaries are easier to defend when their breach has acquired a price.


### E05-013 | A New Instrument, an Old Bias | 1895-10

Faber's new timing instrument could divide an interval with exquisite delicacy. I used it upon the King's movements and announced improved regularity. Voss examined the original records and found I had shifted the instant at which each interval began. The correction disposed of my discovery. Faber wrote that even a perfect mechanism could not cure an observer of imprecision. I placed his note beside the dial, where guests might admire the wit without knowing its victim. Privately I recalculated three old experiments and discovered that one result, dismissed years before, had been more substantial than I believed. I did not announce a triumph. I marked the page for repetition. Instruments sometimes correct a man's conceit and sometimes vindicate his suspicion; only the first outcome is generally told with pleasure by his friends.


### E08-007 | The Hand Beneath the Rays | 1896-02

Reports of Röntgen's new rays had circulated for weeks when Anna persuaded us to attend a demonstration of their photographic effects. A hand appeared upon the plate with its bones pale against the dark, stripped of the familiar flesh that makes a gesture recognizable. Anna studied the image longer than I did. I asked what use could be made of the method for examining sealed vessels without disturbing their contents. Voss asked what evidence I imagined a shadow would supply about life. We returned with no apparatus, only an illustrated notice and a disagreeably large collection of questions. I laid Anna's photograph of her father's hand beside the new printed plate. One celebrated surface; the other disclosed a structure concealed beneath it. Neither told me why Lenz continued to labor with a finger that pained him. I did not mention this last deficiency to the demonstrator.


### E05-014 | A Book from England | 1896-04

Voss sent me Wells's *The Island of Doctor Moreau*, and I read it by the east window while the repaired drain rattled in the rain. Moreau was an ambitious man, which did not excuse his vulgarity. His creatures were made to obey laws they had not devised and punished for failing to remain what their maker wished. The author arranged the matter so that scientific cruelty could be recognized even by readers who disliked science. I objected to the simplification in the margin. Then I thought of Reuter watching the King press against his partition and wrote a longer objection which was not altogether directed at Wells. I called the novel sensational, manipulative, and distressingly difficult to dismiss. Voss asked if I had enjoyed it. I said I had read it twice, which ought to have sufficed.


### E08-008 | The Borrowed Page from Poe | 1896-07

Voss sent me a copy of Poe's account of M. Valdemar, marked at the opening assertion that a disputed marvel must be presented as facts. She asked what difference separated that device from my own pamphlets. I wrote that Poe was a fabulist and I was a witness. Then I examined the earliest printed description of the Queen and discovered that several claims appeared there without the qualifications present in the original ledger. Mathilde had not inserted them; I had removed them while revising. I sent Voss a more candid answer and requested that the earliest issue be marked superseded in future catalogues. She agreed, provided I write the notice myself. I did so without confessing that a tale of mesmerism had obliged me to correct a scientific publication. The little bird from Rosen's shop still whistled whenever its spring caught, an absurd accompaniment to this editorial surgery.


### E12-013 | The Photograph with an Empty Place | 1896-09

Anna arranged to photograph the small instruments and their makers before several older pieces were dismantled for repair. I stood beside the workbench while she placed Lenz and Voss where the window light would reach their hands. I objected that the arrangement made me appear a visitor to my own laboratory. She asked whether I wished the instruments or my person documented. I replied that the one explained the other. She took two exposures and left an empty space in the first where Clara might have stood had she been able to come. When the prints arrived I preferred the less flattering one because Lenz's scarred hand was visible against the glass. I could not remember when I had begun thinking of that hand as part of the apparatus. Anna gave me the second print. I placed it in the ledger rather than hang it where visitors might ask for the names.


### E08-009 | The Train Ticket in the Book | 1896-11

Voss returned Machen's volume with a train ticket between its pages. It bore the date of her mother's last journey before the household had become largely confined to Vienna. I assumed she had placed it there deliberately and prepared a sentence suited to personal consolation, a genre in which I have never excelled. She said she had used it merely to mark her place. I replied that its utility was obvious and placed it back inside the book. Months later I found the ticket in the page describing an irreparable experiment and wondered whether she had been telling the truth about its accidental position. I had no evidence either way. I did not remove it. On a subsequent visit she borrowed the book again and returned it without the ticket. I found the disappearance more affecting than I cared to examine.


### E05-015 | The Empty Place beside the Piano | 1896-12

Clara seldom visited the tower in winter, and the Ballerina had not heard her beloved Mendelssohn competently played for weeks. Anna volunteered to learn the passage. I said the creature might respond to Clara's touch rather than the notes; Anna, apparently incapable of being discouraged by a reasonable objection, practiced after her day's work. On the fourth attempt the Ballerina danced. I declared the experiment successful and sent Clara the news. She wrote that she was glad to be relieved of a duty I had apparently assigned to her for life. The old music pages remained beside the piano after Anna brought a clean copy. I could have put them away. For several winters I had known exactly when Clara would arrive by the sound of her boots below the stairs, and a new pianist could not reproduce that particular prelude.


### E08-010 | A Young Woman's Signature | 1897-02

Anna asked that new shipping agreements carry her own signature rather than her father's. Jakob appeared entirely willing, which I found both generous and surprisingly careless. He said she had been managing the photographic records and a portion of the accounts for some time. I proposed adding my name as guarantor. Anna thanked me and declined. The first crate sent under her signature arrived with its contents arranged more sensibly than in any of Jakob's earlier packages, although I was careful not to say so within his hearing. A second came late because she had accepted another commission. I complained. She forwarded a copy of the terms showing that I had ordered no priority. I paid for expedited service next time. Her independence was excellent when directed against inefficiency in others and altogether less charming when it cost me money.


### E05-016 | The London Address | 1897-08

Agnes Bell, a London translator acquainted with Voss, asked for an account that could be separated from its author's reputation. An admirably rude request. I sent her the Queen's avoidance of certain instruments, including observations which weakened my favored interpretation. She translated the report without strengthening its conclusions, a restraint rare enough to merit praise. At a meeting, someone inquired whether my professorial title remained valid. Bell replied that dismissal did not render a man's measurements false. Later, over a supper notable chiefly for its bad fish, she said she had defended the evidence rather than its author. I answered that this was precisely why I had trusted her with it. She seemed surprised. I was not. I had learned, after some expense, to prefer an ally who could distinguish me from my legend.


### E08-011 | The Count in the New Novel | 1897-09

Bell dispatched Stoker's newly published *Dracula* with a note praising its assemblage of diaries, letters, and mechanical recordings. I expected a melodrama of blood and superstition. I found instead that the most persuasive passages were those in which imperfect witnesses compared their accounts, corrected their errors, and discovered the limits of any solitary observer. A hateful lesson to learn from a book with a vampire in it. Mathilde preferred the passages about the typewriter and the speed with which Mina organized a confused record. I objected that filing papers was a lesser art than generating knowledge. She asked where my knowledge would be after the next fire. I handed her the oldest box of loose correspondence and permitted another index. I refused to call it a tribute to Mr. Stoker, who had enough admirers already.


### E08-012 | The Portrait Not for Sale | 1897-10

A dealer offered a handsome price for Anna's photograph of me beside the tower doorway. He described the ears as a marvel of physiognomy and proposed selling the print in a cabinet of monsters. I said his cabinet was surely already occupied by critics. Mathilde advised that refusing publication would merely increase the rumor. Anna observed that the negative belonged to her, and that she did not wish to supply a curiosity stall. The decision was therefore taken by a young woman whose professional property I had almost forgotten to recognize. We asked the dealer to purchase an ordinary photograph of the tower, without me in it. He declined. Anna produced another print for our records, framed the original view according to her own taste, and kept the negative. I called this a tolerable resolution. She called it hers.


### E12-014 | The Voice in the Other Letter | 1897-12

Bell wrote from London after our exchange about printed accounts of the extraordinary. She said my objections to the new novel's elaborate collection of diaries were persuasive, but that no single narrator could know everything his companions had concealed. Mathilde, sorting proofs beside the fire, asked whether Bell knew I had written a private record of my own work. I said my record was sufficient for its purpose. She said it contained very little of what the others thought while I was speaking. I suggested that their thoughts belonged to their own notebooks. That evening I attempted to reconstruct an argument with Voss from memory and discovered that I could reproduce my position in exquisite detail while failing to recall her first sentence. I wrote to ask her for her version. The reply corrected a minor fact and an entire motive. I kept both accounts. Neither was particularly flattering.


### E08-013 | The Page Kappel Never Numbered | 1898-01

While Clara and Mathilde sorted the inherited papers, we found an unnumbered sheet in Kappel's hand. It contained a list of things borrowed from me and never returned: a lens, a set of maps, one blue ribbon, and an umbrella. The last item made me think of the scholar whose obituary I had kept years before. Clara laughed at the ribbon. I claimed no recollection of it, although I distinctly remembered binding Henry's first drawings with something blue. The list offered no proof. I copied the items into the secondary archive and resisted turning the sheet into a sentimental relic. Nevertheless I kept the original on the table all afternoon, beside Kappel's old magnifying glass. That evening I used his numbering convention for the first time without altering it to suit my preferences. It was a sufficient memorial, more useful than flowers.


### E05-017 | What the Queen Had Not Forgotten | 1898-02

Anna set a new wooden stand beside the Queen's glass. The little sovereign withdrew at once, much as she had years earlier when a certain clamp approached. Anna noticed the resemblance of outline. We tried an innocuous duplicate and observed another retreat. Voss rightly objected that shape alone did not establish remembered experience. I made the objection sharper: without a known account of the intervening years, we could not say what had been preserved or how. But the possibility was intoxicating. I searched the blue ledger and found my old description of the first disturbance: 'trivial.' I had dismissed an incident which might have endured within the creature long after it had ceased to occupy my mind. I underlined the word, resisting the temptation to improve the record. It was not my finest sentence. It might yet prove important.


### E08-014 | The Cup with the Chipped Rim | 1898-04

Clara poured tea into the cup with the chipped rim because it was, she said, the one I always took. I had no memory of choosing it. Voss arrived later with seedlings in a paper wrap and remarked that I placed the cup at the same angle whenever I read. We tested the assertion twice, which was absurd, and discovered that I did so even when the handle was on the wrong side. Clara laughed until she coughed. I objected that an habitual motion was not a theory of character. Neither woman suggested otherwise. By evening the seedlings stood beneath the garden wall and my cup was in the washing bowl. I asked Clara whether she intended to replace it. She said not while it remained useful. On my next visit it was waiting in its familiar place. I regarded the matter as settled and was privately relieved.


### E05-018 | The Visit to Clara's Garden | 1898-07

Clara had taken to keeping herbs and bees behind her house. I visited one July afternoon without needing a bottle, an instrument, or a favor. She asked my opinion of a sickly plant. I pronounced on its leaves, twice and incorrectly, until she lifted a paving stone and showed me how the roots had been crowded. We moved the stone, drank warm tea, and watched bees make an industry of the thyme. I spoke of the lives I had brought forth. Clara replied that her garden had never once obeyed her merely because she planted it. I said my case was rather different. She handed me the watering can without further dispute. The plant recovered. On my next visit I brought a drawing of its roots, and she used the reverse of the paper to write a shopping list.


### E08-015 | The Man Who Wanted a Cure | 1898-08

A merchant whose son had lost the use of an arm sought me out through Reuter. He had heard that I made living bodies where ordinary doctors found only damage. I was tempted to offer a grand account of my accomplishments. Reuter asked me to explain what I could actually do for the boy. I had no treatment to offer, and the father was not interested in a lecture on the future of science. We discussed a brace being prepared by a local craftsman, then let him go. Later, Voss said she had never heard me speak so little to a paying visitor. I replied that he had come seeking medicine, not philosophy, and I did not possess the commodity he required. His disappointment was sharper than most committee judgments. I do not claim it improved me. I remember that he thanked Reuter and did not thank me.


### E12-015 | The Mirror Turned to the Wall | 1898-10

Preparations for the larger laboratory had revived my habit of performing grand conclusions before the figures could sustain them. Voss brought a design objection; Anna brought an estimate; Clara brought the Queen's recent record of avoiding particular instruments. I had intended to present a comprehensive account of my progress. Instead we spent the afternoon moving a mirror away from the vessel and observing whether the Queen returned to her usual ledge. She did, though not at once. Anna made a note of the interval. Voss said I was capable of treating an uncertain result with patience when it happened to occupy a glass jar. I objected that the jar was a controlled world and the larger apparatus an unfinished one. After they left, I began the address again before the empty workbench. It sounded magnificent. I folded it into a drawer and kept the Queen's observation sheet upon the desk. Before bed I took the folded speech out again, read its opening two lines, and returned it to the drawer without correcting them.


### E05-019 | The Scale Model of an Impossible Room | 1898-11

I laid out plans for a laboratory large enough to support a form of life the public could no longer dismiss as a charming smallness. Lenz measured the stairwell and laughed in a manner which I have never encouraged. Anna constructed a paper model and demonstrated that the central apparatus could not round the entrance passage. Voss asked what observations justified its dimensions. I had estimates, hopes, and a theory still too young to be publicly insulted. I did not order the construction. The model went beside the catalogue of failures, its paper walls carefully repaired where Anna had cut them to demonstrate the problem. It was not a surrender. I continued drawing alternative entrances long after the others had gone, one candle burning down into the saucer. The larger creature existed already as a demand upon my imagination, if nowhere else.


### E08-016 | A Place for the Unwritten | 1898-12

Anna's paper model of the impossible larger laboratory occupied half my desk. Beside it stood the little witness book, the false engraving with its invented crown, Kappel's unnumbered sheet, and a square of brown paper that Mathilde had labelled 'unverified.' Voss objected to using that label for a drawer full of ideas rather than observations. We agreed upon 'uncompleted,' a word with the merit of recording neither failure nor success. I put Henry's oldest drawing into the drawer and then took it out again. It belonged with the letters, where its author remained unmistakable. Anna measured the window before she left and said a larger table could be carried up the stairs if we removed its legs. I asked her to prepare a sketch, not a purchase order. The Queen remained upon her favored ledge while we extinguished the lamps. I had no resolution to announce. There was work enough for the following year, and no one present mistook that for a promise of immortality.


### E05-020 | A Rumor with a Familiar Name | 1899-03

Bell enclosed a newspaper clipping concerning a Frankenstein said to have restored motion to dead flesh and brought catastrophe upon himself. A surname in print is a poor identification, especially when journalists are permitted to decorate it. I read the report twice for names, witnesses, and inconsistencies, then searched for Henry's old unsigned drawings. His scheme of assembly lay beside my notes on growth, as it had thirty-four years before beneath a smoking lamp. Voss asked if I intended to write him. I answered that I first intended to discover whether the man in the report was alive. She watched me longer than the answer deserved. I was not certain whether I wished to see my former pupil vindicated, or to discover the one thing he might have done without me. I did know that I disliked learning of it through a newspaper.


### E05-021 | The News from the Windmill | 1899-06

The second account came in June, and with it a confirmation from a correspondent not given to the more picturesque forms of falsehood. Henry Frankenstein had brought a being to life from dead flesh. The creature had survived the fire at a windmill. Henry was alive. I entered the claims, their sources, and the matters still concealed from me in the blue ledger. The diagram of separate organs lay open on the table, its corners curled with age. Henry had pursued assembly while I pursued growth, and there, at last, was a result no committee could dismiss by refusing to inspect it. Anna asked whether I would seek him. Voss asked what I would want when I found him. I closed the travelling case and looked through the east window toward the road. I offered neither woman an answer. The Queen moved upon her ledge behind me. I remained in the tower that night, with the old drawings spread beneath my hand.
