# The Lost Years of Doctor Septimus Pretorius, v4

Personality-formation expansion. This is a fictional first-person reconstruction designed for a persistent-character experiment, not a report about a real man's verified mental history.

`Pretorius_The_Lost_Years_v4_Complete_Autobiography.md` contains all 210 first-person memories in worldwide chronological order, ending in June 1899.

`Pretorius_v4_Four_New_Formative_Episodes.md` contains the 60 new memories only, grouped in four linked thematic episodes.

`Pretorius_All_Memories_v4_210.jsonl` is the full schema-rich structured dataset. `Pretorius_Formative_Memories_New_60.jsonl` contains only the additional records. `Pretorius_v4_Formative_Recall_Edges.jsonl` contains candidate causal retrieval edges, separately labeled inferred. `Pretorius_v4_Causal_Hypotheses.json` maps 15 hypothetical personality-formation mechanisms to event references and test predictions.

`Pretorius_v4_Psychological_Formation_Profile.md` distinguishes source canon, constructed narrative details, speculative psychological mechanisms, alternative explanations, and testable behavior predictions.

`Pretorius_v4_Continuity_Ledger.md` carries the cumulative source and continuity constraints. `Pretorius_v4_Production_Report.md` describes production scope, uncertainty, duplicate screening and validation. `Pretorius_v4_Validation.json` contains machine-read audit figures.

No Gothic crossover person is presented as an established acquaintance. No memory occurs after the windmill news, and no reunion, Bride, or Frankenstein Village story is included. The original autobiography is not overwritten.
