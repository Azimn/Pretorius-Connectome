# Continuity Addendum, Film-Legacy Expansion v6

This is an addition to the existing v4/v5 continuity ledger, not a replacement. All 210 earlier event IDs and narrative texts are retained. New scenes E13-001 through E15-016 are explicitly fictional reconstructions.

## Leonie Rausch

Introduced in 1861 as a theatre craftswoman. She teaches Pretorius how staging shapes an audience's attention, disputes uncredited labor and his acts of social deflection, and supplies the pin in blue cloth later held in a locked theatre-property box. She has independent work, friendships, physical limitations and judgments. As of September 1898 she is living but increasingly slow on the stairs. Do not invent her death. Her 1864 meeting with Henry must follow his autumn 1864 initial encounter.

## Georg and Matthias Eberle

Georg is cemetery caretaker, first met in 1872. The mortuary supper occurs with Georg and Leonie in October 1872 and is an antecedent habit, not a replay of later film action. Georg has a temporary episode of illness in 1883; his younger brother dies before March 1892. Georg is living at his last appearance. Father Matthias, Georg's priest cousin, challenges Pretorius through careful observations and his own faithful and practical convictions. No conversion to Pretorius's ideology is invented.

## Julian Adler

A Viennese dealer and instrument restorer introduced February 1885. He has an injured left hand which affects violin playing, an estranged brother, and independent professional obligations. His gaze toward Pretorius and his offer of hospitality do not establish a sexual identity or romance; these remain uncertain through the narrator's limited perspective. Pretorius violates a boundary by reading a letter addressed to Voss in 1890. His association with Julian is repaired tentatively by 1891 and their later professional respect endures. Julian is not a subordinate or an ownership claim.

## Scientific creation, personality, repeated objects

The Queen is first created in the original pre-1868 chronology. Later experiments establish preferences concerning cloth, a crown and access to a narrow passage, without proving human-like motivations. The King's responses to motion complicate Pretorius's romantic interpretation. The little Devil and Archbishop remain as the prior six-character court. A proposed larger chamber with two doors is not a built or completed experiment as of September 1898. The blue ledger, black velvet, inexpensive gin, cigar case, theatre box, violin case and small red-thread key recur without being treated as supernatural objects.

## Sources and boundaries

Film scholarship is a lens used by the editor, never a record of a nineteenth-century event. The University of Ingolstadt's historical relocation discrepancy remains flagged in the original ledger. Kappel dies in June 1888 according to existing reconstructed continuity. The canonical ending remains E05-021 (June 1899): the report that Henry and the creature survived, before any reunion. No Bride, post-film fate, or Frankenstein Village events are included.

Unresolved: Leonie's eventual health, Julian's family estrangement, the status of the Queen's decisions, the clergy's ongoing assessment of the homunculi, the viability of a larger creature, and the uncertain scale of Pretorius's capacity for equal collaboration.
