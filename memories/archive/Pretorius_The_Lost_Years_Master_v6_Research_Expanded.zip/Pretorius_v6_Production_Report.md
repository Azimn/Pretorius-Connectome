# Production Report: Edition v6

This edition adds **50 complete original reconstructed autobiographical events** to the **210 preserved prior events**, for **260 total events** and **15 episode IDs**. The new memories contain **8,702 words**; the combined autobiographical records contain **37,746 words**. The entire historical span is September 1859 to June 1899; the new scenes occur March 1861 to September 1898.

All original event IDs and original `memory_text` strings are unchanged. The ordinal `chronological_order` is renumbered from 1 through 260 for the new interleaving, and should not be used as a stable reference between v5 and v6. Semantic cross-references use stable event IDs.

All required fields are populated for new memories, including prior expectations, observations, choices, consequences, relationship changes, recall cues and cross-event links. No added memory occurs after the terminal June 1899 event E05-021. Every link refers to an earlier dated record. No event is designated established merely because a film critic discussed a similar motive.

Near-duplicate screen threshold: Jaccard token similarity 0.56, with **0 possible matches**; the screen cannot guarantee absence of semantic redundancy. Chronology corrections performed to new scenes only: the Henry side-room encounter now occurs December 1864 after the established first meeting, and Marta's 1878 cemetery scene is dated November 1878 after her documented introduction within the prior reconstruction.

Scholarly distinctions: original cinematic characterization, contested queer/camp readings, 1930s production censorship, modern commercial legacy, and invented biography are kept separate. The source Ingolstadt institutional anachronism is flagged, not silently repaired. Existing 15 psychological formation mechanisms retain their hypothesis status, as do six new film-informed test hypotheses, not clinical diagnoses.

**Unresolved:** Julian's personal life and family, Leonie's health, the Queen's agency, Georg and Matthias's ongoing views, adult-scale creation. **Next checkpoint:** E05-021, June 1899, news of Henry's survival. This is an absolute stop for this historical corpus.
