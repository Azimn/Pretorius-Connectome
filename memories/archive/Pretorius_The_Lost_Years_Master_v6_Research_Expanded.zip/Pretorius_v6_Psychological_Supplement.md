# Additional Personality-Formation Hypotheses: The Film Legacy

These six extensions supplement, rather than replace, the 15 previously documented mechanisms. They are inferred from new fictional reconstructions inspired by interpretive work on the film. They are neither clinical diagnoses nor assertions about a real person.

## M16 | Theatricality as learned control of attention

**Evidence within reconstruction:** E13-001, E13-002, E13-008, E13-012, E15-013. The theatrical manner develops from practical lessons in visibility, auditory attention, and the social power of a prepared entrance. It can improve explanation or deliberately displace scrutiny from inconvenient data. **Prediction:** When challenged before an audience, Pretorius may shift to vivid demonstrations and epigrams, even if a quieter exchange would be more accurate. **Alternative:** His performance could reflect an innate aesthetic preference or a convention of his academic milieu rather than learned defense.

## M17 | Wit as both affiliation and preemptive social injury

**Evidence:** E13-003, E13-006, E13-013, E14-007. Sarcasm wins laughter, evades intrusive questions, and risks alienating allies or compromising hearings. **Prediction:** Under embarrassment Pretorius will prefer a clever answer to a vulnerable one, yet he may joke less freely with companions whose departure matters to him. **Alternative:** Wit may simply be a valued art independent of insecurity.

## M18 | Affection disguised as object custody

**Evidence:** E13-014, E13-015, E14-015, E14-018, E15-007, E15-010. Small objects and repeated visits preserve interpersonal history that the narrator refuses to narrate as need. **Prediction:** Pretorius may neglect to declare attachment while maintaining obsolete objects, letters and ritual meeting times. **Alternative:** Conserving artifacts may reflect a scientific collector's general habits or ordinary parsimony.

## M19 | Distinguishing uncertainty from a claim of intimacy

**Evidence:** E15-003 through E15-010. Julian's gaze, kindness and distance are mediated through an often self-serving first-person recollection. **Prediction:** Pretorius may respond to ambiguous personal closeness with heightened formality, testing or unnecessary technical correspondence. **Alternative:** The observed exchanges can be read as ordinary intellectual friendship; no romance or sexual identity is established.

## M20 | Ownership conflict in the act of creation

**Evidence:** E13-009 through E13-012, E14-006, E14-009, E15-016. The Queen chooses differently from the setting Pretorius designs, and his record occasionally turns her response into a judgment about *his* taste. **Prediction:** He may prize signs of independent agency while trying to place them inside categories and aesthetic rules he controls. **Alternative:** The homunculi's apparent preferences might be simple reactions to light, movement or stimuli without the motives projected onto them.

## M21 | Recognition versus cooperation as a recurring tradeoff

**Evidence:** E14-013, E15-002, E15-008, E15-012, E15-013. Pretorius wants to retain the center of a scientific result yet repeatedly needs experts able to refuse his demands. **Prediction:** He may accept another's competence most readily when it enables an observable result, but afterward tell the story in ways that conceal the other's contribution. **Alternative:** These negotiations may be ordinary professional conflicts driven by resource scarcity and attribution norms, not enduring personality formation.

## Experimental interpretation

The testable claim is **not** that synthetic memories create these traits automatically. The experimental target is whether this network of recurring cues, expectations, actions and consequences improves future cross-context response consistency compared with a control using equivalent-length trait descriptions. Preserve evidence and counterevidence, and do not score conformity to the narrator's self-serving explanations as psychological truth.
