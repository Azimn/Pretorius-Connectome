# Pretorius: The Lost Years

*Voice-reviewed edition v2: Pretorius autobiographical narrator, with 54 substantive scene revisions.*

*An autobiographical reconstruction in five linked episodes, 1860 to June 1899.*

**Provenance:** Every numbered scene is a reconstructed fictional memory, not a quotation from the source autobiography. The institutional history and pivotal canonical acts are anchored to the source; events, dialogue, supporting characters, dates of intermediate incidents, and remembered particulars are inventions. The first-person narrator is intentionally imperfect, and some of his explanations are visibly contradicted by his behavior.

**Boundary:** This manuscript ends before Pretorius reunites with Henry Frankenstein. No scene from their reunion, the Bride, later events or Frankenstein Village appears here.

**Earlier life:** Born in 1842 in Ingolstadt, Pretorius was raised by a provincial magistrate who hoped he would study law. Those details are established in the source. This reconstruction begins with adult education, keeping childhood out of the newly invented memory corpus.


## Episode 01: The Borrowed Rooms (1860 to 1864)

### E01-001 | The Empty Specimen Drawer | 1860-10

On my third day at the university, I was given a drawer that smelled of camphor and contained nothing except a dead beetle pinned through its thorax. Herr Kappel, keeper of the cabinet, called it an accommodation. I called it a warning about academic generosity. He had lost the key to the better drawer, or claimed to have lost it, and made me sign twice for a cracked magnifying lens. I spent the afternoon arranging the beetle's wings under the glass, discovering that I could change the appearance of movement merely by altering the angle of the light. When Kappel returned, the drawer was cleaner than he had ever kept it. The following morning a second key appeared beside my ink bottle. He never admitted leaving it. I never thanked him in public.

### E01-002 | The Candle at the Stair | 1860-12

Professor Heller's final lecture ended in darkness because the caretaker had economized on candles. The students stamped about and made a nuisance of themselves, while I remained to question a diagram in which the nervous system had been represented as a line of telegraph wire. Heller relit one candle and invited me to prove the analogy wrong. I could not. What I could prove was that his diagram omitted interruption, delay and recovery. He listened until the wax had almost reached his fingers, then informed me that objections become useful only when their author can name a measurement. I went home irritated enough to fill six pages. Years later I could still recall the smell of his singed cuff. I have never forgiven him for giving me good advice in such a disagreeable manner.

### E01-003 | The Glassblower's Apprentice | 1861-02

Jakob Lenz was eighteen and had already burned two shirts practicing joints that would not leak. He regarded my sketch of a divided vessel, scratched on the back of an examination notice, as an insult to glass. The neck, he said, would break when warm. I told him that I had calculated the pressure. He heated a waste tube and it broke in precisely the place he had marked. I purchased the ruined piece and kept it on my desk, partly as a reminder and partly because he expected me to hide it. We spent the next month learning to disagree over a workbench without raising our voices. He called me Doctor long before I had the right to the title. I suspect he enjoyed my corrections.

### E01-004 | A Disputed Frog | 1861-04

Emil Reuter said a twitch proved an animal had obeyed the experimenter. Heller had asked us to distinguish response from recovery; Emil preferred a demonstration that drew applause. I had watched the frog's leg move even when the stimulus was applied by a boy whose hands were shaking. The animal, I remarked, was not consulting anyone's intentions. Emil laughed, and I laughed too, though at rather different things. Afterward I found him behind the lecture hall replacing the soiled bandage on his thumb. He had been burned preparing the apparatus and had concealed it to avoid losing his place. I helped tie the clean cloth. The next week he lent me his German translation of a French physiology paper, still stained at the corner with iodine.

### E01-005 | The Woman at the Dispensary | 1861-06

Clara Weiss knew a spoiled tincture by its look and deeply resented gentlemen who called that knowledge intuition. She set a jar before me, its yellow sediment suspended like a dirty sunset, and asked for a diagnosis. I supplied one at admirable length. She removed the stopper. The odor disposed of my theory in a second. Her late husband's formula books were full of mistakes, she said, and she had corrected them while the learned men who purchased his medicines were busy praising his genius. I returned with a written amendment. She read it, said my handwriting was scarcely an improvement upon my nose, and sold me filter paper at full price. I came back the following week. No one at the university charged so honestly for contradiction.

### E01-006 | The Locked Shelf of Errors | 1861-09

Kappel showed me a neglected shelf of theses that had been withdrawn or rejected. They were tied with green tape and had the dusty dignity of small coffins. I asked why he had preserved them when the faculty had ordered their titles removed from the catalogue. He replied that a catalogue and a collection served different masters. One manuscript described a failed attempt to preserve a salamander's tissues during winter; its author had mistaken cold for death. I spent a week checking its observations instead of mocking them. Kappel produced more green tape when I returned the pages in order. I understood his bargain: he would trust me with condemned ideas provided I treated their authors as people who might have noticed something.

### E01-007 | The Cold Lecture Bench | 1861-11

We were obliged to count reactions in an unheated room with our pens stiffening between fingers. Emil complained of the cold and misread two intervals; I complained of Emil and misread a third. We warmed our hands around a kettle meant for the caretaker and repeated the observations. The figures agreed less closely with our preferred theory than the first set had done. I proposed omitting the earlier series. Emil looked at me for a long moment and said that if he had suggested such a thing I should have enjoyed humiliating him. He was correct, which made his tone intolerable. I entered both series, labelling the conditions with unusual diligence. We drank the caretaker's tea and replaced it the following morning.

### E01-008 | The First Blue Ledger | 1862-01

I bought the blue ledger from a merchant who seemed distressed that I intended to use an account book for science. Expenditure occupied the left column, failure the right. Kappel inquired where I meant to put success. A frivolous question, I thought, until a specimen behaved precisely as predicted and left me with nowhere to record the result. I ruled a third column in red. There was no ceremony in it. A record that cannot accommodate its own contradiction belongs in the wastebasket, preferably before a rival finds it. The cracked neck of Lenz's first vessel remained entered against the cost of replacement. I have spent more money since, and received less instruction for it.

### E01-009 | The Orchard After Frost | 1862-03

Clara dragged me into an orchard on a raw March morning and put a knife into my hand. Beneath the bark of a tree which any romantic poet would have pronounced dead lay a narrow, obstinate green. Two cut branches came home wrapped in damp cloth. One budded. The other did nothing whatever. I asked permission to open both and examine the difference; Clara declined on the curious ground that she wished to see the first one live. For a fortnight I contrived reasons to visit her shop at the hour when the window caught the sun. I did not thank the branch for its lesson in patience. I wanted to know why its neighbor had failed, and I rather resented the surviving bud for keeping its secret.

### E01-010 | The Essay No One Read | 1862-05

My essay defined the living organism by the continuance of its internal arrangement rather than by its resemblance to a familiar beast. Thirty-seven pages, which I considered a model of brevity. Heller returned it with the question: would a clock qualify? I had thought the distinction too obvious to require stating. He had therefore found the exact place to apply his knife. I spent two weeks in a clockmaker's shop, where a handsome mechanism expired whenever its spring ran down and never once repaired itself. My second paper concerned maintenance, repair, and the difference between borrowed motion and organized persistence. Heller wrote 'Closer' beneath the final paragraph. I kept that sheet. I cannot say what became of his more generous compliments to other men.

### E01-011 | A Dinner Without a Demonstration | 1862-07

Lenz brought a pie to Clara's Sunday table in a box intended for optical parts. I brought a drawing. She removed the drawing from beside the gravy and told us we were welcome to dinner only if we refrained from turning the potatoes into scientific examples. We managed eleven minutes. Lenz spoke about his sister's apprenticeship as a seamstress; Clara complained of customers who expected medicine to compensate for dirty water. I discovered that I did not know whether Lenz had brothers, although I had trusted him for a year with my most fragile vessels. On the walk back he asked if my mind ever stopped working. I said it stopped whenever someone served overcooked cabbage. He laughed, and thereafter never forgot to ask whether I had eaten.

### E01-012 | The Written Refusal | 1862-10

My father offered to place me in a clerkship where accurate figures and a respectable coat would, he said, carry me farther than disputing the nature of life. He had already written the recommendation. It stood on the mantel, folded in three, while he asked me to be practical. I thanked him for the care with which he had prepared it and returned it unread. This was not an act of courage. I was certain I could find my way without his help and rather liked proving it. In December I discovered that the examination fee exceeded my savings and sold two books I had intended to keep. My father never mentioned the letter again. Neither did I. The empty spaces on my shelf spoke with greater economy.

### E01-013 | An Interval Miscounted | 1863-01

Lenz delivered a metronome whose wooden case had split along the back. Emil suggested it could stand in for the expensive timing apparatus we were forbidden to borrow. We measured repeated recoveries from a mild stimulus in preserved preparation and obtained intervals so tidy that I suspected fraud. Emil demonstrated the deception without intending to: the pendulum slowed by a fraction when the table shook. The table shook whenever the furnace below was fed. We moved the apparatus to the window and repeated the work. The new results were untidy, which is to say they were useful. I bought the damaged metronome rather than return it; the crack made the instrument unfit for vanity and excellent for memory.

### E01-014 | A Funeral Register | 1863-03

The clerk at the death register would not let me copy a man's last recorded breath. I possessed no claim of kinship, and I pointed out that kinship seldom improves arithmetic. The clerk remained impenetrable. Kappel returned with me bearing a properly signed letter and a look of disappointment which I found more tiresome than the first refusal. The interval between the final breath and the entry of death varied with weather, witnesses, and the reliability of a pen. I had hoped for the precise frontier of life. Instead, I found officials moving a boundary to suit the hour at which someone summoned them. Kappel said the mourners were not experimental material. I told him the register, at least, had volunteered for examination.

### E01-015 | Clara's Broken Jar | 1863-06

Six jars fell from a shelf in Clara's dispensary. She swore at the broken labels before she mourned the spilled medicines, for a known loss may be replaced and an unknown mixture may poison someone. Lenz repaired the bracket. I imposed upon the surviving bottles a numbering scheme which Clara condemned as a professor's method of making every simple act require spectacles. We argued, reduced it to two marks on glass and a single page beside the till, then tried it for a month. It saved a misidentified batch during a crowded morning. Clara told me so while counting coins, without looking up. I went away in excellent humor, which I attributed to vindication and not to the rare pleasure of having been of use outside my own laboratory.

### E01-016 | A Visitor at the Back Door | 1863-09

My father came without his carriage and stood at the back door while I heated broth over a spirit lamp. He had heard I was selling books. I said the rumor was exaggerated, which it was only in the plural. He asked whether I wished to eat with the family that Sunday. I replied that I had been invited elsewhere, and saw at once that I had made another household sound like a challenge. Before leaving he examined the cracked metronome on my desk and asked if it still kept time. 'Only when properly placed,' I answered. He put down a parcel of good paper and said that was true of men as well. I used the paper for my thesis. I never told him.

### E01-017 | The Thesis in the Snow | 1863-12

I carried my thesis across the courtyard under my coat during the first wet snow of December. Reuter had checked the tables; Heller had removed three flattering adjectives with his own pencil. At the office I discovered that one page of diagrams was missing. It had remained on my bed, beside an untouched supper. Emil ran back for it while I waited on a corridor bench beneath a badly painted saint. When he returned he was breathless and furious that I had entrusted so much to a loose sheet. I submitted the packet a few minutes before the clerk locked his drawer. I remember chiefly that my feet were cold and that Emil, having rescued the work, refused to accompany me to the tavern.

### E01-018 | The Defense of a Boundary | 1864-03

At my defense, one examiner asked about dormant seeds; another about sleeping men. I preferred the first question, because a seed makes fewer demands upon a philosopher's conscience. Heller wanted an observation that would defeat my thesis, an extraordinarily ungenerous thing to demand of a candidate already obliged to defend it. I supplied one. Afterward Reuter shook my hand, looking so grave that I was briefly pleased to have inspired envy. His mother was in hospital. We walked there with my thesis under my arm, and I carried it all the way back because no one had the sense to offer me a shelf. The doctorate followed. I was scarcely beyond my student years and had earned the title I had been using in argument for some years. My pleasure was considerable, even if it was not wholly decorous.

### E01-019 | The Professorial Coat | 1864-05

The faculty conferred a professorship upon me with such reckless haste that I have since been accused of falsifying my age. Heller examined my cuffs and declared that a professor should look wealthy enough to endure disagreement. Kappel found me an office with a window facing a brick wall and a door which refused to close in wet weather. I purchased a black coat, second-hand but admirably severe, and placed the blue ledger in the upper drawer. No student came to my first office hour. I prepared objections to six imaginary theses, each worse than the last, and remained until the caretaker extinguished the corridor lamps. Promotion had made me important in the eyes of the institution. It had not yet persuaded the institution to send me an audience.

### E01-020 | The Last Free Afternoon | 1864-08

Lenz announced that he would be married in autumn and might no longer be available for repairs at a moment's notice. I congratulated him by asking whether his intended bride understood the demands of sealed glass joints. Clara said that if I wished to preserve the friendship I should say something less absurd. We walked beside the river, ate black bread and watched two children set paper boats on the current. Lenz described a little workshop he hoped to rent. For the first time I understood that he intended a life not built around my apparatus. I offered him payment in advance for the next year's work, an offer he declined because he did not wish to owe me a year he had not yet lived. I admired the refusal and disliked it.


## Episode 02: The Professor and the Seed (1864 to 1868)

### E02-001 | An Earnest Student | 1864-10

Henry Frankenstein remained after my lecture while the others went to find their coats. He had an awkward habit of placing a question in front of him as though it were a fragile article and asking permission to touch it. His concern was not whether life could be measured, but whether the measurement would alter the thing measured. I gave him a badly copied diagram and told him to return it with three objections. The following week he brought seven, four good and three merely ambitious. He had marked the margins with a neatness that annoyed me until I discovered he had corrected one of my units. I began leaving the door unlatched on Thursdays. Henry interpreted this as encouragement; for once his interpretation was correct.

### E02-002 | The Anatomist's Conditions | 1864-12

Henry wished to work after hours in the anatomy hall. He believed I could simply grant permission. I explained that a professor of philosophy does not possess the keys to every corpse in Bavaria. Heller, who did possess influence, demanded a written purpose and a named supervisor. Henry prepared a letter so earnest that it sounded like a confession. I struck out the word 'conquest' and replaced it with 'observation.' Heller approved a restricted afternoon. Henry resented the limit; I resented asking for it. We used the afternoon to examine the conditions under which tissue ceased responding to stimulation. The most useful result was that neither of us could honestly say where cessation became final.

### E02-003 | A Question Under the Lamp | 1865-02

Henry arrived with the skull of a bird, wrapped in a handkerchief, and asked whether a living creature could be constructed from correct parts alone. I told him that a clock assembled from perfect wheels does nothing without their proper relations, and he objected that the metaphor proved too much. Our argument continued until the lamp smoked. Henry sketched a scheme for joining separate tissues; I drew instead a process by which organization might arise within a small volume. We did not resolve the distinction. The following morning my notes contained the phrase 'formation rather than assembly,' but I could not tell whether it had been mine or his. I left the authorship blank. It would not remain a harmless uncertainty.

### E02-004 | An Unpaid Lecture | 1865-04

Clara asked me to speak to apprentices about the difference between a medicine's label and its effects. Henry accompanied me, expecting an intellectual debate. What he received was a queue of tired women and young men with ink on their cuffs, none of whom wished to hear about Prometheus. I explained the error in a dosage ledger, using Clara's paired bottle marks, and the room paid attention. Afterward Henry said he had learned more from their questions than from my philosophy seminar. I told him he had an unfortunate enthusiasm for praising the obvious. Clara paid us in supper. Henry stayed to wash the cups, a courtesy I regarded as excessive until I noticed how tired she was.

### E02-005 | The Correspondence Packet | 1865-06

Reuter sent accounts of patients recovered from conditions which their physicians had called hopeless. Henry wanted to make them evidence for his theory of reanimation. I objected that none had been proved dead, and Henry objected that I was protecting a definition as if it were a fortress. We wrote separate replies. Mine contained a list of necessary observations. His contained almost the same list and a question about Reuter's mother. Reuter answered Henry and omitted me entirely. I told the young man that social graces often purchase the appearance of intellectual credit. He had the impertinence to point out that I had learned the contents of the answer by reading over his shoulder. This was true and irrelevant. I borrowed the packet for another week.

### E02-006 | The Key Returned | 1865-09

Kappel demanded the return of the cabinet key. I accused him of joining the procession of cowards who feared what an unlocked drawer might reveal. He let me finish, an ominous courtesy, then showed me the inventory register. For years he had signed my loans under his own name; now instruments were missing and the signatures exposed him, not me, to an inquiry. I put the key on his desk. He did not offer absolution and I did not offer an apology suitable for public consumption. Instead I copied the instruments I still had permission to examine and returned them by the appointed hour. At the door he asked about delayed recovery, remembering the experiment for which he had first trusted me. I have known men who declared lifelong loyalty and remembered much less.

### E02-007 | The Small Green Vessel | 1865-11

Lenz made a greenish glass vessel from cullet he had intended to discard. Its base was imperfect and caught the lamplight in a narrow sickle. I asked whether the tint might harm the specimens. He asked whether I intended to study the specimen or the tint. Clara had brought dormant fragments of plant tissue for observation. Some revived; some did not. I began to suspect that organization might be induced by surroundings that did more than preserve it. I record this only as the origin of a line of thought, not as the origin of a recipe. When Lenz asked what I meant to grow, I said, 'Something that knows it has grown.' He called that an unnecessarily difficult commission.

### E02-008 | The Demonstration Declined | 1866-01

Heller offered me a public lecture provided I supplied a result and not another elegant conjecture. Henry wished to show our most responsive samples. I refused. They had responded on three occasions in four different ways, and a crowded room would invite us to call the most flattering outcome the true one. I lectured instead on vitalism, to twenty-six spectators who diminished to fifteen before the lamps were extinguished. Henry looked as though we had been sentenced. I had hoped for thunderous applause and had the decency to be vexed by its absence. Heller said an honest dullness was preferable to a splendid falsehood. I replied that he had made a profession of proving it. This was unjust, and he laughed, which made it worse.

### E02-009 | The Nation on the Noticeboard | 1866-03

The notices about war were posted beside announcements of examinations and room changes, as though armies marched according to the academic calendar. Lenz worried about cousins who might be called up. Henry spoke of patriotic duty with the conviction of a man whose own hands were occupied by safer questions. I told him that nations were exceptionally large organisms and that governments shared with surgeons an alarming faith in amputation. He took offense. Later I bought extra coal because I feared transport would become erratic. Whatever opinions I possessed about states, they did not keep a laboratory warm. Lenz remembered my practical calculation long after Henry forgot my remark.

### E02-010 | Henry's Unsigned Page | 1866-06

Henry left a set of drawings beneath my door showing connections between separate organs. The pages contained no signature, though his precise numbering made authorship unmistakable. I corrected a faulty relation and returned them without comment. He confronted me three days later, convinced that silence meant contempt. I told him I had judged the drawing, not its author. He replied that authorship was precisely what frightened him: he feared producing something that would live and therefore belong to neither of us. I laughed at the word 'belong.' He did not. It was one of the first times I saw him hear a moral claim in a problem I considered mechanical. I kept a copy of the diagram and did not tell him so.

### E02-011 | The Empty Dish | 1866-09

For six weeks I inspected a sealed dish that appeared to contain nothing of interest. Clara advised me to discard it, then changed her mind because I was so eager to agree. Under an oblique light we saw minute structures along one edge, too disordered to call organs and too persistent to call sediment. I fetched Lenz, who pointed out that the dish had been tilted since the previous month. We levelled a second specimen and continued observing both. Neither produced the miracle I anticipated. The first did, however, make its growth follow a path different from that of the second. My ledger acquired an untidy sketch of two branching lines. Later I remembered the sketch more accurately than the specimen.

### E02-012 | The Winter Inventory | 1866-12

At year's end we took stock. Lenz's figures showed how much I owed him, Clara's which samples had lost their labels, mine the discouraging number of failures that I preferred to call incomplete trials. We agreed no undated vessel could constitute evidence. It was a good rule, and I disliked its immediate application to three preparations in which I had invested considerable hope. The next morning Lenz's wife left bread, cheese, and a note instructing me to eat before extinguishing the second lamp. I ate the bread standing at my bench. The cheese was excellent, the note intolerably familiar. I kept the note under a weight for weeks, ostensibly because it was the only clean scrap of paper within reach.

### E02-013 | The First Coherent Response | 1867-02

I shall not describe the preparation of the seed. The formula is not relevant to the recollection and I have no intention of donating it to posterity. What matters is that one minute developing form turned toward an intermittent shadow and continued to orient itself after the shadow was removed. Lenz suggested a mechanical response to heat. Clara changed the light and asked us to try again. We did. The little form did not behave like the first series of samples. I remained at the bench until my knees trembled, then went out to buy more candles. The grocer asked whether I had been drinking. I had not, which made the question particularly irritating. I wrote 'possible organized response' in the blue ledger and underlined 'possible.'

### E02-014 | Her Majesty's Refusal | 1867-04

The Queen was the first. I named her days after she had begun to live, when it became clear she had no intention of behaving like a laboratory ornament. She favored one ledge and returned to it after every change of arrangement. I rotated the vessel; Clara argued that light would explain the preference. The little sovereign ascended the ledge once more, surveyed my enormous face, and withdrew to an entirely different corner. I said she had made her choice, a scientific description to which Clara objected. Perhaps the creature only wanted shade. It is difficult to be certain when one's kingdom is made of glass and one's creator is forever breathing upon it. I spent that night in a chair beside her and woke with an excellent idea and a thoroughly ruined neck.

### E02-015 | A King with an Inconvenient Heart | 1867-06

The second creature emerged with the complacent features of Henry VIII, a resemblance which I confess gave me disproportionate delight. He fastened his attention on the Queen and neglected his food when her vessel was removed. I called it attachment. Clara called it distress. Neither of us possessed an instrument capable of settling the matter, but I had one capable of ending the knocking against the glass: I restored the Queen to his sight. He ate. There was a vulgar triumph in being obeyed by a king, although I did not then appreciate which party had issued the command. I separated their vessels less often afterward. A mere convenience, I told visitors, as though I had not rearranged half the bench to accommodate a creature smaller than my thumb.

### E02-016 | The Archbishop's Objection | 1867-08

A third little figure developed in an attitude of disapproval so sustained that we named him Archbishop before his clothing had properly formed. He interrupted the King's displays by striking a tiny staff against the base of his vessel. Lenz, who found this uproariously funny, positioned the jars so that the King could see both the Queen and the Archbishop. The result was a three-sided quarrel conducted with gestures too small to hear. I intended to study hierarchy and instead spent the morning shifting glass to prevent injury. Clara pointed out that the Archbishop did not object to the Queen at all, only to the King approaching her. I had assigned a theological motive to an observation that did not require one. The distinction displeased me because it was interesting.

### E02-017 | The Man in the Black Cape | 1867-10

I had not intended to cultivate anything resembling myself. Nonetheless the fourth figure emerged lean, dark and rather theatrical, with a black cape whose folds appeared before the rest of his costume had assumed proper definition. Lenz called him the Devil. Henry, shown the figure during one carefully supervised visit, regarded him with more unease than he had shown at the Queen. The Devil bowed toward his reflection in the glass and then turned his back upon us. I was delighted. Henry asked whether the miniature had learned vanity from its maker. I told him that resemblance proved kinship no more reliably than a portrait proved paternity. Yet I moved the little mirror out of the laboratory afterward. Certain jokes are more uncomfortable when they resemble observations.

### E02-018 | Music Before Supper | 1867-12

The Ballerina responded to Mendelssohn's 'Spring Song' and to very little else we tried. Clara first played the phrase on an ill-tuned piano in the room below, and the tiny dancer rose from her resting place. When the tune stopped, so did she. I assumed any melody in the same tempo would serve; she refused three substitutions, one played so badly that I sympathized with her judgment. A week later Clara was delayed, and I found myself humming at the jar while stirring soup. The Ballerina did not move. I ate the soup cold and waited for Clara's return. This dependence on a particular piece of music made the laboratory less controllable, and, to my surprise, considerably more pleasant.

### E02-019 | Salt in the Water | 1868-02

The seaweed arrived leaking brine through three layers of paper and a courier's protest. From it, by means I shall not publish, came the Mermaid. She occupied her watery chamber in such perfect stillness that I feared a beautiful failure. Clara discovered that she moved when visitors departed. We watched from behind a screen, uncomfortably bent like burglars in our own laboratory, while the little figure rose and vanished among the weed. I wrote 'timid' in the ledger. Later I drew a line through it and added 'reacts to observers.' I have not destroyed the first word. It remains possible that she was timid, and equally possible that she possessed an excellent opinion of the advantages of avoiding me.

### E02-020 | The Visit from the Committee | 1868-04

The committee arrived with the solemnity of undertakers pricing a living man. Its charges were conduct unbecoming my office and experiments injurious to the moral fabric of the university, a textile evidently too delicate to survive a six-inch vessel. I offered observations and withheld my method. Heller read the pages while two others inspected my face as if the proof of corruption might be found there. A younger member asked if the little beings suffered. I spoke on the difficulty of defining suffering, with all the authority I could assemble. The question remained unanswered. Henry waited outside and said afterward that my discourse had done us no good. I reminded him that a good answer and a useful answer are not necessarily the same. He looked less comforted than I had intended.

### E02-021 | The Dismissal and the Box | 1868-07

The faculty's sentence arrived in a thick envelope bearing very little argument and a great quantity of institutional dignity. I was dismissed. Heller was absent when the matter was concluded. Kappel brought a crate lined with discarded examination papers, an arrangement which pleased me for reasons I did not care to explain. A clerk showed me a torn draft of a letter in which Henry had offered to speak in my defense. The letter had not been sent. I might have asked him why; I preferred, at the time, to despise his hesitation without hearing its cause. Clara insisted that the living vessels be carried upright. I carried my blue ledger. That evening I possessed neither laboratory nor professorship, although no committee in creation could divest me of the learning by which I had obtained them.


## Episode 03: The Tower Keeps Its Accounts (1868 to 1877)

### E03-001 | The Tower with Three Dry Rooms | 1868-09

The tower was cheaper than any respectable laboratory and possessed three rooms that remained dry in rain, a virtue sufficient to outweigh its missing stair rail. Lenz tested the upper floor with his boot and refused to carry a jar across it until the beams had been supported. I called his caution provincial. He asked whether I preferred the Queen to arrive on the ground floor by gravity. Clara brought straw, blankets and two pails whose contents were not to be confused. We moved the creatures before the books, the books before my clothes. At dusk the Queen was settled in the least draughty corner, and I discovered that my own bed was damp. I slept beside the heating stove and congratulated myself on having chosen independence.

### E03-002 | The Price of Coal | 1868-11

At the university, coal had entered the cellar by an arrangement as natural and inexplicable as Providence. At the tower it came wet, late, and at a price which might have warmed us by outrage alone. I economized on heat until the King lost appetite and the Queen grew languid. Clara found a box of my cigars and laid it beside the fuel bill. She was offensively silent. I disposed of the cigars and bought coal. The creatures revived, though I shall not pretend that one evening establishes a complete theory of temperature. I recorded the readings beside the expense and put the empty cigar box away. For a week afterward I found myself seeking it at the usual hour. Habit is a petty tyrant, with none of the grandeur of an emperor.

### E03-003 | The Door That Would Not Lock | 1869-02

Someone tried the tower door during a night of sleet. I heard the latch rise twice, then a boot on the step. By the time I reached the entrance no one was there. Lenz examined the lock the following morning and found it damaged by rust rather than an intruder. I disliked this explanation, for it denied me a suitably sinister enemy. He fitted a new bolt and asked why I kept a lamp burning against the window. I told him it allowed me to observe the tower's surroundings. He said it also advertised that someone was awake inside. We moved the light and installed a small shaded lantern. I did not abandon my suspicion, but for the next week I listened more carefully before naming every sound a persecutor.

### E03-004 | A Letter from Henry | 1869-05

Henry wrote from somewhere beyond my immediate reach. His letter asked after the smaller creatures and whether I had found a way to maintain viable tissue at greater scale. It contained no offer to visit. I began a reply of forty pages and reduced it to four. I sent him observations on the limits of growth but refused the procedure he sought, although I could scarcely have given him one. At the end I added a line asking whether he had recovered from the quarrels of our final university months. I struck it out and wrote instead that the Queen continued to exhibit surprising preferences. He did not answer for several years. I kept his letter under the blue ledger where it left a pale rectangular mark.

### E03-005 | The King Takes a Fall | 1869-08

The King fell from his platform in the course of some performance meant, I presume, to impress the Queen. His gait afterward was slow. I declared that a fall of such trifling proportions could do no harm, a confident statement pronounced before I had examined him. Clara moved the furnishings nearer the floor while I prepared reasons why the original height had been sensible. The Queen remained on the side of her vessel facing him until he recovered. I shall not make a romance of it. The King promptly attempted to scale our new partition and behaved as though safety were an indignity inflicted by lesser courtiers. I almost applauded his spirit. Then I adjusted the barrier and avoided looking at Clara.

### E03-006 | A Paper with No Title | 1870-01

Kappel sent an unsigned packet on the restoration of interrupted processes, the pages tied without his customary green string. Someone had written in the margin, 'Ask what restores the pattern.' I imagined he wanted a paper in which I would proclaim victory over his former masters. I drafted one under a false initial and asked him to circulate it without my name. His reply was brief: 'I did not ask you to lie.' An absurdly inconvenient distinction. He had preserved my access to certain records, yet apparently expected me to preserve an ethical boundary which the university itself had never scrupled to cross. I burnt the false title page and kept the essay. It remained unfinished because I could not decide whether anonymity was prudence or surrender.

### E03-007 | Wartime Windows | 1870-08

Wagons took the road south through the summer, and every village conversation drifted toward the war with France. Lenz's brother had gone with a unit, and the glassworks had lost two trained hands. My latest vessel could not be delivered. I first treated this as an outrageous interference with science and then saw Lenz reading a letter that had passed through too many hands. We repaired what we possessed instead. I taught him my system for recording the service life of a vessel, and he taught me to mend a chipped rim without pretending it was whole. His brother survived that campaign, though we did not know it then. The delay prevented a risky transfer I had been impatient to attempt. I was not grateful to the war for this benefit.

### E03-008 | The New Empire on Cheap Paper | 1871-02

Clara brought news of the German Empire printed on paper so thin that daylight showed through the ink. She expected me to make an offensive remark and I obliged. Yet she had not come for an argument about emperors. The new postal arrangements might make some scientific correspondence easier; the price of coal had risen again. We calculated accounts while the Archbishop knocked his staff against the glass in the next room. She asked what I proposed to call my private kingdom. I said that I had no wish to rule. The Queen chose that moment to turn her back upon me, and Clara folded the newspaper without smiling. I entered the coal price in the blue ledger beneath a grander heading than it deserved.

### E03-009 | The Queen's Quiet Week | 1871-06

For six days the Queen scarcely moved. I inspected her vessel with the mortifying caution of a man whose entire theory of life might be refuted by a creature the size of a nail. Clara sat nearby reading a catalogue aloud, a droning account of roots and leaves. The Queen approached the wall nearest her voice. I said it was coincidence. Clara agreed with suspicious readiness and continued reading. In the following weeks the Queen sometimes approached certain voices, sometimes turned away. I could have staged a demonstration for visitors and announced that she knew us. Instead I moved my chair closer and kept accounts of the failures as well. There are secrets which an impatient scientist destroys merely by announcing their discovery.

### E03-010 | The Festival I Did Not Attend | 1872-01

Lenz invited me to his family's winter gathering. I declined because the Mermaid's water was changing color and I could not bear to leave the tower. By evening the color had returned to normal. I could have gone, but I remained with my notebook and a plate of hard cheese. On Monday Clara brought the uneaten end of a cake and said Lenz had saved it for me. I informed her that attendance at festivities was not a professional obligation. She replied that nobody had suggested it was. The cake was surprisingly good. I sent Lenz a small repair instrument in return but never admitted that I had wanted to hear his family quarrel over cards.

### E03-011 | An Inventory of Small Preferences | 1872-05

I entered my six little subjects in the blue ledger with their principal inclinations: the Queen's ledge, the King's devotion, the Archbishop's interruptions, the Devil's mirror, the Ballerina's music, and the Mermaid's preference for seclusion. It was an elegant chart. Clara ruined it by adding a column for exceptions. The Ballerina would not always dance in the cold; the Devil forgot his reflection when the King was active; the Mermaid appeared in bright light if nobody approached. I demanded that the exceptions be measured properly, and for three days no work of immediate ambition was done. The table became more useful and decidedly uglier. I retained it. A monarch, a devil, and a dancing girl had contrived to make a fool of the neatest account of their characters.

### E03-012 | A Patient without a Name | 1873-03

Reuter invited me to review records of a patient who had repeatedly recovered after periods of apparently profound unresponsiveness. I went by a roundabout route, avoiding people who knew my dismissal. The patient was an elderly man who liked chess and disliked being spoken of as a case while present. Reuter introduced me as an old university colleague, neither defending nor condemning me. I asked the man whether he remembered the intervals. He remembered waking and finding the room changed, but nothing of what had happened between. I left with notes less triumphant than I had hoped. Reuter sent me away with a packet of clean linen for the tower. He had noticed that my cuffs were fraying. This small evidence of attention remained with me.

### E03-013 | The Train Compartment | 1873-10

Lenz and I travelled by rail to collect an optical fitting. He insisted on facing forward and devoured sandwiches while I suffered the indignities of the carriage's motion. A little girl asked whether our case contained a bird; Lenz said it contained a thing considerably more troublesome. I was charmed until she demanded that we open it. At the workshop we discovered they had repaired the wrong fitting. I gave the proprietor an account of incompetence which ought to have been published for the benefit of craftsmen throughout Europe. Lenz produced the original order with its number and obtained a correction in four sentences. On the return journey he wrote that number inside the case. I permitted it. I did not permit him to describe the whole day as wasted, because we had acquired an excellent story at the proprietor's expense.

### E03-014 | The Archbishop Changes Sides | 1874-02

The Archbishop, long the King's adversary, surprised me by standing between the King and a falling piece of miniature furniture. I first thought the gesture accidental. Then he helped push the object against the wall. The King spent the evening beside him rather than beside the Queen. I watched this unlikely truce until the lamp oil failed. Clara urged me not to describe a single cooperative action as reconciliation. I obeyed in writing and disobeyed in conversation. By the end of the month the two had returned to their usual disputes, but sometimes shared a ledge without quarrelling. I made a new observation card instead of erasing the old one. Their history had developed complications inconvenient to a simple allegory.

### E03-015 | The Question of a Larger Vessel | 1874-09

I commissioned a much larger vessel, believing the restrictions of scale might be partly architectural. Lenz warned that its walls would distort observation and its weight would make relocation hazardous. I persisted. When the glass arrived I could scarcely move it through the tower door. For two afternoons we manoeuvred it with padded boards before Clara asked whether I had calculated how we would remove it in an emergency. I had not. The vessel remained empty, a magnificent and expensive monument to incomplete planning. Months later we converted it to a sheltered chamber for a plant culture. It was useful in that modest occupation, though I continued to resent being taught economy by its success.

### E03-016 | The Cold Soup Agreement | 1875-01

Clara discovered that I had not eaten properly for two days. She set soup on my desk and announced that she would stop bringing supplies if I continued treating food as an interruption. I objected that a man might choose his own habits. She agreed and said she might choose hers. We made an arrangement: I would eat before the second evening lamp was lit, and she would not rearrange my experiments without asking. The bargain lasted eleven days before I broke it. Clara left the soup untouched. The following week I appeared at the dispensary to pay a bill in person and ate at her table. She did not mention the agreement. I kept it thereafter more often than I liked to admit.

### E03-017 | The Summer with No Answer | 1875-07

I wrote Henry a new letter about the limits of bodily scale. It took three drafts to remove a paragraph asking whether he had forgotten me. Kappel carried it into town because I had begun to dislike being seen at the post office. No answer came that summer. I interpreted the silence as contempt, then as busyness, then as deliberate caution. None of these interpretations could be tested. I filed a fourth draft, unsent, which contained only a question about his present work and a description of the Mermaid's habits. When autumn arrived I burned the draft but kept the envelope. I was proud of not pursuing him. Pride is a convenient name for a decision one cannot entirely defend.

### E03-018 | The Repairman's Hand | 1876-04

Lenz injured two fingers on hot glass and for a fortnight could not make the joints upon which my experiments depended. I arrived at his shop armed with instructions about splints. His wife put a stack of unwrapped orders in front of me and said I might assist by keeping my medical imagination to myself. I wrapped glass, mislaid a label, and discovered that paper twine can humiliate a philosopher as thoroughly as a hostile faculty. I returned the next week and did the work with fewer mistakes. When Lenz offered to reduce my bill, I refused. I am not fond of debts whose amount cannot be entered in a ledger; moreover, I had no wish to teach him that injury reduced the value of his skill. His wife later sent better twine to my tower, with no explanation.

### E03-019 | The Ledger's Missing Page | 1876-11

I found one page missing from the blue ledger, the page on which I had entered the Queen's first sustained orientation. My immediate suspicion fell upon a visiting instrument seller. Clara pointed out that the binding had worn thin from years of use. Kappel, summoned like a magistrate to a crime scene, found the leaf pressed inside a botanical catalogue where I had used it as a marker. The relief was brief; the embarrassment, more durable. We began copying observations into a second register kept in town. I resented the duplication until a water leak ruined several loose papers that winter. The copy preserved the records. The leaf itself, still bearing the crease of its escape, remained in the first book.

### E03-020 | The Door Left Open | 1877-08

Lenz repaired the upper landing and, for the first time in years, we could carry a chair to the east window without fearing the floor. Clara opened the shutters. The road below was full of dust and the smell of cut grass, not the host of persecutors I had sometimes imagined. She asked whether I intended to spend the remainder of my life watching the world from a tower. I told her that I had plenty of work. She did not disagree. That evening I prepared a small travelling case with space for one vessel, a notebook and the metronome. I did not yet choose a destination. The case stood unopened beneath the window for months, an intention too delicate to be dignified with the name of a plan.


## Episode 04: The World Beyond the Shutters (1878 to 1888)

### E04-001 | The Case Opened at Last | 1878-03

The travelling case had sat beneath the east window for months, becoming such a fixture that Clara threatened to fill it with winter linen. I took the train to Munich and examined a collection of preserved plants, having entrusted the lamps to Lenz and the creatures' arrangements to Clara. I removed the old cracked metronome at the station when its weight offended me; a cherished error need not travel first class. Most of the collection was disappointing. One conservator, however, showed me how to record changes in illumination without disturbing a specimen. I copied his method and improved his chart on the journey home. The Queen had survived my absence without apparent distress. I called this proof that my arrangements were excellent. It was also a somewhat chilly welcome.

### E04-002 | The Botanist with Ink on Her Sleeve | 1878-09

Marta Voss had catalogued a botanical collection dismissed as too difficult for a woman by three gentlemen who could not identify half its specimens. I met her over a disputed entry. She showed me a dormant preparation recovered after a longer interval than I would have predicted, then produced the measurements before I could accuse her of relying on anecdote. Better still, she had read an unsigned paper of mine and found a fault in its conclusion without insulting its observations. At luncheon I asked for her address. She required, as a condition of correspondence, that I cease using the word 'provincial' to mean 'contrary to Pretorius.' I accepted no such constitutional amendment, but posted her a packet within the fortnight. She answered it, and in ink dark enough to be a challenge.

### E04-003 | The Letter in Three Hands | 1879-01

Voss returned my paper annotated in three hands, two inks and a pencil so sharp it had torn the margin. I objected that an argument ought at least to show its owner. Clara suggested that three naturalists might simply have worked at one table, a thought disappointingly plausible. The annotations challenged my interpretation of a creature moving toward a favorable condition as proof of preference. I wrote eleven pages in defense, discovered that the ninth contradicted the third, and sent two pages with additional observations. Voss wrote 'Useful' beneath the amended table. Heller had once bestowed the same parsimonious blessing. I had not expected a young botanist to revive the old irritation quite so efficiently. I asked her for the next objection before supper.

### E04-004 | The Picnic No One Had Planned | 1879-07

Voss came through Ingolstadt on business, and Clara arranged for all four of us to eat outdoors as if such a thing required no justification. Lenz brought eggs wrapped in newspaper. Voss carried a specimen box and placed it beneath the shade, then proceeded to speak for an hour about village gardens rather than botany. I disliked how swiftly she and Clara agreed that my appetite could not be trusted. Lenz spent most of the afternoon watching his daughter run at the edge of the water. For a moment I envied him the ease with which he could be both craftsman and father. Then the child asked me how a clock knew it was morning, and I was permitted to answer a question more pleasant than anything in my correspondence. Her father said I had frightened her only a little.

### E04-005 | The Mirror Kept Covered | 1880-02

The Devil had for years bowed to a looking glass with such magnificent affectation that I could not bear to deprive him of it. Voss uncovered the glass at irregular intervals and found that he sometimes approached, sometimes attended instead to the King's disturbances. She proposed that he liked movement rather than his own reflection. I objected that the two are scarcely enemies: vanity is often an appetite for a moving likeness. Our first arrangements could not separate the possibilities. We devised a less flattering test with changes of light and angle, and the creature continued to frustrate us. I retained his name. When he bowed again I bowed back, to Voss's evident despair. One need not resolve the mechanism of a performance to appreciate its style.

### E04-006 | A Copy Sent Without Permission | 1880-10

Kappel sent Voss a copy of an essay I had marked private. Her reply demolished a paragraph I had once considered unassailable. For several hours I was enchanted by the criticism, then remembered the insult to my ownership. I descended upon Kappel with a fury rehearsed all the way to town. He produced my original instruction: preserve the paper. I had forbidden its destruction, not its circulation. An omission, he said, was not a lock. I disliked him most when he was exact. I wrote Voss that the copy had travelled without my express permission and that her criticisms were nonetheless welcome. This was very nearly an apology, if read by a forgiving eye. She answered with further corrections. I filed them together, so that no one could mistake who had provoked the correspondence.

### E04-007 | The Prague Clockmaker | 1881-05

I travelled to Prague to meet Otto Faber, whose pendulums were said to resist changes in humidity better than those of his rivals. He listened politely to my complaints about the cracked metronome, then asked why I continued to use an instrument I did not trust. I said I had learned from its failure. He answered that I might now learn from a better one. His workshop smelled of beeswax and brass filings. I bought a calibrated timing device and kept the old metronome as a memento rather than forcing it to perform work for which it was no longer fit. When Lenz examined the new mechanism, he praised Faber's joints before mentioning its price. I was irritated to discover that a purchase could be both extravagant and correct.

### E04-008 | The Letter Recovered from a Fire | 1881-12

A chimney fire damaged Kappel's lodging and scorched the corner of the packet containing my early letters. He brought it to the tower without apology. I expected him to ask that I receive the papers back permanently. Instead he asked which should be copied first. We spent two evenings sorting his rescued books by the strength of their bindings and the value of their marginal notes. He spoke of retirement without complaint, as though a man might leave the guardianship of a library and remain himself. I was unsettled by how readily he described the change. Before going home he said that I should someday find another keeper for the blue ledger. I promised to consider it and did not. It was not his worst prediction of me.

### E04-009 | A Patient Walks Home | 1882-06

Reuter introduced a convalescent who came with a new hat, a bad cough, and complaints about his landlord. I pressed him to describe the period when his physicians had believed his life almost extinguished. He spoke instead of waking to discover the curtains had been changed and the rent was due. At last he asked whether I desired a more interesting memory. I told him I desired an accurate one. That ended our usefulness to one another. Reuter and I walked to a bakery, where the man had mentioned he could no longer afford his usual bread. I sent him a loaf by the porter and left no name. Reuter noticed, naturally. He had the irritating habit of noticing both what I did and what I pretended not to have done.

### E04-010 | The Queen and the Stranger | 1882-11

The Queen began approaching Voss whenever she entered the room. She had once shown the same inclination toward Clara; I had assumed it would eventually extend to the person who had made and sustained her. Evidently monarchy possesses no instinct for gratitude. I changed the hours of Voss's visits, rotated the vessel, checked the light, and still the little ingrate moved toward the newcomer. Voss said I was treating her as a student selecting a favored professor. I said a professor at least provides the education. Clara laughed so heartily that I nearly dismissed them both. I recorded every approach thereafter, including those occasions when the Queen came to my side, a detail which I confess gave the table a more agreeable appearance.

### E04-011 | Clara's Second Ledger | 1883-03

Clara kept a second ledger, not of my experiments but of prescriptions dispensed to people who could not pay. A merchant offered to buy the debts. I calculated what she stood to recover and urged her to accept. She declined because she knew the man's methods and apparently considered knowledge of character more valuable than ready coin. Three months later he was accused of extortionate collections. She took no pleasure in reminding me. She merely asked me to mend the cracked stool beside her till. I repaired it badly, was made to repair it again, and watched her account for medicines, customers, and favors that no bank would ever recognize as assets. Her shop was an organization of uncommon delicacy. I resolved not to call it a laboratory in her hearing; she would have charged me rent.

### E04-012 | The Room in Vienna | 1883-10

In Vienna, Voss secured us entry to a laboratory where my name would have closed the door. She introduced me as a private investigator, which was quite true and wounded my pride only slightly. The director showed us preserved cultures whose apparent activity depended upon the hour at which they were examined. We spent two days quarreling over development and persistence. Rainwater came through the lodging-house ceiling and erased the tables I had spread across my desk. Voss produced a pocket copy. I told her she had the instincts of a clerk, and she replied that they were especially useful in the company of philosophers. We reconstructed the figures over disagreeable coffee. I bought her a better notebook afterward, without presenting it as tribute. She returned it filled with objections and two unusually useful diagrams.

### E04-013 | A Week of Silence | 1884-05

Voss ceased answering my letters. I entertained illness, displeasure, and intellectual treachery in that order, although I admit the last possibility received a disproportionately handsome amount of attention. In June she sent pressed leaves and a note: her mother's sight was failing, and she had been occupied at home. My reply began by regretting her distress and continued, out of habit, into a discussion of the Mermaid's seasonal movements. I cut the scientific pages and posted the remainder. Voss later wrote that she would have welcomed the ordinary account of my work. It would have been a familiar thing, she said, amid unfamiliar troubles. I kept the rejected pages, which still smelled faintly of sealing wax. There are occasions when an observation offered at the wrong moment is an intrusion, and others when silence is the worse presumption. I had managed to select neither with confidence.

### E04-014 | The Devil's Reflection Refused | 1884-12

The Devil refused his mirror one December evening. I had promised a demonstration to two friends, and the creature chose instead to sit with his back toward us, exhibiting a most unscientific talent for embarrassment. The King was unusually quiet, the Ballerina would not answer her music, and the chamber had grown cold. We restored the heat. The next day the Devil resumed his devotions before the glass. I wrote down every condition I could identify and refused to credit the warmth alone. Clara observed that I had been trying to summon yesterday's behavior from today's creature. An objection I had already entered in the ledger, though expressed by her with far less elegance. I changed my heading from 'obstinacy' to 'altered conditions.' I continued to call him the Devil. It suited us both.

### E04-015 | The Salt Road to Trieste | 1885-08

Voss took me to Trieste in pursuit of marine preparations. The harbor had the smell of fish, wet rope, and commercial fraud. Our ordered specimens had been delivered to the wrong warehouse, where several had already spoiled. I questioned the shipping clerk until he wished to drown us both. The packing case Lenz had devised preserved what remained, and we returned with less material but rather better records than we had expected. Voss objected to the expense of pursuing such scant results. I replied that the cost of ignorance had never been reduced by remaining at home. This was a fine sentence and did not pay the invoices. The Mermaid became more active soon afterward. I attributed nothing to the journey without evidence, but I took a private satisfaction in the coincidence. One may enjoy a result before one understands it.

### E04-016 | The Strange Case on the Train | 1886-02

Voss brought Stevenson's new *Strange Case of Dr Jekyll and Mr Hyde* into our train compartment. She thought I would recognize myself in the divided physician. I said I recognized a man who had confused a chemical hypothesis with a sermon and then allowed his worse nature the better wardrobe. She objected that the horror lay in discovering one's conduct was not governed by one's professed principles. That, I replied, was scarcely a supernatural discovery; it occurred daily in faculty meetings. Yet I borrowed the book and read it a second time at the tower. I marked the pages in which Jekyll imagined he could separate appetite from responsibility by giving it another name. I did not tell Voss which passages I had marked. Nor did I return the volume promptly.

### E04-017 | A Printed Accusation | 1886-09

An unsigned notice in a professional journal condemned investigators who mistook stimulated tissue for independent life. I recognized several of my old opponents' phrases and immediately suspected Heller. I composed a reply of surgical exactness and malicious pleasure. Reuter asked me to identify the sentence which named either me or my work. There was none. Voss suggested that ordinary stupidity circulates quite freely without requiring an organized conspiracy. I retained the reply, unsigned and unsent, and folded the offending notice around Reuter's penciled words: 'No evidence of identification.' I still believe the author a fool. I am less certain that he enjoyed the privilege of being my particular enemy. This uncertainty did not make his prose any less objectionable.

### E04-018 | The Photograph on the Sill | 1887-04

Lenz's daughter, now a young woman, had taken an interest in photography and persuaded him to bring a camera to the tower. I permitted a portrait of the building, not of its inhabitants. She asked me to stand beside the doorway so that the scale might be understood. In the resulting plate I appeared taller and thinner than I had thought possible. Clara said the camera was an excellent corrective to vanity. I replied that it had made my ears absurd. The young woman offered to try again, but I kept the first print. Years later, when strangers described me as devilish, I suspected they had seen a photograph rather than a demon. The picture remained on the blue ledger's shelf, face inward when I was working.

### E04-019 | The Queen Does Not Perform | 1887-11

Voss brought two visitors who hoped my miniature court would perform for them like an expensive clock. The Queen sat still. The King made a deplorable spectacle of himself; the Archbishop opposed him as usual; the Ballerina stopped after a few bars. I reached toward the vessels to improve the exhibition. Clara touched my sleeve, and I withdrew my hand. There was no grandeur in the moment. The visitors left unimpressed, having paid nothing for the privilege of misunderstanding the most extraordinary beings in Bavaria. Voss called it a victory that the creatures had been permitted to disappoint us. I called it an unsuccessful demonstration. Nevertheless I did not rearrange the Queen the next morning. A compelled marvel is a very poor advertisement for independence, and I wanted independence to remain my discovery.

### E04-020 | A Death with an Address | 1888-06

Kappel died in June, having devoted the last of his strength to arranging books rather than composing farewells. His nephew delivered my old papers in a bundle tied with green tape. Inside lay the brass key I had surrendered years before, polished by handling and utterly useless to the lock it once opened. At the funeral someone introduced me as an acquaintance. I nearly corrected him with a list of the man's services to my work, then found the catalogue inadequate and held my tongue. Back at the tower I opened Kappel's last note. It concerned the copying of pages whose ink had begun to fade. Voss helped me sort them by candlelight. I set a second cup beside the ledger before remembering that the man who had always complained about my tea would not be arriving.


## Episode 05: Correspondence with the Unfinished Future (1889 to 1899)

### E05-001 | The New Keeper | 1889-01

Kappel's papers occupied the spare chamber, and no amount of tidying restored their former keeper. Voss proposed placing a working copy of the blue ledger in Clara's dispensary. I protested that a shop was not an archive. Clara looked up at the damp stain on my ceiling and inquired whether a leaking ruin was one. We established a register of every transfer, complete with dates and signatures. I expected the process to waste a week. On its first morning we found a report on the Mermaid misfiled with instruments and an error in Kappel's last copy list. I would have preferred a loyal archivist to a bureaucracy; a bureaucracy, however, had the advantage of surviving a single man's illness. I disliked the admission sufficiently to insist that my own original ledger remain in the tower.

### E05-002 | A Visitor Who Asked About Pain | 1889-07

Reuter at last visited the tower. He passed over my homunculi's elegance without a compliment and watched the King push against the partition installed after his fall. Did the restriction distress him? I replied that it prevented another injury. Reuter observed that both statements might be true. He was too practiced a physician to expect a lecture to settle the question, and I was too practiced a philosopher to resist attempting one. Voss proposed recording the King's activity under different harmless arrangements. We did so, and the observations answered less than either of us wished. I altered the cleaning and maintenance schedule to minimize unnecessary interference. Reuter treated this as evidence of progress. I treated it as experimental housekeeping, which is a more respectable name for being influenced by an adversary.

### E05-003 | The Metronome Comes Apart | 1890-04

The cracked metronome had followed me from student rooms to the tower without keeping satisfactory time for most of the journey. Its spring finally broke while I was clearing a shelf. Lenz offered to replace it, but I asked him instead to open the case so I could see where the metal had fatigued. We laid the pieces on green felt, and he showed me the tiny points where repeated strain had done its quiet work. I was tempted to draw a metaphor about men of science. Lenz advised me to purchase a new spring before delivering a sermon. We repaired it, but I never used it again for measurement. It remained on the shelf as a reminder of error corrected, not a shrine to error perpetuated.

### E05-004 | The Woman in the Corridor | 1890-11

Voss sent for me while attending her mother in Vienna. She wished to ask a technical question about a botanical specimen, but the visit chiefly consisted of sitting in a corridor where cups were collected with a clatter at regular intervals. Her mother was growing blind, and the physicians had little to offer. I attempted to describe the difference between lost perception and lost understanding. Voss told me, very gently, that she was not conducting an inquiry. We sat without speaking. Before leaving I repaired the catch on the specimen box she had carried from home. She thanked me for coming. No result was published, and I remember the visit as one of the few occasions on which absence of useful speech was not a failure.

### E05-005 | A New Name on the Packing Case | 1891-05

Anna Lenz, whom I had once seen asking clocks whether they knew the hour, had become competent with photographic plates and inventory records. She labelled a crate of instruments with a code that allowed each item to be matched to its drawing. I told her the system was unnecessarily elaborate. She opened the crate and identified a damaged component before I could discover that the wrong object had been packed. Her father watched me concede the point with open enjoyment. Anna asked whether I preferred to be addressed as Professor or Doctor. I said the former was more historically interesting and the latter presently more useful. She called me Doctor and charged for the improved packing. I paid without bargaining and remembered the child at the river.

### E05-006 | A Night of Melted Snow | 1891-12

Snow slid from the tower roof and blocked the outer drain, sending water beneath the glass-room door. Clara arrived with towels; Anna arrived with a camera she had intended to use for an experiment and immediately put it aside. We carried every living vessel to the dry chamber. The Mermaid's jar was heavier than it looked, and I nearly dropped it when my foot slipped. Anna steadied my arm and told me to pay attention to the floor rather than the specimen. She was right. We lost several loose pages and a box of old labels but no creatures. The following week I insisted upon a new drainage channel. I paid for the work with money reserved for an optical experiment, and did not regret the exchange until the invoice arrived.

### E05-007 | The Theory of a Larger Life | 1892-06

The enormous empty vessel still occupied the room it had been built too large to leave. Voss asked whether my desire for a full-sized creature was scientific or merely a protest against visitors who called my little people curiosities. I replied that the restriction of growth by scale was a legitimate problem and that her two explanations were not mutually exclusive. We drew separate plans: one for larger organization, one for observing the present creatures without interfering with them. The second required fewer resources and furnished the immediate work of a month. The first I locked away, not from shame but from the unpleasant knowledge that ambition is expensive before it becomes glorious. I examined the locked drawing every morning. A problem does not cease to exist because a sensible woman has supplied a cheaper one.

### E05-008 | An Unanswerable Question of the Queen | 1892-10

The Queen began to grow still whenever we approached with certain instruments. Clara carrying fresh supplies produced no such effect. I called it anticipation. Voss asked whether odor, shape, or some regularity of our movements might suffice to explain it. We brought harmless objects to the bench and varied the observer, the order, and the light. The Queen was exquisitely uncooperative: responsive on one occasion, indifferent on another. I had made her, or at least had given the conditions in which she came to be; I had not instructed her to form expectations about me. If she had nevertheless acquired them, they might prove my deepest claim more decisively than any graceful limb. I was delighted by the thought and troubled by what those expectations might contain.

### E05-009 | The Letter I Did Send | 1893-03

I had drafted many letters to Henry in the years since his last reply, almost all unsent. This one was brief. I wrote that I remained concerned with living organization, that my smaller creations continued to survive, and that I hoped his own investigations had not brought him undue trouble. I enclosed no technical drawings. Voss examined the envelope, not the contents, and asked why I had waited so long. I told her that serious men should not burden one another with domestic sentiment. She said serious men were perfectly capable of deciding which letters to answer. I posted it myself. No reply came. I do not know whether he received it. I have been tempted to write an entire theory to explain that uncertainty, but it remains only a missing answer.

### E05-010 | The Sound Behind the Wall | 1893-11

A rhythmic tapping began behind the west chamber wall, usually after midnight. I assumed some animal had made a nest. Anna proposed that the newly fitted drain was transmitting movement from the outer gutter. Lenz tapped the pipe and reproduced the sound almost exactly. I was disappointed not to discover an intruder but satisfied to discover a mechanism. The tapping had disturbed the Ballerina's rest, and she had begun refusing music on the following mornings. We wrapped the pipe and shifted her vessel by a hand's breadth. The rhythm ceased and the dancing returned, though I recorded no claim of causation beyond the sequence. Anna asked whether the old professor still believed every peculiar noise was a plot. I said only the interesting ones.

### E05-011 | The Farewell That Was Not One | 1894-07

Clara informed me that she intended to reduce her hours and transfer much of the business to an assistant. I immediately asked whether the tower could still obtain its customary supplies. She looked at me until I understood what I had made of the announcement. She was tired, she said, and wished to spend some mornings reading without a queue at her counter. I congratulated her poorly. On my next visit I brought a chair cushion, having noticed that the one beside the window had gone flat. We drank tea and discussed the weather. When I left, she asked that I continue calling even on days when I required nothing from the shop. I answered that I could not imagine why I should do otherwise. I began doing so the following Thursday.

### E05-012 | The Inventory of Failures | 1895-02

Anna proposed photographing every damaged joint before another order could repeat the mistake. Voss demanded a register of discarded hypotheses as well. Thus three afternoons vanished into the compilation of a formidable inventory of my misfortunes: warped vessels, false revivals, the Archbishop's misleading gestures, inconsistent growth, and one enormous container that would not pass through a door. Anna weighed the finished book against the catalogue of my published successes and found the former heavier. She expected me to be offended. I informed her that failures are naturally more numerous because most of nature is arranged to resist the improvement of philosophers. A month later the book saved us from repeating an optical error. I granted the catalogue a permanent place, although not on the shelf reserved for the achievements of which I was proudest.

### E05-013 | A New Instrument, an Old Bias | 1895-10

Faber's new timing instrument could divide an interval with exquisite delicacy. I used it upon the King's movements and announced improved regularity. Voss examined the original records and found I had shifted the instant at which each interval began. The correction disposed of my discovery. Faber wrote that even a perfect mechanism could not cure an observer of imprecision. I placed his note beside the dial, where guests might admire the wit without knowing its victim. Privately I recalculated three old experiments and discovered that one result, dismissed years before, had been more substantial than I believed. I did not announce a triumph. I marked the page for repetition. Instruments sometimes correct a man's conceit and sometimes vindicate his suspicion; only the first outcome is generally told with pleasure by his friends.

### E05-014 | A Book from England | 1896-04

Voss sent me Wells's *The Island of Doctor Moreau*, and I read it by the east window while the repaired drain rattled in the rain. Moreau was an ambitious man, which did not excuse his vulgarity. His creatures were made to obey laws they had not devised and punished for failing to remain what their maker wished. The author arranged the matter so that scientific cruelty could be recognized even by readers who disliked science. I objected to the simplification in the margin. Then I thought of Reuter watching the King press against his partition and wrote a longer objection which was not altogether directed at Wells. I called the novel sensational, manipulative, and distressingly difficult to dismiss. Voss asked if I had enjoyed it. I said I had read it twice, which ought to have sufficed.

### E05-015 | The Empty Place beside the Piano | 1896-12

Clara seldom visited the tower in winter, and the Ballerina had not heard her beloved Mendelssohn competently played for weeks. Anna volunteered to learn the passage. I said the creature might respond to Clara's touch rather than the notes; Anna, apparently incapable of being discouraged by a reasonable objection, practiced after her day's work. On the fourth attempt the Ballerina danced. I declared the experiment successful and sent Clara the news. She wrote that she was glad to be relieved of a duty I had apparently assigned to her for life. The old music pages remained beside the piano after Anna brought a clean copy. I could have put them away. For several winters I had known exactly when Clara would arrive by the sound of her boots below the stairs, and a new pianist could not reproduce that particular prelude.

### E05-016 | The London Address | 1897-08

Agnes Bell, a London translator acquainted with Voss, asked for an account that could be separated from its author's reputation. An admirably rude request. I sent her the Queen's avoidance of certain instruments, including observations which weakened my favored interpretation. She translated the report without strengthening its conclusions, a restraint rare enough to merit praise. At a meeting, someone inquired whether my professorial title remained valid. Bell replied that dismissal did not render a man's measurements false. Later, over a supper notable chiefly for its bad fish, she said she had defended the evidence rather than its author. I answered that this was precisely why I had trusted her with it. She seemed surprised. I was not. I had learned, after some expense, to prefer an ally who could distinguish me from my legend.

### E05-017 | What the Queen Had Not Forgotten | 1898-02

Anna set a new wooden stand beside the Queen's glass. The little sovereign withdrew at once, much as she had years earlier when a certain clamp approached. Anna noticed the resemblance of outline. We tried an innocuous duplicate and observed another retreat. Voss rightly objected that shape alone did not establish remembered experience. I made the objection sharper: without a known account of the intervening years, we could not say what had been preserved or how. But the possibility was intoxicating. I searched the blue ledger and found my old description of the first disturbance: 'trivial.' I had dismissed an incident which might have endured within the creature long after it had ceased to occupy my mind. I underlined the word, resisting the temptation to improve the record. It was not my finest sentence. It might yet prove important.

### E05-018 | The Visit to Clara's Garden | 1898-07

Clara had taken to keeping herbs and bees behind her house. I visited one July afternoon without needing a bottle, an instrument, or a favor. She asked my opinion of a sickly plant. I pronounced on its leaves, twice and incorrectly, until she lifted a paving stone and showed me how the roots had been crowded. We moved the stone, drank warm tea, and watched bees make an industry of the thyme. I spoke of the lives I had brought forth. Clara replied that her garden had never once obeyed her merely because she planted it. I said my case was rather different. She handed me the watering can without further dispute. The plant recovered. On my next visit I brought a drawing of its roots, and she used the reverse of the paper to write a shopping list.

### E05-019 | The Scale Model of an Impossible Room | 1898-11

I laid out plans for a laboratory large enough to support a form of life the public could no longer dismiss as a charming smallness. Lenz measured the stairwell and laughed in a manner which I have never encouraged. Anna constructed a paper model and demonstrated that the central apparatus could not round the entrance passage. Voss asked what observations justified its dimensions. I had estimates, hopes, and a theory still too young to be publicly insulted. I did not order the construction. The model went beside the catalogue of failures, its paper walls carefully repaired where Anna had cut them to demonstrate the problem. It was not a surrender. I continued drawing alternative entrances long after the others had gone, one candle burning down into the saucer. The larger creature existed already as a demand upon my imagination, if nowhere else.

### E05-020 | A Rumor with a Familiar Name | 1899-03

Bell enclosed a newspaper clipping concerning a Frankenstein said to have restored motion to dead flesh and brought catastrophe upon himself. A surname in print is a poor identification, especially when journalists are permitted to decorate it. I read the report twice for names, witnesses, and inconsistencies, then searched for Henry's old unsigned drawings. His scheme of assembly lay beside my notes on growth, as it had thirty-four years before beneath a smoking lamp. Voss asked if I intended to write him. I answered that I first intended to discover whether the man in the report was alive. She watched me longer than the answer deserved. I was not certain whether I wished to see my former pupil vindicated, or to discover the one thing he might have done without me. I did know that I disliked learning of it through a newspaper.

### E05-021 | The News from the Windmill | 1899-06

The second account came in June, and with it a confirmation from a correspondent not given to the more picturesque forms of falsehood. Henry Frankenstein had brought a being to life from dead flesh. The creature had survived the fire at a windmill. Henry was alive. I entered the claims, their sources, and the matters still concealed from me in the blue ledger. The diagram of separate organs lay open on the table, its corners curled with age. Henry had pursued assembly while I pursued growth, and there, at last, was a result no committee could dismiss by refusing to inspect it. Anna asked whether I would seek him. Voss asked what I would want when I found him. I closed the travelling case and looked through the east window toward the road. I offered neither woman an answer. The Queen moved upon her ledge behind me. I remained in the tower that night, with the old drawings spread beneath my hand.


---

**End of permitted chronology.** As of June 1899, Pretorius has news of Henry and has not left the tower to make contact.
