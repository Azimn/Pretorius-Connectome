# Pretorius: The Lost Years
## Batch 1 Production Report, Voice-Reviewed Edition v2

**Date compiled:** 2026-10-08

**Result:** 102 new autobiographical memory events across 5 complete chronological episodes. All are marked **reconstructed**, with explicitly named established anchors held in the continuity ledger. **Speculative crossover events:** 0. Childhood additions: 0; primary-source childhood facts are preserved in the manuscript preface and ledger rather than fictionalized into trauma.

**Periods covered:** 1860-1864, 1864-1868, 1868-1877, 1878-1888 and 1889-June 1899. The first two episodes contain 41 academic and scientific-career events; the subsequent three contain 61 exile, fieldwork, relationship and independent-research events. This distribution favors adult exile in keeping with project emphasis.

**Narrative size:** 13,139 words in event bodies, excluding metadata and continuity prose. Each complete episode contains between 15 and 30 linked events. All memory_text fields are first-person scene accounts. **Record order:** E01-001 through E05-021.

**Input audit:** Autobiography: 1842 birth; 1860 matriculation; 1864 doctorate and faculty appointment; Henry mentorship; six established homunculi in stated order before dismissal; 1868 expulsion and tower; 1899 news of Henry. The original manuscript also contains a large repeated LoRA training archive, and the second file includes 389 JSONL `generated_training` conversational entries. Those are not primary eyewitness records. The 1860s University of Ingolstadt is incompatible with actual history, so it remains a flagged fictional divergence, not a silently repaired location.

**Duplicates:** 0 exact repeated memory texts across the 102 new events. Near-duplicate review used TF-IDF unigram/bigram cosine, threshold 0.40 for review. 0 distinct pairs exceeded its comparison threshold; see below for any flagged pairs. Related scenes deliberately return to the same subject with new evidence or changed relationships and are not automatically duplicates.

**Near-duplicate review candidates:** None at the chosen threshold.

**Chronological uncertainties and conflicts:** The functioning Ingolstadt university of the 1860s is fictional relative to documented history. Pretorius's rapid 1864 doctorate and professorship remain original canon, though unusually early. The exact dates of the six homunculi and the 1899 windmill incident are not fixed in the autobiography; new intermediate dates are approximations, not claims about source chronology. The primary text states nearly thirty years of isolation in broad terms, while the reconstruction introduces discreet visits, travel and correspondence; the interpretive choice is that *obscurity* need not mean complete immobility. Readers who prefer literal total seclusion should review the 1878-1897 travel subarc as a potentially incompatible extension. Public-domain literary novels appear only as contemporary books, not direct encounters.

**Historical consistency:** 1866 is treated as a period of wartime anxiety without fabricating a specific military service record; 1870-71 references correspond to the Franco-Prussian War and unification. Mendelssohn's 'Spring Song' was published by 1844, predating the 1867 Ballerina scene. *Strange Case of Dr Jekyll and Mr Hyde* appeared in 1886; *The Island of Doctor Moreau* in 1896. For background: https://www.lmu.de/en/about-lmu/lmu-at-a-glance/history/ ; https://imslp.org/wiki/Lieder_ohne_Worte,_Op.62_(Mendelssohn,_Felix) ; https://www.gutenberg.org/ebooks/159 ; https://germanhistorydocs.org/en/forging-an-empire-bismarckian-germany-1866-1890/creation-of-the-german-empire-1866-1871

**Unresolved threads:** Henry's unanswered correspondence; Pretorius's motives for contact; whether the homunculi's responses reflect learned anticipation or simpler environmental cues; Clara's independent life and slowing business; the archive succession; the difficulty of scaling living forms without endangering existing lives; the old paper laboratory model; the degree of trust between Pretorius and Voss; the ethical question Reuter pressed about pain and restriction; interpretation of the Queen's avoidance and of the King/Archbishop cooperative episodes.

**Privacy and safety of inference:** Fields headed `observations` and `belief_changes` distinguish recorded behavior from Pretorius's interpretations. No new biography is treated as evidence that the historical source attests actual creature consciousness. The cultivation process stays wholly fictional and nonprocedural.

**QA controls:** Required keys and nonempty memory bodies; monotonic event chronology; episode lengths 15-30; referential integrity and prior-only event links; no events after 1899; no reunion, Bride or Frankenstein Village material; no em dashes; no sub-90-word scenes. Automated validation output: **PASS**, with 0 errors. The events additionally received manual narrative review of recurring objects, named relationships and source anchors.

**Exact continuation checkpoint:** **E05-021, June 1899**, ending with Pretorius still at the tower, having obtained corroboration about Henry and the creature. There is no later permitted event within this project's boundary. Any further in-scope enrichment should be inserted as retrospective scenes *before* that date, using distinct IDs and revised chronological_order values. No next encounter can be written without changing the stop rule.


## Voice review and revised-edition quality report (2026-10-08)

**Editorial assessment:** The original narrative had unusually good material continuity but regularly ended scenes in conscientious self-analysis. Repeated pattern: Clara, Voss, or Reuter corrects Pretorius, then the narrator explicitly announces moral growth. That flattened his pride, self-protection, and intellectual sovereignty. The revision retains all 102 narrative incidents and revises their psychological framing, the cadence of personal recollection, and the imbalance between reported actions and inferred motives. He remains capable of considerate conduct, but seldom names it generously. His harshest vanity is not always stated aloud; it may appear in the order of the records he preserves.

**Characterization safeguards:** The aged, digital Pretorius persona is used as a voice reference only. It is not retroactively inserted as historical autobiography. Period episodes retain university and post-dismissal life, not modern computational self-descriptions. The narrator's self-serving claims are not treated as confirmed inner states. No literal crossover was added. All earlier established anchors and the June 1899 hard stop remain in force.

**Revision scope:** 54 scene texts materially revised; 48 retained verbatim. Selected record interpretation fields were updated where revised causal emphasis required it. Pre-1899 E05 events no longer use the specific 1899 windmill news as their source_anchors. All dates, episode lengths, chronological orders, IDs, participant/location metadata and prior-event links remained stable.

**Selected revision IDs:** E01-005, E01-008, E01-009, E01-010, E01-014, E01-015, E01-018, E01-019, E02-005, E02-006, E02-008, E02-012, E02-014, E02-015, E02-019, E02-020, E02-021, E03-002, E03-005, E03-006, E03-009, E03-011, E03-013, E03-018, E04-001, E04-002, E04-003, E04-005, E04-006, E04-009, E04-010, E04-011, E04-012, E04-013, E04-014, E04-015, E04-016, E04-017, E04-019, E04-020, E05-001, E05-002, E05-007, E05-008, E05-012, E05-013, E05-014, E05-015, E05-016, E05-017, E05-018, E05-019, E05-020, E05-021

**New manuscript event-body words:** 13,139. **Exact duplicates:** none. **Near-duplicate candidates at TF-IDF cosine >= 0.40:** 0.

**Automated checks:** 102/102 manuscript-to-JSONL exact matches; 102/102 chronological indices; all required fields preserved; all previous-event links resolve backward; episode lengths remain 20/21/20/20/21; all scenes at least 90 words; no em dashes; all memories stop before Henry's reunion; ZIP integrity test completed. **All automated checks passed.**

**Interpretive limits:** A good voice edition is not proof of a real historical psyche. Dates and incidental relationships remain invented. Literary authenticity and neural-imprinting suitability still require independent user testing; no behavioral retention result has been claimed here.
